 #pragma rtGlobals=1		// Use modern global access method.
#pragma version=9.2

//Software written by Brandon Dzuba in order to automate various data acquisition protocols
#include ":Dependencies"


//Cryptid V 2.0
//Force Spectroscopy assay software written for Asylum Cypher AFM's running version 16+
//Instruction on writing packages for cryptid exists in the readMe file

//NOTE: All functions in this folder are core to the functioning of Cryptid. For functions you can use to program
//in Cryptid, see CryptidFunctions.ipf


Menu "Cryptid" 
	"Initialize", initializeCryptid()

	subMenu "Cryptid"
		"Show Panel", showCryptidWindow()
		"Show Settings", showCryptidSettings()
		
	end
	subMenu "Current Panel"
		"Popout or Modify panel", popOutPanel()
		"Show Settings", showCurrentPanelSettings()
	End
End


Menu "stackMenu" , contextualmenu, dynamic
	Submenu "Add Step After"
		wave2List(root:Settings:Cryptid:packageList,0), cryptidAddStep()
	End
	Submenu "Add Step Before"
		wave2List(root:Settings:Cryptid:packageList,0), cryptidAddStep(position=getSelectedStep())
	End
	"Popout Panel", popOutPanel()
	"Rename Step", renameCryptidStep()
	"Remove Step", cryptidRemoveStep(getSelectedStep())
	
End


//PANEL INFORMATION
#pragma TextEncoding = "UTF-8"
#pragma rtGlobals=3				// Use modern global access method and strict wave access
#pragma DefaultTab={3,20,4}		// Set default tab width in Igor Pro 9 and later

//Where all the magic happens. All functions should call back to here
Function cryptidMain(action, [deflVolts,zSensorVolts,FC,step,saveName, save2Memory, getNewZero])
	
	Variable action, FC, step, save2Memory, getNewZero
	string saveName
	wave deflVolts,zSensorVolts
	wave/t cryptidStack = getCryptidStack()
	wave/t tSettings = getCryptidSettings(1)
	wave vSettings = getCryptidSettings(0) 
	
	if (paramIsDefault(save2Memory))
		save2Memory =1 
	endif
	
	if (paramIsDefault(getNewZero))
		getNewZero = 0
	endif		
	if (vSettings[%save2Memory] == 0)
		save2Memory = 0
	endif
	
	//TIME TEST
	cryptidTimer(0)
	
	//If a wave was passed, we were expected to save it
	if(!paramIsDefault(deflVolts))
		if (paramIsDefault(savename))
			cryptidSaveWaves(DeflVolts,ZSensorVolts,FC=FC, save2Memory = save2Memory)
			
		else
			cryptidSaveWaves(DeflVolts,ZSensorVolts,FC=FC,saveName=saveName,save2Memory = save2Memory)
		endif
		//TIME TEST
		cryptidTimer(1)
	endif
	
	
	//TIME TEST
	cryptidTimer(2)
	//if we just ran the first ramp, store the DF so we can use it later
	if (vSettings[%currentStep] == firstRamp() )
		vSettings[%firstRamp] = vSettings[%currentStep] 
	endif
	
	//TIME TEST
	cryptidTimer(3)
	
	//If stop was pressed, stop, or if we were only running through once
	if (getCVar("stop") || ((action == 0 || action == 2) && vSettings[%singleRun])  )
		vSettings[%singleRun] = 0
		cryptidDebug(diagString="STOP")
		vSettings[%currentStep]=0
		vSettings[%stop] = 0
		vSettings[%repeatCounter] = 0
		listbox StackDisplay disable=0, win=$getCStr("DynamicPanelName")
		updateStatus("Stopped")
		return 0
	endif
	
	
	//Repeat handler
	Variable skipPrerun = 0
	//If were doing a repeat, we should move on regardless of trigger condition
	if (vSettings[%repeatCounter])
		//print "repeat "+ num2str(vSettings[%repeatCounter])
		action = 1
		skipPrerun = 1
	endif
	
	string SFMCallback = "cryptidExecuteStep()"
	CryptidDebug(diagString="Cryptid Called with action "+num2str(action))
	Switch(action)
		
		//Do not proceed and restart
		case 0:
			vSettings[%currentStep] = -1
			vSettings[%totalIterations] += 1
			vSettings[%iterationsSinceLastButton] += 1
			
			//Fix filters
			td_WV("Cypher.Input.FastA.filter.freq",25000)
			td_WV("Cypher.Input.FastB.filter.freq",25000)
			td_wv("cypher.lvdt.z.filter.freq",2e3)
			//Modified to not call back cryptid main, but go straiht to below line
			//TIME TEST
			cryptidTimer(4)
			SearchForMolecule(Callback=SFMCallback,FoundMolecule=0)
			break  
			
		//Proceed with next step
		case 1:
			//store deflV
			cryptidExecuteStep(skipPrerun = skipPrerun)
			break

		//Entire process is completed
		case 2:
			vSettings[%currentStep] = -1
			vSettings[%totalIterations] += 1
			vSettings[%fullIterations] += 1
			vSettings[%iterationsSinceLastButton] += 1
			
			//Kill any ongoing tasks
			td_stopInWaveBank(-1)
			td_stopOutWaveBank(-1)
			ARBackground("Kill",0,"")
			//TIME TEST
			cryptidTimer(9)
			SearchForMolecule(Callback="cryptidMain(1)",FoundMolecule=1)
			
			if (vSettings[%discordMessage])
				discordMessage("Run completed")
			endif
			
			updateStatus("Run Completed!")
			
			break
		
		//Just runs the selected step
		case 3:
			
			string callback = "cryptidExecuteStep(stepNum=getSelectedStep(),ignoreIterCounter=1)"
			getDeflVOffset(callback = callback)
			vSettings[%totalIterations] += 1
			vSettings[%fullIterations] += 1
			vSettings[%iterationsSinceLastButton] += 1
			vSettings[%stop]=1
			break
			
		//Just run through once
		case 4:
			vSettings[%currentStep] = -1
			vSettings[%totalIterations] += 1
			vSettings[%fullIterations] += 1
			vSettings[%iterationsSinceLastButton] += 1
			SearchForMolecule(Callback=SFMCallback,FoundMolecule=0)
			break  
			
	endswitch
	
End

Function cryptidExecuteStep([stepNum, skipPrerun, forcePrerun,ignoreIterCounter])

	variable stepNum, ignoreIterCounter
	variable skipPrerun, forcePrerun
	wave vSettings = getCryptidSettings(0)
	wave/t tSettings = getCryptidSettings(1)
	wave/t cryptidStack = getCryptidStack()
		
	//If default, we want to go to next step, so increment step here
	if(paramIsDefault(stepNum))
		vSettings[%currentStep] += 1
		stepNum = vSettings[%currentStep]	
	endif
	if(paramIsDefault(ignoreIterCounter))
		ignoreIterCounter = 0
	endif
	if(paramIsDefault(forcePrerun))
		forcePrerun = 0
	endif
	
	if(paramIsDefault(skipPrerun))
		skipPrerun = 0
	endif
	
	cryptidDebug(diagString="Executing Step Number: "+num2str(stepNum))
	
	//TIME TEST
	cryptidTimer(5)
	//If first run, execute prerun stuff. Wish I didn't have to do a callback here but it's easier....
	if( forcePrerun || (stepNum == 0 && !skipPrerun) )
		
		cryptidPrerunRoutine()
	else
		cryptidFinishExecuteStep(stepNum,ignoreIterCounter=ignoreIterCounter)
	endif
	
End

Function cryptidFinishExecuteStep(stepNum,[ignoreIterCounter])

	Variable stepNum,ignoreIterCounter
	if(paramIsDefault(ignoreIterCounter))
		ignoreIterCounter = 0
	endif
	
	string stepType
	string stepName
	
	wave vSettings = getCryptidSettings(0)
	wave/t tSettings = getCryptidSettings(1)
	wave/t cryptidStack = getCryptidStack()
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")

	//If out of steps, go back to main (stack is completed!!)
	if (stepNum >= dimSize(cryptidStack,0))
		cryptidMain(2)
		
	//If the step we are running has an iter, and it's not time to run it, proceed to next step
	elseif( !ignoreItercounter && (mod(vSettings[%iterationsSinceLastButton],str2num(cryptidStack[stepNum][%iter])) && vSettings[%iterationsSinceLastButton] != 0))
		cryptidMain(1)
	else	
	//Actually run the step
		//Show were running the step by selecting the one were running (makes it selected in the listbox)
		wave selWave = root:Settings:Cryptid:stackSelWave
		selWave[][0] = 0
		selWave[stepNum][0] = 1
		
		//Get the name and type of the step to run
		stepName = cryptidStack[stepNum][%Name]
		stepType = getStepType(stepNum=stepNum)
		tSettings[%currentStepName] = stepName
		
		//Probably don't need this bit anymore
		if (stringMatch(stepType,""))
			cryptidDebug(diagString="Step Type not found", alwaysPrint=1)
			return -1
		endif	
	
		//set the workingFolder to the correct one
		setWorkingFolder(stepName)
		
		//Uncomment to show the currently running panel (way too much)
		//replaceSettingsPanel(stepName)
		
		//Execute the appropriate command
		//THIS IS WHERE WE RUN THE STEP
		//TIME TEST
		cryptidTimer(8)
		execute experimentExecutables[%$stepType][%executeCommand]
	endif
End

//This is a "catch-all" function for things
Function cryptidPrerunRoutine()

	cryptidDebug()
	
	//Get the zero voltage offset
	//TIME TEST
	cryptidTimer(6)

	wave vSettings = getCryptidSettings(0)
	
	if (vSettings[%useFastZero])
		QuickDeflVOffset()
	else
		getDeflVOffset()
	endif
	
//	cryptidFinishExecuteStep(0)
End

//Variant for calling in user programs with a callback
Function getNewDeflVOffset(callback)
	
	string callback
	
	wave vSettings=getCryptidSettings(0)
	
	if (vSettings[%useFastZero])
		QuickDeflVOffset(callback=callback)
	else
		getDeflVOffset(callback=callback)
	endif

End
//Function to access the first ramp waves easily
Function/WAVE getFirstRampWave(infoName)
	
	string infoName
	
	wave/t cryptidStack = getCryptidStack()
	Variable firstRampIndex = firstRamp()
	if (firstRampIndex ==-1)
		return $""
	endif
	
	string DF = getWorkingFolder(cryptidStack[firstRampIndex][%Name])
	wave returnWave = $DF+infoName
	
	if(!WaveExists(returnWave))
		CryptidDebug(diagString="First ramp wave not found", alwaysPrint=1)
		return $""
	endif
	
	cryptidDebug(diagString="First Ramp DF: "+DF)
	return returnWave
	

End

Function QuickDeflVOffset([callback])

	string callback

	wave/t tSettings = getCryptidSettings(1)
	
	string channel = tSettings[%primaryDeflectionChannel]
	
	Wave vSettings = getCryptidSettings(0)
	vSettings[%deflVOffset] = td_RV(channel)
	
	if(paramIsDefault(callback))
		cryptidFinishExecuteStep(0)
	else
		execute callback
	endif
End	


//Gets the zeroDeflV for the experiment
Function getDeflVOffset([callback])

	string callback
	
	if(paramIsDefault(callback))
		callback = "cryptidFinishExecuteStep(0)"
	endif
	
	Make/O/N=100 root:Settings:Cryptid:DeflectionOffsetData
	Wave DeflectionOffsetData = root:Settings:Cryptid:DeflectionOffsetData
	
	Variable Error=0
	
	//Removed td_stop, as it (hopefully) wasn't needed and could cause issues with high-bandwith data collection
//	Error+=td_stop()
	
	wave/t tSettings = getCryptidSettings(1)
	
	//Changed decimation from 100 to 1 to try and speed up data acquisition
	Error+= td_xSetInWave(0, "0", tSettings[%primaryDeflectionChannel], DeflectionOffsetData, "getDeflVOffsetCallback(\""+callback+"\")",1)
	// Execute motion
	Error +=td_WriteString("Event.0", "once")

	if (Error>0)
		cryptidDebug(diagString="Asylum Error in SetInWave or td_writeString: "+num2str(Error), alwaysPrint=1)
	endif

End


Function getDeflVOffsetCallback(callback)
	
	string callback
	
	Wave DeflectionOffsetData=root:Settings:Cryptid:DeflectionOffsetData
	WaveStats/Q DeflectionOffsetData 	
	Variable DeflectionOffset=V_avg

	killWaveStats()
	Wave vSettings = getCryptidSettings(0)
	
	vSettings[%deflVOffset] = deflectionOffset 

	cryptidDebug(diagString="Deflection offset set to: "+num2str(deflectionOffset))
	
	//TIME TEST
	cryptidTimer(7)
	//SORRY FOR CALLBACK HELL I TRIED TO AVOID THIS
	Execute callback
	//cryptidFinishExecuteStep(0)

End



//Display the main cryptid settings files
Function showCryptidSettings()

	string loc = "root:Settings:Cryptid:"
	edit/W=(0,0,500,200) $(loc+"tSettings").ld
	edit/W=(0,300,500,500) $(loc+"vSettings").ld
	edit/W=(0,600,500,800) $(loc+"experimentStack").ld

End

Function showCurrentPanelSettings()

	Wave vSettings
	Wave/t tSettings
	
	if (waveExists(vSettings))
		edit/W=(0,0,500,200) vSettings.ld
	endif
	if (waveExists(tSettings))
		edit/W=(0,300,500,500) tSettings.ld
	endif

End

Function popoutPanel()

	variable selStep = getSelectedStep()
	string stepType = getStepType(stepNum=selStep)
	
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
	
	string executeString = experimentExecutables[%$stepType][%panelFunction]+"()"
	
	execute executeString
	
	setWindow $"", hook(thisPanelHook)=cryptidPanelHook

End

//When a panel is popped out, I want to capture events to it
Function cryptidPanelHook(s)
    STRUCT WMWinHookStruct &s
    switch(s.eventCode)
        case 3:
            // inspect mouse/button info in s
            // if right click:
            
            	Variable isRightClick = s.eventMod %& 0x10
			if(isRightClick)
				PopupContextualMenu/N "cryptidPanelMenu"
			endif
            return 1 
    endswitch

    return 0
End

Menu "cryptidPanelMenu" , contextualmenu, dynamic
	"Copy recreation for cryptid", savePanelUpdates()
End



//set the current step
Function setCurrentStep(number, name)

	variable number
	string name
	
	wave/t tSettings = getCryptidSettings(1)
	wave vSettings = getCryptidSettings(0)
	
	vSettings[%currentStep] = number
	tSettings[%currentStepName] = name
	
End

//Initialization procedure
Function initializeCryptid()
	
	//Check before reinitilizing
	if (windowExists("CryptidPanel"))
		doAlert 1, "Cryptide already running. Reinitialize?"
		if (v_flag != 1)
			doWindow/F $"CryptidPanel"
			return 0
		else
			killWindow $"CryptidPanel"
			killDataFolder root:settings
		endif
			
	endif
		makeCryptidFolderStructure()

	makeCryptidSettingsWaves()
	
	String startDF = getDataFolder(1)
	
	//Load Cryptid settings waves
	loadCryptidSettings("Cryptid","tSettings;vSettings;packageList;UserList;cantileversTemplate",nodebug=1)
	wave/t tSettings = getCryptidSettings(1)
	wave vSettings  = getCryptidSettings(0)
	Make/O/T/N=0 root:settings:Cryptid:experimentLog
	
	vSettings[%cryptidDebug] = 0
	
	//reset the counters in these waves
	vSettings[%totalIterations] = 0
	vSettings[%stop] = 0
	vSettings[%fullIterations]= 0

	//Set the FolderPath
	wave/t tSettings = getCryptidSettings(1)
	tSettings[%CryptidPath] = getCryptidPath("")
	
	//Initialize all packages
	initializeCryptidPackages()

	doWindow cryptidPanel
	if (!V_flag)
		execute "CryptidPanel()"
	endif
	doWindow cryptidGraph
	if (!V_flag)
		execute "cryptidGraph()"
	endif
	
	updateGraphPosition()
	
//	doWindow cryptidDynamicPanel
//	if (!V_flag)
//		execute "cryptidDynamicPanel()"
//	endif
	
	//SetWindow $tSettings[%panelName] hook=crytptidPanelHook, hookevents=1
	
//	execute "Search_Panel(root:Settings:Cryptid:tSettings[%panelName],root:Settings:Cryptid:tSettings[%SettingsPanelName])"
	tSettings[%previousSelName] = tSettings[%settingsPanelName]
	//Add the first step, which should almost always be a force ramp
	cryptidAddStep(expType="ForceRamp")
	
	//Replace the ForceRamp panel
	replaceSettingsPanel(tSettings[%settingsPanelName])

	setDataFolder $startDF

End

//Returns the name of the type of setting/Panel
Function/S getStepType([stepName, stepNum])

	string stepName
	variable stepNum
	wave/t cryptidStack = getCryptidStack()
	
	if(paramIsDefault(stepName) && paramIsDefault(stepNum))
		stepName = getDimLabel(cryptidStack, 0, getCurrentStepNumber())
	elseif(paramIsDefault(stepName))
		stepName =  getDimLabel(cryptidStack, 0, stepNum)
	else
		//Use step name to find the stepType
		variable maxIter = dimsize(cryptidStack,0)
		variable i
		for (i=0;i<maxIter;i+=1)
			if (stringMatch(stepName,cryptidStack[i]))
				stepName = getDimLabel(cryptidStack, 0, i)
				break
			endif
		endfor
	endif
		

	variable endNum = strsearch(stepName, "_",0) -1
	string returnString = stepName[0,endNum]
	
	cryptidDebug(diagString="Step Type for ("+stepName+") is ("+returnString+")")
	
	return returnString
	
End

//Return a string to create a new path
Function/S getCryptidPath(relativePathString)
	
	String relativePathString
	string pathIn = functionPath("cryptidMain")

	//Get the path in native format
	string pathout = parseFilePath(5, pathIn, "*", 1, 0)
	
	//Remove the ipf file (this might make it windows only?)
	pathout = parseFilePath(1,pathout,"\\",1,0)
	
	//Tack on the relative path	
	string relPath = parseFilePath(5,relativePathString,"*",1,0)
	pathout += relPath
	
	return pathout
	
End
//Initialize all dependencies
//Initially tried to load all of the ipf files, but I couldn't get it to work
//Need to add your ipf file to the include
Function initializeCryptidPackages()

	//Initialize the base packages first
	InitSearch(ShowUserInterface=0)
	InitializeExperimentInfo()

	//Initialize packages listed in "PackageList" wave...
	
	//Load the package files
//	NewPath/Q/O mainPath getCryptidPath("Packages:")
	
	wave/t packageList = generateCryptidPackageList()
//	print wave2list(packageList,0)
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
	
	variable maxIter = dimsize(packageList,0)
	Variable i
	for (i=0; i<maxIter; i+=1)
		string packageName = packageList[i]
		
		//Make the data folder
		newDataFolder/O $"root:Settings:"+packageName
		
		setDataFolder $"root:Settings:"+packageName
		
		//Add the executables to the list (so we know which functions to call for the package
		
		loadCryptidSettings(packageName,"Executables")

		wave/t executables

		//Make executables if empty, else concatanate
		if (dimsize(experimentExecutables,0) == 0)
			duplicate/O/T executables experimentExecutables
		else
			concatenate/DL/T/NP=0 {executables,experimentExecutables}, temp
			duplicate/T/O temp experimentExecutables
			killWaves/Z temp
			print "Loaded package: "+packageName
		endif
		
	Endfor


End

//Tells you if something is done saving to disk
Function savedToDisk(fileName)

	string fileName
	
	pathInfo saveForce
	string savedWavesList =  indexedFile(saveForce,-1,".ibw")
	
	if (FindListItem(fileName,savedWavesList) == -1)
		return 0
	else
		return 1
	endif
End



//Returns a wave containing all packages foudn in the packages folder
//exludes some packages that are "built-in"
Function/Wave generateCryptidPackageList()

	string path = getCryptidPath("Packages:")
	newPath/O/Q packagePath path
	
	string packageListString = indexedDir(packagePath,-1,0)
	
	String mainPackageList = "Cryptid;ExamplePackage;ExperimentInfo;SearchGrid;"
	Variable packageNumber = ItemsInList(packageListString) - itemsInList(mainPackageList)

	string startDF = getDataFolder(1)
	setDataFolder root:Settings:Cryptid
	
	//Start by removing the default packages
	packageListString = removeFromList(mainPackageList, packageListString)
	
	Make/O/T/N=(packageNumber) packageList
	Variable maxIter = packageNumber
	Variable i
	for(i=0;i<maxIter;i+=1)
		packageList[i] = StringFromList(i, packageListString)
	endFor
	
	
	setDataFolder $startDF
	
	return packageList
	
End

//Makes a folder for the desired step
Function cryptidMakeExperimentFolder(folderName)
	string folderName
	
	newDataFolder/O $"root:Settings:Cryptid:workingFolders:"+folderName
	
End

//Returns all of the experiment options
Function/s cryptidAllExperimentNamesList()

	wave/t settings = getCryptidSettings(1)
	
	return settings[%experimentList]

End

//Makes a settings panel next to the cryptid panel
//Mostly used for Search for molecule, not used for general packages
Function makeSearchPanel(panelName)

	string panelName
	 
	wave/t tSettings = getCryptidSettings(1)
	
	string executeString = panelName+"(\""+tSettings[%DynamicpanelName]+"\",\""+tSettings[%settingsPanelName]+"\")"
	
	if(windowExists(tSettings[%DynamicpanelName]+"#"+tSettings[%settingsPanelName]))
		killWindow $tSettings[%DynamicpanelName]+"#"+tSettings[%settingsPanelName]
	endif
	
	 cryptidDebug(diagString="Executing Panel: "+executeString)
	 execute executeString
 
//	 doWindow/F $panelName
	
End

//Appropriate starting dimensions for a settings panel
Function newPanelDims(dimType)
	
	variable dimType
	wave/t tSettings = getCryptidSettings(1)
		
	//Make the panel in the cryptidOne
	getWindow $tSettings[%DynamicpanelName] wSizeOuterDC
	variable returnValue
	
	Switch(dimtype)
		case 0:
			returnValue = v_left+10
			break
		case 1:
			returnValue = v_top+20
			break
		case 2:
			returnValue = 280
			break
		case 3:
			returnValue = 700
			break
	EndSwitch


	return returnValue

End
	
//Make settings waves if not saved externally
Function makeCryptidSettingsWaves()
	
	//Debug variable
	variable/G cryptidDBugMode = 0
	
	make/O/T/N=0 root:Settings:Cryptid:stdOut
	
	make/O/N=(0,2) root:Settings:Cryptid:stackSelWave
	make/O/N=(0,2)/T root:Settings:Cryptid:experimentStack
	setDimLabel 1, 0, Name, root:Settings:Cryptid:experimentStack
	setDimLabel 1, 1, Iter, root:Settings:Cryptid:experimentStack
	
	make/O/N=0 root:Settings:Cryptid:workingForce
	make/O/N=0 root:Settings:Cryptid:workingZSensor
	
	make/O/N=(0,6)/T root:Settings:Cryptid:ExperimentExecutables
	wave/t extEx = root:Settings:Cryptid:ExperimentExecutables
	setDimLabel 1, 0, Name, extEx
	setDimLabel 1, 1, PanelFunction, extEx
	setDimLabel 1, 2, vWaveSetup, extEx
	setDimLabel 1, 3, tWaveSetup, extEx
	setDimLabel 1, 4, initializationFunction, extEx
	setDimLabel 1, 5, executeCommand, extEx
	
	//These waves are for storing the first ramp info in an easily accessible place
		
	//Make the waves if they don't exist (should move this elsewhere
	make/O/N=0 root:Settings:Cryptid:FRDeflVolts
	make/O/N=0 root:Settings:Cryptid:FRZSensorVolts
	make/O/N=0 root:Settings:Cryptid:FRrampSettings
	make/O/N=0 root:Settings:Cryptid:FRtriggerInfo


End

//Make the necessary folder structure
Function makeCryptidFolderStructure()

	//Settings Data folder
	newDataFolder/O root:Settings
	
	//Settings folder for the main window
	newDataFolder/O root:Settings:Cryptid
	
	//Make the folder that will house all the of experiment settings
	if(dataFolderExists("root:Settings:Cryptid:WorkingFolders"))
		killDataFolder root:Settings:Cryptid:WorkingFolders
	endif
	
	newDataFolder/O root:Settings:Cryptid:WorkingFolders

	//Make a data folder to store all of the waves from this run
	newDataFolder/O root:Settings:Cryptid:currentRunWaves

End

//Type is 0 for zSensor and 1 for deflVolts
Function putWaveInCurrentRunStorage(thisWave, saveName, type)

	wave thisWave
	string saveName
	variable type
	
	if (stringMatch(saveName[strlen(saveName)-1], "_"))
		saveName = saveName[0,strlen(saveName)-2]
	endif
	
	if (type == 1)
		saveName = "d_"+saveName
	else
		saveName = "z_"+saveName
	endif
	
	string newWaveLoc = "root:Settings:Cryptid:currentRunWaves:"+saveName
	duplicate/O thisWave $newWaveLoc

End

//Handling of the stack wave
Function/Wave getCryptidStack()

	wave/t cryptidStack = root:Settings:Cryptid:experimentStack
	return cryptidStack

End

//Load saved settings files
Function loadCryptidSettings(location, names, [useCurrentDF,noDebug])
	
	string location, names
	Variable useCurrentDF, noDebug
	
	if (paramIsDefault(noDebug))
		noDebug = 0
	endif
	
	if(paramIsDefault(useCurrentDF))
		useCurrentDF=0
	endif

	if(!useCurrentDF)
		String startDF = getDataFolder(1)
		String newDF = "root:Settings:" + location
		setDataFolder $newDF
	endif
	
	String pathIn = getCryptidPath("Packages:"+location+":Settings:")
	
	NewPath/Q/O mainPath pathIn
	if (!noDebug)
		cryptidDebug(diagString="Loading "+names+" From: "+pathIn)
	endif
	Variable i
	Variable numberOfWaves = itemsInList(names)
	
	for (i=0;i<numberOfWaves;i+=1)
		String name = stringFromList(i,names) + ".ibw"
		LoadWave/H/Q/O/P=mainPath name
	endfor
	
	if(!useCurrentDF)
		setDataFolder $startDF
	endif
	

	if (v_flag && !noDebug)
		cryptidDebug(DiagString="Error: "+num2str(v_flag))
	endif
End

//Saves a crytpid wave to the appropriate place in the given package
Function saveCryptidSetting(wave2Save, [packageName])

	Wave wave2Save
	string packageName
	
	if(paramIsDefault(packageName))
		packageName = "Cryptid"
	endif
	
	String pathIn = getCryptidPath("Packages:"+packageName+":Settings:")
	NewPath/Q/O mainPath pathIn
	
	Save/O/P=mainPath wave2Save
End

//Brings the window forward if it exist
Function showCryptidWindow()
	
	Wave/t tSettings = getCryptidSettings(1)
	
	doWindow/F $tSettings[%panelName]
//	moveWindow ADD movewindow command to move it to 0, 0, somex, somey
//ALSO: CHANGE SAVE NAME TO ONLY USE SUCESSFUL RUN COUNT SO IT STOPS BREAKING
	if (!windowExists(tSettings[%panelName]))
		execute "CryptidPanel()"
	endif

End

//Adds a step to the list
Function cryptidAddStep([expType, position,iter])
	
	string expType,iter
	variable position
	cryptidDebug()
	if(paramIsDefault(iter))
		iter="1"
	endif
	
	if(paramIsDefault(expType))
		//expType=getCStr("addStepPopup")
		//Assume called from context menu
		GetLastUserMenuInfo
		expType = s_Value
	endif
	
	wave/t cryptidStack = getCryptidStack()
	if(paramIsDefault(position))
		position=dimsize(cryptidStack,0)
	endif
	
	wave stackSelWave = root:Settings:Cryptid:stackSelWave

	string stepname = expType+"_"+num2str(position)
	
	InsertPoints/M=0 position, 1, cryptidStack, stackSelWave
	
	//Update IDs first
	updateStackIDs(position=position+1)
	
	//Add the new step
	cryptidStack[position][%Name] = stepName
	cryptidStack[position][%Iter] = iter
	stackSelWave[position][0]=0
	stackSelWave[position][1]=2

	setDimLabel 0, position, $stepName, cryptidStack
	
	//Make the folder
	initializeCryptidExperiment(stepName)
	
	//Make it the new selection
	stackSelWave[*][0] = 0
	stackSelWave[position] = 1

	//Replace the panel
	replaceSettingsPanel(stepName)
End

Function/S getSelectedStepName([stepNum])

	variable stepNum
	if (paramIsDefault(stepNum))
		stepNum = getSelectedStep()
	endif
	
	wave/T CStack = getCryptidStack()
	
	return CStack[stepNum][%Name]
End

//This function will initialize a package inside the DF of another
//Useful for running, say, centering inside of a force clamp
Function initializeSubModule(expType)
	String expType
	string currentDF = getDataFolder(0)
	string currentDFFull = getDataFolder(1)
	newDataFolder/S $expType
	
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
	wave/t tSettings = getCryptidSettings(1)

	//make the settings waves
	execute experimentExecutables[%$expType][%tWaveSetup]
	execute experimentExecutables[%$expType][%vWaveSetup]
	
	//Make the panel as a popout panel
	string windowName = currentDF+"_"+expType
	string execString = experimentExecutables[%$expType][%panelFunction]+"(PanelName=\""+windowName+"\", windowName=\""+windowName+"\")"

	execute execString
	
	setDataFolder $currentDFFull
End

//Initializes the named experiment
Function initializeCryptidExperiment(stepName)

	string stepName
	newDataFolder/O $"root:Settings:Cryptid:WorkingFolders:"+stepName
	setDataFolder  $"root:Settings:Cryptid:WorkingFolders:"+stepName
	
	string expType = getStepType(stepName=stepName)
	
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
	wave/t tSettings = getCryptidSettings(1)

	//make the settings waves
	execute experimentExecutables[%$expType][%tWaveSetup]
	execute experimentExecutables[%$expType][%vWaveSetup]
	
	cryptidMakePanel(stepName)


End


Function cryptidMakePanel(stepName)

	string stepName
	
	setWorkingFolder(stepName)
	
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")	
	wave/t tSettings = getCryptidSettings(1)
	string expType = getStepType(stepName=stepName)
	string panelFuncName = experimentExecutables[%$expType][%PanelFunction]

	doWindow/F $tSettings[%DynamicPanelName]
	string executeStr = panelFuncName+"("+"WindowName=\"" + stepName +"\",panelName=\""+stepName+"\",hostName=\""+tSettings[%DynamicpanelName]+"\")"
	cryptidDebug(diagString=executeStr)
	
	execute executeStr
	
	replaceSettingsPanel(stepName)

End


Function CryptideTab(tca) : TabControl
	STRUCT WMTabControlAction &tca

	switch( tca.eventCode )
		case 2: // mouse up
			Variable tab = tca.tab
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End



Function CryptidCheckBox(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			string ctrlName = cba.ctrlName
			
			wave vSettings = getCryptidSettings(0)
			vSettings[%$ctrlName] = checked
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


//Replaces the settings panel with a new one
//Couldn't figure out how to hide/disable a subWindow, so I just make the unused ones zero pixels big and move them to the side
Function replaceSettingsPanel(panelName)

	string panelName
	wave/t tSettings = getCryptidSettings(1)

	string mainPanelName = tSettings[%dynamicPanelName]
	
	doWindow/F $mainPanelName
	string fullOldName =mainPanelName+"#"+tSettings[%previousSelName]
	string fullNewName = mainPanelName+"#"+panelName
	
	//Couln't seem to hide the windows. This is how I'm getting around it
	if(windowExists(fullOldName))
		moveSubWindow/W=$fullOldName fNum=(1,1,1,1)
	endif
	
	//moveSubWindow/W=$fullNewName fNum=(0,0,0.2345,0.98)
	moveSubWindow/W=$fullNewName fNum=(0,0,0.43,0.99)
	SetActiveSubwindow $fullNewName

	tSettings[%previousSelName] = panelName

End


Function renameCryptidStep()

	Wave/t cryptidStack = getCryptidStack()
	Variable selStep = getSelectedStep()
	
	String currentName = cryptidStack[selStep][%name]
	
	String newName
	prompt newName, "Enter new name: "
	doPrompt  "Change Step Name", newName
	
	//Change the name in the stack
	cryptidStack[selStep][%name] = newName	
	
	//Change the name of the DF
	setDataFolder root:
	renameDataFolder $"root:Settings:Cryptid:WorkingFolders:"+currentName $newName
	
	wave/t tSettings = getCryptidSettings(1)
	string oldWindowName = tSettings[%DynamicpanelName]+"#"+currentName
	//Rename the window
	renameWindow $oldWindowName, $newName

End

Function DNACalibrate([DNA, DNAZSensor])

	Wave DNA
	Wave DNAZSensor
	
	if (paramIsDefault(DNA))
		wave DNA = waveRefIndexed("ForceReviewGraph",1,1)
	endif
	if (paramIsDefault(DNAZSensor))
		wave DNAZSensor =  waveRefIndexed("ForceReviewGraph",1,2)
	endif
	
	
	duplicate/O DNA root:DNACalibration
	duplicate/O DNAZSensor root:DNACalibrationZSensor
	duplicate/O DNA root:DNAZero
	wave DNAZero = root:DNAZero
	duplicate/O DNA root:DNAFit0
	wave DNAFit0 = root:DNAFit0
	duplicate/O DNA root:DNAFit1
	wave DNAFit1 = root:DNAFit1
	duplicate/O DNA root:DNAFit2
	wave DNAFit2 = root:DNAFit2
	
	string DNAWindowName = "DNACalibrateWindow"
	
	
	variable A = min(pcsr(A,DNAWindowName),pcsr(B,DNAWindowName))
	variable B = max(pcsr(A,DNAWindowName),pcsr(B,DNAWindowName))
	
	variable C = min(pcsr(C,DNAWindowName),pcsr(D,DNAWindowName))
	variable D = max(pcsr(C,DNAWindowName),pcsr(D,DNAWindowName))
	
	variable E = min(pcsr(E,DNAWindowName),pcsr(F,DNAWindowName))
	variable F = max(pcsr(E,DNAWindowName),pcsr(F,DNAWindowName))
	
	variable G = min(pcsr(G,DNAWindowName),pcsr(H,DNAWindowName))
	variable H = max(pcsr(G,DNAWindowName),pcsr(H,DNAWindowName))
	
	//Fit line to AB to get zero
	waveStats/Q/R=[A,B] DNA
	variable zeroV = v_avg
	DNAZero = v_avg
	killWaveStats()
	
	//fit line to CD, EF, GH
	CurveFit/Q/M=2/W=0 line,DNA[C,D]
	
	wave w_coef
	duplicate/o W_coef CDCoef
	DNAFit0 = w_coef[0] + w_coef[1]*x
	
	CurveFit/Q/M=2/W=0 line,DNA[E,F]
	DNAFit1 = w_coef[0] + w_coef[1]*x
	duplicate/o W_coef EFCoef
	CurveFit/Q/M=2/W=0 line,DNA[G,H]
	DNAFit2 = w_coef[0] + w_coef[1]*x
	duplicate/o W_coef GHCoef
	
	removeFromGraph/Z DNAZero, DNAFit0, DNAFit1, DNAFit2
	appendtograph/W=$DNAWindowName/c=(0,0,0) DNAZero
	appendtograph/W=$DNAWindowName/c=(0,0,0) DNAFit0
	appendtograph/W=$DNAWindowName/c=(0,0,0) DNAFit1
	appendtograph/W=$DNAWindowName/c=(0,0,0) DNAFit2
	
	//Calculate intersections
	Variable CDEF = (CDCoef[0]-EFCoef[0])/(EFCoef[1]-CDCoef[1])
	Variable EFGH = (GHCoef[0]-EFCoef[0])/(EFCoef[1]-GHCoef[1])
	
	Variable mid = (CDEF+EFGH) / 2
	Variable deflV = abs( EFCoef[0]+EFCoef[1]*mid - zeroV)
	
	Variable SC = SCDNATherm(deflV)
	Variable invols = involsDNATherm(deflV)
	
	print "\rDNA Calibration\r--------------------------------------------\r Spring Constant: "+num2str(SC*1000)+" pN/nm\r Invols: "+num2str(invols*10^9)+" nm/V"

End

//For now, saving entire Settings folder. Probably a better way to do this, but this works
Function cryptidSaveExperiment()
	
//	string expName
//	prompt expName, "Name of Experiment?"
//	doPrompt "Save...", expName
	
//	if (v_flag)
//		return 0
//	endif
	
//	expName += ".pxp"
	
	string savePath = getCryptidPath("SavedExperiments:")

	newPath/O tempSavePath savePath
	
	string startDF = getDataFolder(1)
	
	killDataFolder/Z root:tempSettings

	//What do we want to save?
	//Make a temp directory which compies settings
	newDataFolder/S/O root:tempSettings
	
	//Move the waves we wish to save
	//SearchGrid Settings
	newDataFolder/S/o searchGrid
	duplicate/o root:Settings:SearchGrid:SearchSettings searchSettings

	//ExperimentInfo experimentTemplate
	newDataFolder/S/O root:tempSettings:ExperimentInfo
	duplicate/O root:Settings:experimentInfo:experimentTemplate experimentTemplate

	//experimentStack
	//stackSelWave
	//Everything in WorkingFolders
	newDataFolder/S/O root:tempSettings:Cryptid
	duplicate/O root:Settings:Cryptid:stackSelWave stackSelWave
	duplicate/O root:Settings:Cryptid:experimentStack experimentStack
	DuplicateDataFolder root:Settings:Cryptid:WorkingFolders, root:tempSettings:Cryptid:WorkingFolders

	setDataFolder root:tempSettings
	SaveData/I/O/Q/R/P=tempSavePath
		
	killDataFolder/Z root:tempSettings
	
	setDataFolder $startDF

End

//Loads a previously saved experiment
Function cryptidLoadExperiment()

	//Hit stop now to fully retract, as grid will be changed
//	cryptidStop()

	string loadPath = getCryptidPath("SavedExperiments:")
	wave/t tSettings = getCryptidSettings(1)
	setDataFolder root:Settings:
	newPath/O TemploadPath loadPath
	wave/t cryptidStack = getCryptidStack()
	
	//Save cantilever
	wave/t ETSettings = root:Settings:ExperimentInfo:experimentTemplate
	string cantileverName = ETSettings[%Cantilever]
	
	killDataFolder/Z root:tempSettings
	newDataFolder/O/S root:tempSettings
	LoadData/I/O/Q/R/P=tempLoadPath
	
//	if (v_flag)
//		return -1
//	endif
	
	//Prompt if we want to change the grid and the experiment info
	variable loadGrid = 1
	variable loadExperimentInfo = 1
	prompt loadGrid, "Load grid?		"
	prompt loadExperimentInfo, "Load experiment info?	"
	doPrompt "Load options", loadGrid, loadExperimentInfo
	
	if(v_flag)
		return 1
	endif
	
	//Try to kill WorkingFolders first, to see if things are open
	killDataFolder/Z root:Settings:Cryptid:WorkingFolders
	
	if (v_flag)
		doAlert 0, "Please close all graphs and tables and try again"
		return -1
	endif
	
	
	//Kill all current subwindows
	replaceSettingsPanel(tSettings[%settingsPanelName])
	variable i 
	for (i=0;i<dimSize(cryptidStack,0);i+=1)
		string subWindowName = tSettings[%DynamicpanelName]+"#"+cryptidStack[i]
		if (windowExists(subWindowName))
			killWindow $subWindowName
		endif
	endFor
	
	if (loadGrid)
		setDataFolder root:Settings:SearchGrid
		
		wave searchSettings
		//Keep some things
		variable coarseSpotNumber = searchSettings[%coarseSpotNumber]
		variable SpotNumber = searchSettings[%spotNumber]
		variable fineSpotNumber = searchSettings[%fineSpotNumber]
		
		//Move all the data to the appropriate location
		duplicate/O root:tempSettings:SearchGrid:SearchSettings, root:Settings:SearchGrid:SearchSettings
		
		wave searchSettings
		 searchSettings[%coarseSpotNumber] = coarseSpotNumber 
		searchSettings[%spotNumber] = SpotNumber
		searchSettings[%fineSpotNumber] = fineSpotNumber
	endif
	
	if (loadExperimentInfo)
		//ExperimentInfo experimentTemplate
		setDataFolder root:Settings:experimentInfo
		duplicate/O root:tempSettings:experimentInfo:experimentTemplate experimentTemplate
	endif
	
	
	//Everything in WorkingFolders and selWave and expStack
	setDataFolder root:Settings:Cryptid
	duplicate/O root:tempSettings:Cryptid:stackSelWave stackSelWave
	duplicate/O root:tempSettings:Cryptid:experimentStack experimentStack
	DuplicateDataFolder root:tempSettings:Cryptid:WorkingFolders, root:Settings:Cryptid:WorkingFolders
	
	tSettings[%previousSelName] = tSettings[%settingsPanelName]
	//Make all of the settings panels
	for (i=0;i<dimSize(cryptidStack,0);i+=1)
		cryptidMakePanel(cryptidStack[i])
	endFor
	
	replaceSettingsPanel(tSettings[%settingsPanelName])
	
	//Update controls
	ControlUpdate/A/W=$tSettings[%DynamicpanelName]
	
	wave/t ETSettings2 = root:Settings:ExperimentInfo:experimentTemplate
	ETSettings2[%Cantilever] = cantileverName
	
	if (loadGrid)
		//Update the grid parameters and reset
		MakeCoarseGrid()  
		initSearch(showUserInterface=0,justReset=1)  	
		Wave CurrentX = root:Settings:SearchGrid:CurrentX
 		Wave CurrentY= root:Settings:SearchGrid:CurrentY
		MakeFineGrid(CurrentX[0],CurrentY[0])
	endif
	
	
	killDataFolder/Z root:tempSettings
	
	//Now go through and check all of the settings are up to date
	checkAndFixOldSettingsWaves()

End

//Removes a step from the stack and redoes the IDs
Function cryptidRemoveStep(stepNum, [numOfSteps])

	variable stepNum, numOfSteps
	
	if(paramIsDefault(numOfSteps))
		numOfSteps=1
	endif
	replaceSettingsPanel(getCStr("SettingsPanelName"))
	wave stackSelWave = root:Settings:Cryptid:stackSelWave
	wave/t cryptidStack = getCryptidStack()
	//Switch settingsPanel to searchGrid to enable deleting folder
	doWindow/F $getCStr("settingsPanelName")
	
	//Delete folder
	string stepName = cryptidStack[stepNum][%Name]
	cryptidDebug(DiagString="Killing Data Folder: "+getWorkingFolder(stepName))
	killDataFolder/Z $getWorkingFolder(stepName)
	
	if (v_flag)
		cryptidDebug(diagString="Error: Couldn't kill data folder, close tables and try again",alwaysPrint=1,alert=1)
		return -1
	endif
	
	//Remove from stack
	DeletePoints/M=0 stepNum, numOfSteps, cryptidStack, stackSelWave
	
	//Kill the window
	string windowName = getCStr("DynamicPanelName")+"#"+stepName
	killWindow $windowName
	
	//rename stack names and folder ids
	updateStackIDs()	
	

End

//Updates the stack IDs so that the 0 position is always _0, 1 _1, ect...
Function updateStackIDs([position])

	Variable position
	
	if(paramIsDefault(position))
		position=0
	endif
	//Switch to grid view
//	makeSettingsPanel("search_panel")
	cryptidDebug()
	//get stack
	wave/t cryptidStack = getCryptidStack()
	wave/t tSettings = getCryptidSettings(1)
	
	//rename stack values and folders
	Variable maxIter = dimsize(cryptidStack,0) 
	Variable i

	duplicate/O/T cryptidStack tempStack
	
	//Make a wave tempStack with the same info, but new names
	//Also, rename data folders and windows to temp_i
	for(i=position;i<maxIter;i+=1)
		String OGName = cryptidStack[i][%Name]
		
		//Remove Id and replace with new one (if there is one)
		Variable underPos = strSearch(OGName,"_", strlen(OGName)-1,3)
		if (underPos != -1)
			tempStack[i][%Name] = OGName[0,underPos]+num2str(i)
		else
			tempStack[i][%Name] = OGName
		endif
		
		//Do the same for the label (seperate to preserve stepType if name is changed)
		String OGLabel = getDimLabel(cryptidStack, 0, i)
		underPos = strSearch(OGLabel,"_", strlen(OGLabel)-1,3)
		String newLabel = OGLabel[0,underPos]+num2str(i)
		setDimLabel 0, i, $newLabel, tempStack
		
		renameDataFolder $getWorkingFolder(OGName) $"temp_"+num2str(i)
		
		string panelName = getCStr("DynamicPanelName")
		renameWindow $panelName+"#"+OGName $"temp_"+num2str(i)
		
		//Update previousSel if needed
		if (stringMatch(OGName,tSettings[%previousSelName]))
			tSettings[%previousSelName] = "temp_"+num2str(i)
		endif
	endFor
	
	//Now rename the temp dataFolder names and window names
	for(i=position;i<maxIter;i+=1)
		
		renameDataFolder $getWorkingFolder("temp_"+num2str(i)) $tempStack[i][%Name]

		panelName = getCStr("DynamicPanelName")
		renameWindow $panelName+"#"+"temp_"+num2str(i) $tempStack[i][%Name]
		
		//Update previousSel if needed
		if (stringMatch("temp_"+num2str(i),tSettings[%previousSelName]))
			tSettings[%previousSelName] = tempStack[i][%Name]
		endif
	endFor

	Duplicate/O/T tempStack CryptidStack
	killWaves/z tempStack

	
End

Function CryptidTab(tca) : TabControl
	STRUCT WMTabControlAction &tca

	switch( tca.eventCode )
		case 2: // mouse up
			Variable tab = tca.tab
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function CryptidSetVariable(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva

	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
		case 3: // Live update
			Variable dval = sva.dval
			String sval = sva.sval
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End



/////////////////////////////////////////////////

//returns the value of a string setting from a specific package
Function/S getCStr(settingName,[package])
	
	string settingName, package
	
	if(paramIsDefault(package))
		package="Cryptid"
	endif
	
	wave/t tSettings = getCryptidSettings(1,package=package)
	
	if (findDimLabel(tSettings, 0, settingName) == -2)
		print "GetCStr "+settingName+" not found"
		return ""
	endif
	
	return tSettings[%$settingName]

End

//set a string from a specific package
Function/S setCStr(settingName, value,[package])
	
	string settingName, package, value
	
	if(paramIsDefault(package))
		package="Cryptid"
	endif
	
	wave/t tSettings = getCryptidSettings(1,package=package)
	
	if (findDimLabel(tSettings, 0, settingName) == -2)
		print "GetCStr "+settingName+" not found"
		return ""
	endif
	
	tSettings[%$settingName] = value
	
	return value

End



//returns a setting
Function getCVar(settingName,[package])
	
	string settingName, package
	
	if(paramIsDefault(package))
		package="Cryptid"
	endif
	
	wave vSettings = getCryptidSettings(0,package=package)
	
	if (findDimLabel(vSettings, 0, settingName) == -2)
		print "GetCVar "+settingName+" not found"
		return 0
	endif
	
	return vSettings[%$settingName]

End

//set a setting
Function setCVar(settingName, value,[package])
	
	string settingName, package
	variable value
	if(paramIsDefault(package))
		package="Cryptid"
	endif
	
	wave vSettings = getCryptidSettings(0,package=package)
	
	if (findDimLabel(vSettings, 0, settingName) == -2)
		print "GetCVar "+settingName+" not found"
		return 0
	endif
	
	vSettings[%$settingName] = value
	
	return 1

End

Function getCurrentStepNumber()

	return getCVar("currentStep")

End

Function/S getCurrentStepName()

	//wave/t cryptidStack = getCryptidStack()
	//string returnString = cryptidStack[getCurrentStepNumber()][%Name]
	
	//Changing to just return name of DF
	
	return getDataFolder(0)
	
End

Function/S currentStepType()

	return getStepType()

End

Function/S setWorkingFolder(panelName)

	string panelName
	setDataFolder $"root:Settings:Cryptid:WorkingFolders:"+panelName
	
	return "root:Settings:Cryptid:WorkingFolders:"+panelName+":"
End

Function/S getWorkingFolder(stackName)

	string StackName
	return "root:Settings:Cryptid:WorkingFolders:"+stackName+":"

End

Function/Wave getPanelSettings(panelName,type)

	string panelName
	Variable type
	
	setWorkingFolder(panelName)
	
	if(type)
		wave tSettings
		return tSettings
	else
		wave vSettings
		return vSettings
	endif

End

Function getSelectedStep()

	variable currentSel = getCVar("currentSel")
	
	return currentSel

End


Function CryptidListBox(lba) : ListBoxControl
	STRUCT WMListboxAction &lba

	Variable row = lba.row
	Variable col = lba.col
	WAVE/T/Z listWave = lba.listWave
	WAVE/Z selWave = lba.selWave

	switch( lba.eventCode )
		case -1: // control being killed
			break
		case 1: // mouse down
			
			//Add contextual menu
			Variable isRightClick = lba.eventMod %& 0x10
			if(isRightClick)
				PopupContextualMenu/N "stackMenu"
			endif
		
			break
		case 3: // double click
			break
		case 4: // cell selection
			
			
			wave/t cryptidStack = getCryptidStack()
			wave vSettings = getCryptidSettings(0)
			wave/t tSettings = getCryptidSettings(1)
			
			
			//Fix for bug that happened when you clicked in the listbox, not on an item
			if (row > dimsize(cryptidStack,0)-1)
				return 0
			endif
			
			vSettings[%currentSel] = row
			string panelName =cryptidStack[row][%Name]
			
			//Taken out for now, was causing bug
			tSettings[%currentSelName]=  panelName
			
			replaceSettingsPanel(panelName)
			
			tSettings[%previousSelName] = panelName
			
			//I think this will help?
			setWorkingFolder(panelName)
			break
		case 5: // cell selection plus shift key
			break
		case 6: // begin edit
			break
		case 7: // finish edit
			break
		case 13: // checkbox clicked (Igor 6.2 or later)
			break
	endswitch

	return 0
End


//For debugging
//Spren Debug
Function CryptidDebug([diagString, alwaysPrint, alert, updateDisplay,message, stopCryptid])

	string diagString
	variable alwaysPrint, alert, updateDisplay,message, stopCryptid
	
	if(paramIsDefault(message))
		message=0
	endif
	
	if(paramIsDefault(stopCryptid))
		stopCryptid=0
	endif
	
	if(paramIsDefault(alwaysPrint))
		alwaysPrint=0
	endif
	
		if(paramIsDefault(updateDisplay))
		updateDisplay=0
	endif
	
	if(paramIsDefault(alert))
		alert=0
	endif
	
	if (paramIsDefault(diagString))
		diagString = ""
	endif
	
	Wave cryptidSettings = root:Settings:Cryptid:vSettings
	if (!WaveExists(cryptidSettings))
		variable debugMode = 0
	else
		debugMode = cryptidSettings[%CryptidDebug]
	endif
	
	if (alwaysPrint || debugMode)
		print GetRTStackInfo(2)+" "+time()+"\r"
		print "_____________________________\r"
		print diagString+"\r\r\r"
		
	endif
	
	if (stopCryptid)
		cryptidStop()
		message = 1
	endif
	
	if (updateDisplay)
		updateStatus(diagString)
	endif
	
	if (message)
		discordMessage(diagstring)
	endif
	
	if (alert)
		doAlert 0, "Cryptid: "+diagString
	endif
	
End

Function cryptidSaveWaves(DefVolts,ZSensorVolts,[FC, saveName,save2memory])

	Wave defVolts, zSensorVolts
	Variable FC, save2memory
	string saveName
	
	//Allow saving without ZSensorVolts
	variable noZ = 0
	if(!WaveExists(ZSensorVolts))
		noZ = 1
	endif
	
	//FC Taking a really long time in 16. Try to fix...
	cryptidDebug()
	if (paramIsDefault(FC))
		FC = 0
	endif
	
	if (paramIsDefault(save2memory))
		if (FC)
			save2memory = 0
		else
			save2memory = 1
		endif
	endif
	
	if (paramIsDefault(saveName))
		saveName = getCurrentStepName()+"_"
	endif
	
	wave/t  tSettings = getCryptidSettings(1)
	wave vSettings = getCryptidSettings(0)
	wave searchSettings = root:Settings:SearchGrid:SearchSettings
	
	//If this is a repeat (using the repeat module), then alter the saved name
	if (vSettings[%repeatCounter] > 0)
		saveName = saveName+"R_"+num2str(vSettings[%repeatCounter])+"_"
	endif
	
	//Lets duplicate to not modify the OG though. Keep track to make sure this doesn't take too much time
	duplicate/O defVolts defVoltsSave
	wave deflVoltsSave
	
	if (!noZ)
		duplicate/O zSensorVolts zSensorVoltsSave
		wave zSensorVoltsSave
		
		//If stopped early, the waves my be different in sizes. Going to fix that here
		Variable numDef = numpnts(DefVoltsSave)
		Variable numZ = numpnts(zSensorVoltsSave)
		if (numDef != numZ )
			Variable resize = min(numDef, numZ)
			resize -= mod(resize, 32)
			
			redimension/N=(resize) DefVoltsSave, ZSensorVoltsSave
		Endif
		
	else
		wave ZSensorVoltsSave = $""
	endif
	
	//Might as well zero the waves while were at it
	string addedNotes = cryptidGenerateNote()
	if (!FC)
		wave vSettings = getCryptidSettings(0)

		defVoltsSave -= vSettings[%deflVOffset]
		//Add the zero information to the note
		addedNotes = ReplaceStringbyKey("DeflVOffset",AddedNotes,"0",":","\r")
		addedNotes = ReplaceStringbyKey("OGDeflVOffset",addedNotes,num2str(vSettings[%deflVOffset]),":","\r")
	
	endif


	//Do a progress window if we need to pull over fast capture
	if (FC)
		updateStatus("Saving FC...")
		if (windowExists("ProgressWindow"))
			killWindow progressWindow
		endif
		variable timer = startMSTimer
		Variable estRate =  8.08808e+06 * 1.1 //pnts per second total
		variable estTime = (dimsize(DefVoltsSave,0)+dimsize(zSensorVoltsSave,0))/estRate
		cryptidTimerProgress("Saving FC Wave", estTime)
		
	endif
		
	
	if (vSettings[%fullIterations] > 9999)
		CryptidDebug(diagString = "You've done it, ya broke it", alwaysPrint = 1,updateDisplay = 1)
		//Gotta stop until we can make a new folder some other time its late i'm tired
		wave vSettings = getCryptidSettings(0)
		vSettings[%stop] = 1
		doScanFunc("StopScan_0")
		listbox StackDisplay disable=0, win=$getCStr("DynamicPanelName")
		//updateStatus("STOPPED",error=1)
	endif
	
	if (!noZ)
		SaveAsForce(saveName, vSettings[%FullIterations],defVoltsSave,zSensorVoltsSave,additionalNotes=addedNotes,save2memory=save2memory)
	else
		SaveAsForce(saveName, vSettings[%FullIterations],defVoltsSave,$"",additionalNotes=addedNotes,save2memory=save2memory)
	endif
	if (FC)
		killWindow progressWindow
//		print "Estimated Time: "+num2str(estTime)
//		print "Actual time:" +num2str(stopMSTimer(timer)/1000000)
//		print "Numpnts: "+num2str(dimsize(defVolts,0))
	endif
		
End

Function saveAsForce(FRName,Iteration,DefVolts,ZSensorVolts,[TriggerInfo,AdditionalNotes,save2memory])
	
	String FRName,AdditionalNotes
	Variable Iteration,save2Memory
	Wave DefVolts,ZSensorVolts
	Wave/T TriggerInfo
	
	SVAR gBaseName = root:Packages:MFP3D:Main:Variables:BaseName
	wave MVW = root:Packages:MFP3D:Main:Variables:MasterVariablesWave
	
	variable noZ = 0
	if (!WaveExists(ZSensorVolts))
		noZ = 1
	endif
	
	if (paramIsDefault(save2memory))
		save2memory = 1
	endif
	
	if (noZ)
		killWaves/z zSensorVolts
		duplicate/O defVolts, root:ZSensorVolts
		wave zSensorVolts = root:ZSensorVolts
		zSensorVolts = 1
	endif
	
	If(Iteration>9999)
		Iteration=0
	EndIf
	Variable FRNameLength=strlen(FRName)
	If(FRNameLength>17)
		String NewName=FRName[0,16]
		FRname=NewName
	EndIf
	gBaseName=FRName		//take a local copy, to protect the global

	If(ParamIsDefault(TriggerInfo))
		Make/O/T TriggerInfo
		td_ReadGroup("ARC.CTFC",TriggerInfo)
	EndIf
	
	MVW[%BaseSuffix][%Value]=Iteration
	
	//////////////
	
	cryptidDebug(diagString="Before Zap")
	
	wavetransform/o zapNaNs DefVolts
	wavetransform/o zapNaNs ZSensorVolts

	cryptidDebug(diagString="Before Dup")
	duplicate/o ZSensorVolts Z_raw_save
	Variable zSens = GV("ZLVDTSens")
	Fastop Z_raw_save=(zSens)*ZSensorVolts
	SetScale d -10, 10, "m", Z_raw_save
	duplicate/o Z_raw_save Z_snsr_save
	duplicate/o DefVolts Def_save
	Variable invols = GV("invols")
	fastop Def_save=(invols)*DefVolts
	SetScale d -10, 10, "m", Def_save
	
	variable ApproachVelocity=str2num(TriggerInfo[%RampSlope1])*GV("ZPiezoSens")
	string TriggerChannel=TriggerInfo[%TriggerChannel1]
	variable TriggerSet1=str2num(TriggerInfo[%TriggerValue1])  
	variable RetractVelocity=str2num(TriggerInfo[%RampSlope2])*GV("ZPiezoSens")*-1
	string TriggerChannel2=TriggerInfo[%TriggerChannel2]
	variable TriggerSet2=str2num(TriggerInfo[%TriggerValue2])
	variable NoTrigSet=str2num(TriggerInfo[%TriggerHoldoff2])         //Fix
	string Callback=TriggerInfo[%CallBack]
	variable TriggerSetVolt1=str2num(TriggerInfo[%TriggerValue1])	 //Fix
	variable TriggerSetVolt2=str2num(TriggerInfo[%TriggerValue2])	  //Fix
	variable TriggerValue1=str2num(TriggerInfo[%TriggerPoint1])
	variable TriggerValue2=str2num(TriggerInfo[%TriggerPoint2])
	variable TriggerTime1=str2num(TriggerInfo[%TriggerTime1])
	variable TriggerTime2=str2num(TriggerInfo[%TriggerTime2])
	variable DwellTime1=str2num(TriggerInfo[%DwellTime1])
	variable DwellTime2=str2num(TriggerInfo[%DwellTime2])
	variable NoTrigTime=str2num(TriggerInfo[%TriggerHoldoff2 ])      //Fix
	variable sampleRate=1/DimDelta(DefVolts, 0 )   //This has to be updated to adapt to inputs.
	
	variable TriggerDeflection=0
		
	//TriggerValue2 shoudl be set to inf if 
		
	strswitch(TriggerChannel)  //A switch to properly define the trigger levels (in voltage) based on the channel used for the second trigger.
			
		case "Deflection":

			TriggerDeflection=TriggerValue1/1e-12*GV("InvOLS")*GV("SpringConstant") //Deflection to reach
			break
		
		default:
		
	endswitch
	
	variable dwellPoints0 = round(DwellTime1*sampleRate)   
	variable dwellpoints1=round(DwellTime2*sampleRate) 
	variable ramp2pts= round((TriggerTime2)*sampleRate)-1
	
	String Indexes = "0," //Start the index and directions 
	String Directions = "Inf,"
	variable Index = round(TriggerTime1*sampleRate)-1      //Counts out to one point less than where it triggered
	Indexes += num2istr(Index)+","
	Directions += num2str(1)+","
	
	if (DwellPoints0)

		Index += DwellPoints0
		Indexes += num2istr(Index)+","
		Directions += "0,"
	
	endif
	
	// Note from Rob on 06/16/2015
	// I tracked down the issues with a back "X" index in saving in the asylum format to this section of code
	// basically, if you use the molecule trigger, it will return a value of over 400000 if you didn't get a molecule
	// this then gets put in this giant number over 400,000 as a index for splitting the wave up.  This just prevents that from happening
	// Note from Rob on 06/22/2017
	// I had another issue pop up with a bad "x" index.  For some reason, the old way of estimating the index from trigger 2 was giving indices bigger
	// than the size of the wave.  This was freezing up the program from time to time.  I updated the code below to make sure that can't happen.
	If (TriggerTime2<400000)
		Variable EstimatedRampTrigger=Index + ramp2pts
		Variable EndIndex=dimsize(Def_save,0)-1
		If(EstimatedRampTrigger>EndIndex)
				Index = EndIndex
		Else 
			Index =EstimatedRampTrigger
		EndIf
		
		Indexes += num2istr(Index)+","
		Directions += num2str(-1)+","
	EndIf
	
	//This just lists the rest of the wave (from where the trigger fired through to the end of the wave) as a dwell. In general, this isn't a true dwell, but
	//rather the time it takes to interact with Igor, decide whether we found a molecule, and then do whatever else it is we want to do (for instance,
	//ramp toward the surface etc.
	Index=dimsize(Def_save,0)-1
	Indexes += num2istr(Index)
	// Another addition related to my correction above on 06.16.2015.  The direction is important to get right.  You have to set it for 0 in most circumstances, but -1 for the molecule trigger not engaging.
	
	//If we're checking for a trigger here, needs to be triggerTime2 and not ramp2pnts (BD)
	If (TriggerTime2<400000)
		Directions += "0"
	Else
		Directions += "-1"
	EndIf
	
	
	string CNote="" //This is a correction note for the string that the ARSaveAsForce() function is going to write when we save this as a force.
	CNote = ReplaceStringbyKey("Indexes",CNote,Indexes,":","\r")
	CNote = ReplaceStringbyKey("Direction",CNote,Directions,":","\r")
	CNote = ReplaceStringbyKey("ApproachVelocity",CNote,num2str(ApproachVelocity),":","\r")
	CNote = ReplaceStringbyKey("RetractVelocity",CNote,num2str(RetractVelocity),":","\r")
	CNote = ReplaceStringbyKey("DwellTime",CNote,num2str(DwellTime1),":","\r")
	CNote = ReplaceStringbyKey("DwellTime2",CNote,num2str(DwellTime2),":","\r")
	CNote = ReplaceStringbyKey("NumPtsPerSec",CNote,num2str(sampleRate),":","\r")
	CNote = ReplaceStringbyKey("TriggerDeflection",CNote,num2str(TriggerDeflection),":","\r")
	CNote = ReplaceStringbyKey("TriggerChannel",CNote,TriggerChannel,":","\r")
	CNote = ReplaceStringbyKey("TriggerChannel2",CNote,TriggerChannel2,":","\r")
	CNote = ReplaceStringbyKey("TriggerTime1",CNote,num2str(TriggerTime1),":","\r")
	CNote = ReplaceStringbyKey("TriggerTime2",CNote,num2str(TriggerTime2),":","\r")
	CNote = ReplaceStringbyKey("TriggerSet1",CNote,num2str(TriggerSet1),":","\r")
	CNote = ReplaceStringbyKey("TriggerSet2",CNote,num2str(TriggerSet2),":","\r")
	CNote = ReplaceStringbyKey("TriggerValue1",CNote,num2str(TriggerValue1),":","\r")
	CNote = ReplaceStringbyKey("TriggerValue2",CNote,num2str(TriggerValue2),":","\r")
	
	if (!ParamIsDefault(AdditionalNotes) && Strlen(AdditionalNotes))

		variable nop
		nop = ItemsInList(AdditionalNotes,"\r")
		String CustomItem
		Variable n,A

		for (A = 0;A < nop;A += 1)

			CustomItem = StringFromList(A,AdditionalNotes,"\r")
			//print customitem
			n = strsearch(CustomItem,":",0,2)
	
			if (n < 0)
	
				Continue
	
			endif
	
			CNote = ReplaceStringByKey(CustomItem[0,n-1],CNote,Customitem[n+1,Strlen(CustomItem)-1],":","\r",0)
		
		endfor
	
	endif
	
	//This function (eventually) applies a LP filter to the data
	//Currently, the rate of the filter seems to be ~8000 for our data (here) and 300 for an Asylum single force
	//This results in non-monotonic zSensor on our end, making things look squigley
	
	//Aylum: If no dwell, or if any dwell? localForceDist = inf
	//Asylum seems to set forceDist here to infinity no matter what? Rob used TriggerSet2
	cryptidDebug(diagString="Before Zpos")
	
	if (!noZ)
		MakeZPositionFinalCryptid(Z_Snsr_save,ForceDist=inf,indexes=indexes,DirInfo=Directions)	
	endif
	
	Variable bitSave = 3
	if (save2Memory == 0)
		bitSave = 2
	endif
	cryptidDebug(diagString="Before AR")
	
	ARSaveAsForceCryptid(bitsave,"SaveForce","Defl;ZSnsr",Z_raw_save,Def_save,Z_snsr_save,$"",$"",$"",$"",CustomNote=CNote)
	killwaves Z_raw_save, Z_snsr_save,Def_save
	
End


Function ARSaveAsForceCryptid(SaveBit,PName,DataTypeList,Wave0,Wave1,Wave2,Wave3,Wave4,Wave5,Wave6[,CustomNote])
	Variable SaveBit
	String PName, DataTypeList
	Wave Wave0
	Wave/Z Wave1, Wave2, Wave3, Wave4, Wave5, Wave6
	String CustomNote
	
	
	//Function to Save Waves as Asylum Force Plots.
	//Save Bit 0x1 = Save to Mem
	//0x2 = Save to disk
	//	PName Name of Symbolic path that you want to save to disk to.
	//DataTypeList, ; seperated list of dataTypes for Wave1,Wave2 ... Wave6 [Wave0 is always Raw]
	//	Wave0, Raw data Type, must have this wave
	//[Wave1...wave6 optional waves (if you don't have a wave pass it $"")
	
	
	Variable MaxWaves = 7
	
	
	
	Variable WaveCount = WaveExistS(Wave0)+WaveExists(Wave1)+WaveExists(Wave2)+WaveExists(Wave3)+WaveExists(Wave4)+WaveExists(Wave5)+WaveExists(Wave6)
	
	
	
	

	Variable XPos = Td_ReadValue("XSensor")
	Variable YPos = td_ReadValue("YSensor")
	
	String SavedDataFolder = GetDataFolder(1)
	String EmptyFolder = GetDF("Empty")
	SetDataFolder(BuildDataFolder(EmptyFolder))		//go somewhere quiet to work
	//if there are a lot of waves in the folder, things will get slower.




	Wave TimeWave = root:Packages:MFP3D:Force:TimeWave
	wave MVW = root:Packages:MFP3D:Main:Variables:MasterVariablesWave
	wave FVW = root:Packages:MFP3D:Main:Variables:ForceVariablesWave
	Wave RVW = root:Packages:MFP3D:Main:Variables:RealVariablesWave
	SVAR FWL = root:Packages:MFP3D:Force:ForceWavesList
	SVAR SFWL = root:Packages:MFP3D:Force:ShortForceWavesList
	SVAR gBaseName = root:Packages:MFP3D:Main:Variables:BaseName
	String BaseName = gBaseName		//take a local copy, to protect the global


	wave TVW = root:Packages:MFP3D:Main:Variables:ThermalVariablesWave
	Wave UserParms = root:Packages:MFP3D:Main:Variables:UserVariablesWave
	Wave/T GSW = $GetDF("Strings")+"GlobalStrings"
	wave XPTwave = root:Packages:MFP3D:XPT:XPTLoad
	wave AllAlias = root:packages:MFP3D:Hardware:AllAlias
//	NVAR VerDate = root:Packages:MFP3D:Main:Variables:VerDate





	Variable AllowMDB = 1
	string suffixStr = num2strlen(MVW[%BaseSuffix][0],4)
	string tempSeconds
	String DataType = ""
	String LongDataType = ""
	String NoteStr = ""
	Variable SaveNop, DataNop, SaveFactor, StartIndex, StopIndex
	String Indexes = "0,"
	String Directions = "NaN,"

	Indexes += "0,"+num2istr(DimSize(Wave0,0)-1)+","+num2istr(DimSize(Wave0,0)-1)+","
	Directions += "1,0,-1,"

	
	variable i
	variable column = 1
	

	String OfflineSubFolder = "Memory"
	
	//make sure we can still save to disk
	if (SaveBit & 0x2)
		if (!SafePathInfo(PName))			//what happened to our path!
			SaveBit = SaveBit & ~0x2
		else
			PathInfo $Pname
			OfflineSubFolder = ForceSubFolderCleanUp(LastDir(S_Path))
		endif
	endif
	
	
	

	StopIndex = WhichListItem("ZSensor",FWL,";",0,0)
	
	String DataFolder = ARGetForceFolder("",OfflineSubFolder,BaseName+SuffixStr)
	//Don't ever set to root:ForceCurves, it can get very slow when there are lots of force plots in memory
	//This also keeps the empty string input, this is the only way into the "memory" folder (besides double click loaders).
	




	Variable TheWeatherOutside = NaN, A, nop
	Variable ImagingMode = MVW[%ImagingMode][%Value]



	NoteStr = ReplaceNumberbyKey("VerDate",NoteStr,VersionNumber(),":","\r")
	NoteStr = ReplaceStringByKey("Version",NoteStr,VersionString(),":","\r")
	NoteStr = ReplaceStringByKey("XOPVersion",NoteStr,td_XopVersion(),":","\r")
	NoteStr = ReplaceStringByKey("OSVersion",NoteStr,StringByKey("OS",IgorInfo(3),":",";",0),":","\r",0)
	NoteStr = ReplaceStringByKey("IgorFileVersion",NoteStr,StringByKey("IgorFileVersion",IgorInfo(3),":",";",0),":","\r",0)
	NoteStr = ReplaceNumberByKey("XLVDT",NoteStr,td_ReadValue("XSensor")*abs(MVW[%XLVDTSens][%value]),":","\r")
	NoteStr = ReplaceNumberByKey("YLVDT",NoteStr,td_ReadValue("YSensor")*abs(MVW[%YLVDTSens][%value]),":","\r")
	SVAR/Z ForceNote = root:Packages:MFP3D:Main:Variables:ForceNote
	SVAR/Z TipSerialNumber = Root:Packages:MFP3D:Main:Variables:TipSerialNumber
	if (SVAR_EXISTS(ForceNote))
		NoteStr = ReplaceStringByKey("ForceNote",NoteStr,ForceNote,":","\r")
	endif
	If (SVAR_EXISTS(TipSerialNumber))
		NoteStr = ReplaceStringByKey("TipSerialNumber",NoteStr,TipSerialNumber,":","\r")
	endif

	noteStr += GetWaveParms(FVW)
	NoteStr = ReplaceStringByKey("TriggerChannel",NoteStr,GTS("TriggerChannel"),":","\r",0)
	NoteStr = ReplaceStringByKey("DwellRampFunc",NoteStr,GTS("DwellRampFunc"),":","\r",0)
	NoteStr = ReplaceStringByKey("DwellRampMode",NoteStr,GTS("DwellRampMode"),":","\r",0)
	NoteStr = ReplaceStringBykey("ForceMode",NoteStr,GTS("ForceMode"),":","\r",0)
	NoteStr = ReplaceStringByKey("ForceSaveList",NoteStr,GTS("ForceSaveList"),":","\r",0)
	nop = cMaxRTForceGraphs
	for (A = 0;A < nop;A += 1)
		NoteStr = ReplaceStringByKey("ForceDisplay"+num2str(A),NoteStr,GTS("ForceDisplay"+num2str(A)),":","\r",0)
	endfor
	noteStr += GetWaveParms(XPTWave)
	noteStr += GetWaveParms(MVW)
	NoteStr = ReplaceStringByKey("MicroscopeModel",NoteStr,GetMicroscopeName(MicroscopeID=MVW[%MicroscopeID][0]),":","\r",0)
	NoteStr = ReplaceStringByKey("ImagingMode",NoteStr,GTS("ImagingMode"),":","\r",0)
	NoteStr = ReplaceNumberByKey("NumPtsPerSec",NoteStr,1/DimDelta(Wave0,0),":","\r",0)
	noteStr += GetWaveParms(TVW)
	NoteStr += GetWaveParms(GSW)
	if (FVW[%ARDoIVFP][%Value])
		Wave DoIVWave = root:Packages:MFP3D:Main:Variables:ARDoIVVariablesWave
		NoteStr += GetWaveParms(DoIVWave)
		NoteStr = ReplaceStringByKey("ARDoIVFunc",NoteStr,GTS("ARDoIVFunc"),":","\r")
		Wave/Z ExtraParms = $GetDF("DoIV")+"UserParmWave"
		if (WaveExists(ExtraParms))
			for (A = 0;A < DimSize(ExtraParms,0);A += 1)
				NoteStr += "ARDoIVParm"+num2str(A+4)+":"+num2str(ExtraParms[A])+"\r"
			endfor
		endif
	endif
	NoteStr += GetWaveParms(UserParms)
	UpdateGRDNoteStr(NoteStr)
	if (ImagingMode == cFMMode)
		Wave FMVW = $cFMVW
		NoteStr += GetWaveParms(FMVW)
	endif
	NoteStr += GetWaveParms(AllAlias)
	
	NoteStr = ReplaceStringByKey("Indexes",NoteStr,Indexes,":","\r",0)
	NoteStr = ReplaceStringByKey("Direction",NoteStr,Directions,":","\r",0)
	
	
	//sprintf tempSeconds, "%u", DateTime
	tempSeconds = ARNum2Str(DateTime)
	
	//Variable Tic = StopMsTimer(-2)
	NoteStr = RemoveStringByKey(NoteStr,"StartHeadTemp",":","\r")		//to move this to bottom of note?
	NoteStr = RemoveStringByKey(NoteStr,"StartScannerTemp",":","\r")
	//print StopMsTimer(-2)-tic
	
	variable readTemp = 0
	switch (MVW[%MicroscopeID][0])

		case cMicroscopeInfinity:
		case cMicroscopeMFP3D:
	
			NoteStr = ReplaceStringByKey("StartHeadTemp",NoteStr,td_ReadString("Head.Temperature"),":","\r",0)
			NoteStr = ReplaceStringByKey("StartScannerTemp",NoteStr,td_ReadString("Scanner.Temperature"),":","\r",0)
			NoteStr = ReplaceStringByKey("StartTempSeconds",NoteStr,TempSeconds,":","\r",0)

			Struct HeaterTempParms HeaterParms
			HeaterTempNoteFunc(HeaterParms,NoteStr,SetEndTemp=false)
			HeaterTempNoteFunc(HeaterParms,NoteStr)

			readTemp = 1				//we might read temperature later
			NoteStr = ReplaceStringByKey("EndHeadTemp",NoteStr,"None Yet",":","\r",0)
			NoteStr = ReplaceStringByKey("EndScannerTemp",NoteStr,"None Yet",":","\r",0)
			NoteStr = ReplaceStringByKey("EndTempSeconds",NoteStr,"0",":","\r",0)
			break
		
		case cMicroscopeCypher:		//cypher has none of this
			
			NoteStr = RemoveByKey("StartTempSeconds",NoteStr,":","\r",0)

			NoteStr = RemoveByKey("EndHeadTemp",NoteStr,":","\r",0)
			NoteStr = RemoveByKey("EndScannerTemp",NoteStr,":","\r",0)
			NoteStr = RemoveByKey("EndTempSeconds",NoteStr,":","\r",0)
			break
			
	endswitch	
	


////////////////////
//Clean up the note







	//sprintf tempSeconds, "%u", DateTime
	tempSeconds = ARNum2Str(DateTime)
	NoteStr = ReplaceStringByKey("Date",NoteStr,ARU_Date(),":","\r",0)
	NoteStr = ReplaceStringByKey("Time",NoteStr,Time(),":","\r",0)
	NoteStr = ReplaceNumberbyKey("BaseSuffix",NoteStr,MVW[%BaseSuffix][0],":","\r",0)
	NoteStr = ReplaceStringByKey("Seconds",NoteStr,TempSeconds,":","\r",0)
	if (AllowMDB && readTemp)
		NoteStr = ReplaceStringByKey("EndHeadTemp",NoteStr,td_ReadString("Head.Temperature"),":","\r",0)
		NoteStr = ReplaceStringByKey("EndScannerTemp",NoteStr,td_ReadString("Scanner.Temperature"),":","\r",0)
		NoteStr = ReplaceStringByKey("EndTempSeconds",NoteStr,TempSeconds,":","\r",0)
		
	endif
	NoteStr = ReplaceNumberByKey("XLVDT",NoteStr,XPos*abs(MVW[%XLVDTSens][%value]),":","\r",0)
	NoteStr = ReplaceNumberByKey("YLVDT",NoteStr,Ypos*abs(MVW[%YLVDTSens][%value]),":","\r",0)
	NoteStr = ReplaceNumberByKey("DDSAmplitude",NoteStr,td_ReadValue("DDSAmplitude0"),":","\r",0)



	if (!ParamIsDefault(CustomNote) && Strlen(CustomNote))
		nop = ItemsInList(CustomNote,"\r")
		String CustomItem
		Variable Index
		for (A = 0;A < nop;A += 1)
			CustomItem = StringFromList(A,CustomNote,"\r")
			Index = strsearch(CustomItem,":",0,2)
			if (Index < 0)
				Continue
			endif
			NoteStr = ReplaceStringByKey(CustomItem[0,Index-1],NoteStr,Customitem[Index+1,Strlen(CustomItem)-1],":","\r",0)
		endfor
	endif
//Note is all set now

	
	if (SaveBit & 0x1)				//Memory
		Column = 1			//make sure it is still 1.
		OfflineFPLookup(BaseName+SuffixStr,OfflineSubFolder,1)		//add the new FP to the lookup Table.
		SetDataFolder(EmptyFolder)
		SetScale d,0,0,"m",Wave0
		Duplicate/O Wave0 $DataFolder+BaseName+suffixStr+"Raw"
		Wave Temp = $DataFolder+BaseName+suffixStr+"Raw"
		Note/K Temp
		Note Temp,NoteStr
		
		for (A = 1;A < MaxWaves;A += 1)
			Switch (A)
				case 1:
					Wave/Z Data = Wave1
					break
					
				case 2:
					Wave/Z Data = Wave2
					break
				
				case 3:
					Wave/Z Data = Wave3
					break
					
				case 4:
					Wave/Z Data = Wave4
					break
					
				case 5:
					Wave/Z Data = Wave5
					break
					
				case 6:
					Wave/Z Data = Wave6
					break
					
			endswitch
			if (!WaveExists(Data))
				continue
			endif
			
			Duplicate/O Data $DataFolder+BaseName+suffixStr+StringFromList(A-1,DataTypeList,";")
			Wave Data = $DataFolder+BaseName+suffixStr+StringFromList(A-1,DataTypeList,";")
			Note/K Data
			Note Data,NoteStr
			SetScale d,0,0,Get3DScaling(StringFromList(A-1,DataTypeList,";")),Data
		endfor
		
	endif


	Variable FileRef, SaveIndex
	String LabelStr

	
	if (SaveBit & 0x2)			//save to disk
		SaveIndex = 0
		Make/O/N=(DimSize(Wave0,0),WaveCount) $BaseName+SuffixStr
		Wave SaveWave = $BaseName+SuffixStr
		SetDimLabel 1,SaveIndex,$"Raw",SaveWave
		SaveWave[][SaveIndex] = Wave0[p]
		SaveIndex += 1
		CopyScales/P Wave0, SaveWave
		Note/K SaveWave
		Note SaveWave,NoteStr



		for (A = 1;A < MaxWaves;A += 1)
			Switch (A)
				case 1:
					Wave/Z Data = Wave1
					break
					
				case 2:
					Wave/Z Data = Wave2
					break
				
				case 3:
					Wave/Z Data = Wave3
					break
					
				case 4:
					Wave/Z Data = Wave4
					break
					
				case 5:
					Wave/Z Data = Wave5
					break
					
				case 6:
					Wave/Z Data = Wave6
					break
					
			endswitch
			if (!WaveExists(Data))
				continue
			endif

			SaveWave[][SaveIndex] = Data[P]
			SetDimLabel 1,SaveIndex,$StringFromList(A-1,DataTypeList,";"),SaveWave
			SaveIndex += 1
		endfor

		close/A

		Save/C/O/P=$Pname SaveWave

		//Put on the footer
		Open/Z/A/P=$Pname FileRef as BaseName+SuffixStr+".ibw"
		TagFPFooterCryptid(FileRef,SaveWave,UpdateOffline=0)
		Close(FileRef)
		KillWaves SaveWave
	endif
	
	
	
	IncSuffix()

	SetDataFolder(SavedDataFolder)
	ForceRealTimeUpdateOffline()
End //ARSaveAsForce

Function TagFPFooterCryptid(FileRef,Data,[UpdateOffline])
	Variable FileRef
	Wave Data
	Variable UpdateOffline

	FStatus FileRef
	if (!V_Flag)
		return(1)
	endif
	String FileName = RemoveEnding(S_fileName,".ibw")
	String PathStr = S_Path
	FSetPos FileRef, V_LogEOF
	Variable FileStart = V_LogEOF
	Variable DataLength = 128

	String TempFolder = ARGetForceFolder("Temp","","")
	BuildDataFolder(TempFolder)

	Duplicate/FREE/R=[0,DimSize(Data,0)-1][0,0] Data,XData
	Redimension/N=(numpnts(XData))/E=1 XData
	

	Make/B/U/O/N=(0) $TempFolder+"BrowseExt"/Wave=BrowseExt
	Make/B/U/O/N=(0) $TempFolder+"BrowseRet"/Wave=BrowseRet
	String DataList = GetDimLabels(Data,1)
	DataList = RemoveListItem(0,DataList,";")+StringFromList(0,DataList,";")+";"		//move the raw to the end
	DataList = ReplaceString(";",DataList,",",1)
	String IndexStr, DirectionStr
	String NoteStr = Note(Data)
	
	IndexStr = StringByKey("Indexes",NoteStr,":","\r",0)
	DirectionStr = StringBykey("Direction",NoteStr,":","\r",0)
	

	if (!Strlen(IndexStr) && !Strlen(DirectionStr))
		CalcPullIndex2(Data,-1,IndexStr,DirectionStr)
	endif
	String BrowseFooterStr = ""
	String TempStr = ""
	Variable ForceDistSign = NumberByKey("ForceDistSign",NoteStr,":","\r",0)
	
	Variable A, nop = DimSize(Data,1)
	BrowseFooterStr += "DataType:UByte;"						//these numbers are no longer hard wired
	BrowseFooterStr += "FooterVersion:0;"
	BrowseFooterStr += "ForceDir:"+num2str(ForceDistSign)+";"
	BrowseFooterStr += "DataLength:"+num2str(DataLength)+";"
	BrowseFooterStr += "IsImage:0;IsForce:1;"
	Variable DirIndex, DriveIndex0, DriveIndex1, DriveIndex2, DriveIndex3
	String BrowseStr = ""
	Variable UpdateBrowseGraph = 0
	if (ParamIsDefault(UpdateOffline))
		UpdateOffline = 0
	if (!SafePathInfo(cOfflinePName))
		if (StringMatch(FileName,"Line*Point*"))
			PathStr = Updir(UpDir(PathStr))
		endif
		NewPath/Q/Z $cOfflinePName PathStr
		UpdateOffline = 1
	else
		PathInfo $cOfflinePName
		if (StringMatch(s_Path,PathStr))
			UpdateOffline = 1
		else
			endif
		endif
	endif

	if (UpdateOffline)
		Make/N=(0,0)/O/B/U $"root:Images:Browse:"+FileName/Wave=BrowseWave
	else
		Wave/Z BrowseWave = $""
	endif
	
	
	
	for (A = 1;A <= nop;A += 1)
		if (A == nop)
			Duplicate/FREE XData,DataSlice
			
			DirIndex = WhichListItem("1",DirectionStr,",",0,0)
			DriveIndex0 = str2num(StringFromList(DirIndex,IndexStr,","))
			DriveIndex1 = str2num(StringFromList(DirIndex-1,IndexStr,","))
			
			//Bug fix
			if (driveIndex0 > (dimsize(XData,0)-1))
				driveIndex0 = dimsize(XData,0)-1
			endif
			
			XData[DriveIndex1,DriveIndex0] = P-DriveIndex1
			
			DirIndex = WhichListItem("-1",DirectionStr,",",0,0)
			DriveIndex2 = str2num(StringFromList(DirIndex-1,IndexStr,","))
			DriveIndex3 = str2num(StringFromList(DirIndex,IndexStr,","))
			
			//Bug fix
			if (driveIndex2 > (dimsize(XData,0)-1))
				driveIndex2 = dimsize(XData,0)-1
			endif
			
			XData[DriveIndex2,DriveIndex3] = (+DriveIndex0-DriveIndex1)-(P-DriveIndex2)
			
			
		else
			Duplicate/FREE/R=[0,DimSize(Data,0)-1][A,A] Data, DataSlice
		endif
		Redimension/N=(numpnts(DataSlice))/E=1 DataSlice
		
		ScaleFPBrowse(XData,DataSlice,BrowseExt,BrowseRet,IndexStr,DirectionStr,BrowseWave)
		
		if (A == 1)
			BrowseFooterStr += "ExtendLength:"+num2str(DimSize(BrowseExt,0))+";"
			BrowseFooterStr += "RetractLength:"+num2str(DimSize(BrowseRet,0))+";"
			BrowseFooterStr += "NumberOfFiles:"+num2str(nop)+";"		//put in the number of files
			BrowseFooterStr += "DataTypes:"+DataList+";"
		endif

		FBinWrite/B=3 fileRef, BrowseExt			//write the wave into the file using Wintel byte order
		FStatus fileRef										//get the file status
		sprintf tempStr, "%d", fileStart					//put the file start into a string, num2str doesn't use enough digits
		FileStart = V_FilePos
		
		BrowseFooterStr += "ExtendStart"+num2str(A)+":"+tempStr+";"
		
		FBinWrite/B=3 fileRef, BrowseRet			//write the wave into the file using Wintel byte order
		FStatus fileRef										//get the file status
		sprintf tempStr, "%d", fileStart					//put the file start into a string, num2str doesn't use enough digits
		FileStart = V_FilePos
		
		BrowseFooterStr += "RetractStart"+num2str(A)+":"+tempStr+";"
	endfor
	
	
	if (WaveExists(BrowseWave))
		SetDimLabels(BrowseWave,ReplaceString(",",DataList,";"),1)
		InsertPoints/M=1 DimSize(BrowseWave,1),1,BrowseWave		//for the tag.
		Note/K BrowseWave
		BrowseStr = BrowseFooterStr
		BrowseStr = ReplaceStringByKey("FileName",BrowseStr,FileName+".ibw",":",";")
		Note BrowseWave,BrowseStr
		FastOp BrowseWave = (0.5)*BrowseWave		//scale it to show up on the axes
		SVAR ForceDataTypeList = $InitOrDefaultString("Root:Packages:MFP3D:Main:Variables:BrowseForceDataTypeList","")
		SVAR gFDTList = root:ForceCurves:ForceDataTypeList
		SVAR gSFDTList = root:ForceCurves:ShortForceDataTypeList
		ForceDataTypeList = StarSpliceStringList(ForceDataTypeList,ListSubtract(ScaleStringList(gFDTList,gSFDTList,ReplaceString(",",DataList,";")),cBadForceBrowseList,";"))

	endif

	BrowseFooterStr += "IsForce:1;"

	sprintf tempStr, "%4.4u", strlen(browseFooterStr)+11		//put the length of the footer plus the length of the stuff still to be added into a string
	browseFooterStr += " "+tempStr+" Force"						//put the length and the ident into the string
	FBinWrite fileRef, browseFooterStr					//write the string into the file

	
End //TagFPFooter


Static Function ScaleFPBrowse(XData,YData,YBrowseExtend,YBrowseRetract,IndexStr,DirectionStr,BrowseWave)
	Wave XData, YData, YBrowseExtend, YBrowseRetract
	String IndexStr, DirectionStr
	Wave/Z BrowseWave


	//InterpolateFunc can't deal with free waves, so we have to use a global folder
	String TempFolder = ARGetForceFolder("Temp","","")
	Variable XStart = WaveMax(XData)
	Variable XStop = WaveMin(XData)
	Variable XRange = XStart-XStop

	Variable YStart = WaveMin(YData)
	Variable YRange = WaveMax(YData)-YStart
	
	
	if (!YRange)
		YRange = 1
	endif
	
	
	Variable Start, Stop, Index, BrowseIndex
	Variable B, nopB = 2, XNop
	Variable BrowseNOP// = max(DimSize(YBrowseExtend,0),DimSize(YBrowseRetract,0))
	BrowseNOP = 128	
	Variable ForwardPull = 1
	if (WhichListItem("1",DirectionStr,",",0,0) > WhichListItem("-1",DirectionStr,",",0,0))
		ForwardPull = 0
	endif
	
	FastOp YBrowseExtend = 0
	FastOp YBrowseRetract = 0

	for (B = 0;B < nopB;B += 1)
		
		Index = WhichListItem(num2str((B*2-1)*-1),DirectionStr,",",0,0)
		if (Index < 1)
			continue
		endif

		Start = str2num(StringFromList(Index-1,IndexStr,","))
		stop = str2num(StringFromList(Index,IndexStr,","))


		Duplicate/O/R=[Start,Stop] YData,$TempFolder+"YTemp"
		Wave YTemp = $TempFolder+"YTemp"

		Duplicate/O/R=[Start,Stop] XData,$TempFolder+"XTemp"
		Wave XTemp = $TempFolder+"XTemp"
		
		
		
		
		if (!numpnts(YTemp))
			continue
		endif

		Redimension/N=(numpnts(YTemp)) XTemp		//I don't know why
		//Igor just makes a mistake and gives them different number of points
		//I mean how can it do that?
		//It is generally so good about these things.
		//It might be close, I mean within 1
		//but interp needs them to be the same
		//so we force them to be the same
		

		//WaveStats/Q XTemp
		if (!B && DimSize(YBrowseExtend,0))
			XNop = DimSize(YBrowseExtend,0)
		elseif (B && DimSize(YBrowseRetract,0))
			XNop = DimSize(YBrowseRetract,0)
		else
			if (B)
				ForwardPull = !ForwardPull
			endif
			if (ForwardPull)
				Xnop = (XStart-WaveMin(XTemp))/XRange*BrowseNOP
			else
				Xnop = (WaveMax(XTemp)-XStop)/XRange*BrowseNOP
			endif
			if (B)
				ForwardPull = !ForwardPull
			endif
			if (IsNan(XNop) || (XNop < 1))
				XNop = BrowseNOP
			endif
		endif
		
		InterpolateFunc(XNop,1,XTemp,YTemp,XTemp,YTemp)

		//WaveStats/Q YTemp
		FastOp YTemp = YTemp+(-YStart)
		FastOp YTemp = (255/YRange)*YTemp
		
		if (XTemp[0] < XTemp[DimSize(XTemp,0)-1])
			Reverse/P YTemp
//			FlipVector(YTemp)
		endif
		
		if (B)
			Redimension/N=(numpnts(YTemp)) YBrowseRetract
			YBrowseRetract = YTemp
		else
			Redimension/N=(numpnts(YTemp)) YBrowseExtend
			YBrowseExtend = YTemp
		endif
	endfor
	
	if (WaveExists(BrowseWave))
		BrowseIndex = DimSize(BrowseWave,1)
		XNop = DimSize(YBrowseExtend,0)
		if (!DimSize(BrowseWave,0))
			Redimension/N=(Dimsize(YBrowseRetract,0)+XNop,1) BrowseWave
		else
			InsertPoints/M=1 BrowseIndex,1,BrowseWave
		endif
		BrowseWave[0,Min(DimSize(BrowseWave,0)-1,XNop-1)][BrowseIndex] = YBrowseExtend[P]
		BrowseWave[Min(DimSize(BrowseWave,0)-1,XNop),Min(DimSize(BrowseWave,0)-1,XNop+DimSize(YBrowseRetract,0)-1)][BrowseIndex] = YBrowseRetract[P-XNop]
	endif

End //ScaleFPBrowse


Function/S cryptidPausePanel(title, message, [forTime])
	
	string title, message
	variable forTime
	
	PauseUpdate; Silent 1		// building window...
	NewPanel/N=title/W=(20,20,200,100)
	ModifyPanel cbRGB=(60928,60928,60928)

	variable start = ticks/60

	ValDisplay CryptidPauseDisplay,pos={22,20},size={126,42},title="Test"
	ValDisplay CryptidPauseDisplay,barmisc={10,1000}

	wave vSettings = getCryptidSettings(0)
	if(!ParamIsDefault(forTime))
		ValDisplay CryptidPauseDisplay,limits={start,start+forTime,0}, value=(ticks/60)
	endif
	
End


//Generates a note out of the experiment info and the wave stdOut
Function/S cryptidGenerateNote()

	string addedNote = ""
	Wave/t stdOut = getCryptidSettings(1,setting="stdOut")
	wave vSettings = getCryptidSettings(0)
	wave searchSettings = root:Settings:SearchGrid:SearchSettings

	
	//Write everything from stdOut
	Variable i
	for (i=0; i<dimsize(stdOut,0); i+=1)
		addedNote = ReplaceStringbyKey(stdOut[i][0],AddedNote,stdOut[i][1],":","\r")
	endFor
	
	//Experiment Info stuff in panel
	addedNote += ExperimentInfoNote()
	string stepType = currentStepType()
	addedNote = ReplaceStringbyKey("ExperimentType",AddedNote,stepType,":","\r")
	addedNote = ReplaceStringbyKey("MoleculeNumber",AddedNote,num2str(SearchSettings[%CoarseSpotNumber]),":","\r")
	addedNote = ReplaceStringbyKey("ZeroVoltage",AddedNote,num2str(vSettings[%deflVOffset]),":","\r")
	
	return addedNote
	
End

Window CryptidPanelNEW() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(2348,131,2908,788)
	ModifyPanel cbRGB=(60928,60928,60928)
	SetDrawLayer UserBack
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 9,468,180,558
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 9,414,180,459
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 378,9,549,189
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 189,225,369,387
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 378,342,549,558
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 378,198,549,333
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 189,9,369,216
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 9,567,549,648
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 189,396,369,558
	ListBox StackDisplay,pos={9,9},size={171,396},proc=CryptidListBox
	ListBox StackDisplay,help={"Modify the stack using right-click"},fSize=16
	ListBox StackDisplay,listWave=root:Settings:Cryptid:experimentStack
	ListBox StackDisplay,selWave=root:Settings:Cryptid:stackSelWave,mode= 5
	ListBox StackDisplay,widths={119,33}
	Button Execute,pos={386,393},size={77,37},proc=CryptidButton,title="Execute"
	Button Execute,help={"Execute the experiment"},fColor=(61440,61440,61440)
	Button LoadExperiment,pos={18,423},size={72,27},proc=CryptidButton,title="Load"
	Button LoadExperiment,help={"Load a previously saved experiment"}
	Button LoadExperiment,fColor=(61440,61440,61440)
	Button SaveExperiment,pos={90,423},size={81,27},proc=CryptidButton,title="Save"
	Button SaveExperiment,help={"Save this experiment/stack for later use"}
	Button SaveExperiment,fColor=(61440,61440,61440)
	Button EditSearchGrid,pos={18,500},size={81,27},proc=CryptidButton,title="Edit Grid"
	Button EditSearchGrid,help={"Edit the search grid settings"}
	Button EditSearchGrid,fColor=(61440,61440,61440)
	Button ViewSearchGrid,pos={18,526},size={153,27},proc=searchButtonProc,title="View Search Grid"
	Button ViewSearchGrid,help={"Bring the search grid window to the front"}
	Button ViewSearchGrid,fColor=(61440,61440,61440)
	PopupMenu xAxisOption,pos={388,261},size={146,22},bodyWidth=111,proc=CryptidPopupMenu,title="X-Axis:"
	PopupMenu xAxisOption,mode=3,popvalue="Time",value= #"\"zSensor;ZSensorV;Time\""
	TitleBox experimentInfoTB,pos={207,18},size={135,21},title="Experiment Information"
	TitleBox experimentInfoTB,anchor= MC,fixedSize=1
	SetVariable Cantilever,pos={387,51},size={153,16},title="Cantilever: "
	SetVariable Cantilever,value= root:Settings:ExperimentInfo:experimentTemplate[%Cantilever]
	SetVariable TotalPEGLength,pos={198,45},size={162,16},title="PEG Length: "
	SetVariable TotalPEGLength,value= root:Settings:ExperimentInfo:experimentTemplate[%totalPEGLength]
	SetVariable TotalContourLength,pos={198,63},size={162,16},title="Protein Lc:    "
	SetVariable TotalContourLength,help={"Contour length of just the molecule of intereset"}
	SetVariable TotalContourLength,value= root:Settings:ExperimentInfo:experimentTemplate[%TotalContourLength]
	SetVariable surfaceDensity,pos={198,81},size={162,16},title="Surface Density: "
	SetVariable surfaceDensity,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%surfaceDensity]
	PopupMenu molecule,pos={198,99},size={162,22},bodyWidth=110,proc=experimentInfoPopup,title="Molecule: "
	PopupMenu molecule,fSize=12
	PopupMenu molecule,mode=1,popvalue="SdrG",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%Molecule][%Options]"
	PopupMenu TipChemistry,pos={198,144},size={162,22},bodyWidth=162,proc=experimentInfoPopup
	PopupMenu TipChemistry,mode=1,popvalue="Silane:Amine:PEG:Mal:CoA:SdrG",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%TipChemistry][%Options]"
	PopupMenu SurfaceChemistry,pos={198,189},size={162,22},bodyWidth=162,proc=experimentInfoPopup
	PopupMenu SurfaceChemistry,mode=1,popvalue="Silane:Amine:PEG:Mal:CoA",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%SurfaceChemistry][%Options]"
	SetVariable FineNumX,pos={474,388},size={50,20},disable=1
	SetVariable FineNumY,pos={534,388},size={50,20},disable=1
	SetVariable FineDistX,pos={594,388},size={50,20},disable=1
	SetVariable FineDistY,pos={654,388},size={50,20},disable=1
	SetVariable FineIterationsPerspot,pos={714,388},size={50,20},disable=1
	TitleBox SearchGridTitleBox,pos={27,474},size={135,21},title="Search Grid"
	TitleBox SearchGridTitleBox,anchor= MC,fixedSize=1
	TitleBox experimentInfoTB2,pos={408,207},size={111,21},title="Graph Settings"
	TitleBox experimentInfoTB2,anchor= MC,fixedSize=1
	Button Stop,pos={386,507},size={77,40},proc=CryptidButton,title="Stop (after run)"
	Button Stop,help={"Stop after the current step"},fColor=(61440,61440,61440)
	SetVariable SpringConstantSV,pos={387,73},size={153,16},title="SpringC   "
	SetVariable SpringConstantSV,format="%.1W1PN/nm"
	SetVariable SpringConstantSV,valueBackColor=(60928,60928,60928)
	SetVariable SpringConstantSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%DisplaySpringConstant],noedit= 2
	TitleBox InformationTitle,pos={396,20},size={135,24},title="Cantilever Information"
	TitleBox InformationTitle,anchor= MC,fixedSize=1
	SetVariable involsSV,pos={387,94},size={153,16},title="InvOLS   "
	SetVariable involsSV,format="%.1W1Pm/V",valueBackColor=(60928,60928,60928)
	SetVariable involsSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%InvOLS],noedit= 2
	SetVariable DeflVOffsetSV,pos={198,442},size={162,16},title="ZeroVolts"
	SetVariable DeflVOffsetSV,format="%.1W1PV",valueBackColor=(60928,60928,60928)
	SetVariable DeflVOffsetSV,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%deflVOffset],noedit= 2
	Button FixScale,pos={388,288},size={71,18},proc=CryptidButton,title="Fix Scale"
	Button FixScale,fColor=(61440,61440,61440)
	Button Continue,pos={463,393},size={78,37},proc=CryptidButton,title="Continue"
	Button Continue,help={"Execute without resetting the counter, so tasks with \"iter\" defined don't run if not needed"}
	Button Continue,fColor=(61440,61440,61440)
	CheckBox CryptidDebug,pos={201,349},size={80,14},proc=CryptidCheckBox,title="Debug Mode"
	CheckBox CryptidDebug,help={"Prints a bunch of debuggin info while running"}
	CheckBox CryptidDebug,value= 0
	Button StopNow,pos={463,507},size={78,40},proc=CryptidButton,title="Stop Now!"
	Button StopNow,help={"Does what the button says"},fColor=(61440,61440,61440)
	SetVariable Temperature,pos={198,488},size={124,16},title="Temp      "
	SetVariable Temperature,format="%.1f C",valueBackColor=(60928,60928,60928)
	SetVariable Temperature,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:EnvironVariablesWave[%EnvironSampleTemp],noedit= 2
	Button ResetEnviron,pos={322,486},size={38,24},proc=CryptidButton,title="Fix"
	Button ResetEnviron,help={"Reinitializes the enviroment since it freezes a lot (the software, not like ice freezing)"}
	Button ResetEnviron,fColor=(61440,61440,61440)
	SetVariable Iteration,pos={198,466},size={162,16},title="Iteration  "
	SetVariable Iteration,limits={-inf,inf,0},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration]
	SetVariable FullIterationCount,pos={198,512},size={124,16},title="Full Iter   "
	SetVariable FullIterationCount,valueBackColor=(60928,60928,60928)
	SetVariable FullIterationCount,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%fullIterations],styledText= 1
	Button ResetSearchGrid,pos={99,500},size={72,27},proc=CryptidButton,title="Reset Grid"
	Button ResetSearchGrid,help={"Reset the search grid"},fColor=(61440,61440,61440)
	TitleBox experimentInfoTB4,pos={425,355},size={77,30},title="Run",fStyle=0
	TitleBox experimentInfoTB4,anchor= MC,fixedSize=1
	SetVariable CryptidStatusDisplay,pos={18,612},size={476,28},bodyWidth=476,title=" "
	SetVariable CryptidStatusDisplay,fSize=20,valueBackColor=(48896,59904,65280)
	SetVariable CryptidStatusDisplay,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%cryptidStatusDisplay],noedit= 2
	SetVariable CryptidStatusDisplay1,pos={18,576},size={522,28},bodyWidth=522,title=" "
	SetVariable CryptidStatusDisplay1,fSize=20,valueBackColor=(65535,65535,65535)
	SetVariable CryptidStatusDisplay1,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%currentStepName],noedit= 2
	Button ResetFullIter,pos={322,510},size={38,22},proc=CryptidButton,title="Reset"
	Button ResetFullIter,help={"Reinitializes the enviroment since it freezes a lot (the software, not like ice freezing)"}
	Button ResetFullIter,fColor=(61440,61440,61440)
	TitleBox UserSettingsTitle,pos={200,234},size={160,19},title="Cryptid Settings"
	TitleBox UserSettingsTitle,anchor= MC,fixedSize=1
	Button SingleRun,pos={386,430},size={77,40},proc=CryptidButton,title="Run Once"
	Button SingleRun,help={"Run just once through"},fColor=(61440,61440,61440)
	Button ViewLog,pos={494,612},size={46,27},proc=CryptidButton,title="Log"
	Button ViewLog,fColor=(61440,61440,61440)
	PopupMenu yAxisOption,pos={388,234},size={146,22},bodyWidth=111,proc=CryptidPopupMenu,title="Y-Axis:"
	PopupMenu yAxisOption,mode=1,popvalue="Force",value= #"\"Force;Defl;DeflV;zSensor\""
	Button CharacterizeCantilever,pos={495,115},size={45,32},proc=CryptidButton,title="Test"
	Button CharacterizeCantilever,fColor=(61440,61440,61440)
	SetVariable Stability,pos={387,115},size={108,16},title="Stability   "
	SetVariable Stability,help={"This is the sub pN force stability of the cantilever. Get it by hitting the test button at ~100 nm from the surface"}
	SetVariable Stability,valueBackColor=(60928,60928,60928)
	SetVariable Stability,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%ForceStability],noedit= 2
	SetVariable TimeResponse,pos={387,136},size={108,16},title="Time Res."
	SetVariable TimeResponse,help={"This is time response of the cantilever. Get it by hitting the test button at ~100 nm from the surface"}
	SetVariable TimeResponse,valueBackColor=(60928,60928,60928)
	SetVariable TimeResponse,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%TimeResponse],noedit= 2
	TitleBox TipChemTitle,pos={198,126},size={135,21},title="Tip Chemisty",frame=0
	TitleBox TipChemTitle,anchor= LC,fixedSize=1
	TitleBox TipChemTitle1,pos={198,171},size={135,21},title="Surface Chemisty"
	TitleBox TipChemTitle1,frame=0,anchor= LC,fixedSize=1
	TitleBox RunInformation,pos={208,407},size={142,27},title="Run Information"
	TitleBox RunInformation,anchor= MC,fixedSize=1
	Button ExecuteStep,pos={463,430},size={78,40},proc=CryptidButton,title="Execute Step"
	Button ExecuteStep,help={"Execute just the selected step"}
	Button ExecuteStep,fColor=(61440,61440,61440)
	CheckBox save2Memory,pos={200,368},size={95,14},proc=CryptidCheckBox,title="Save to Memory"
	CheckBox save2Memory,help={"Send a discord message upon completion of the experiment. Read the ReadMe file for info on how to set this up"}
	CheckBox save2Memory,value= 1
	Button SkipRun,pos={386,470},size={77,37},proc=CryptidButton,title="Skip Run"
	Button SkipRun,help={"Stop after the current step"},fColor=(61440,61440,61440)
	PopupMenu User,pos={200,259},size={69,22},bodyWidth=69,proc=CryptidPopupMenu,title="User:"
	PopupMenu User,fSize=12,mode=0,value= #"\"Brandon;Dylan;\""
	SetVariable UserName,pos={268,261},size={92,16},title=" "
	SetVariable UserName,valueBackColor=(60928,60928,60928)
	SetVariable UserName,value= root:Settings:Cryptid:tSettings[%User],noedit= 1
	Button EditUserInfo,pos={200,291},size={80,30},proc=UserInfoButtonProc,title="Edit User Info"
	Button EditUserInfo,help={"Stop after the current step"}
	Button EditUserInfo,fColor=(61440,61440,61440)
	Button SaveUserInfo,pos={280,291},size={80,30},proc=UserInfoButtonProc,title="Save Edits"
	Button SaveUserInfo,help={"Stop after the current step"}
	Button SaveUserInfo,fColor=(61440,61440,61440)
	Button saveCantilever,pos={387,157},size={81,21},proc=UserInfoButtonProc,title="Save"
	Button saveCantilever,fColor=(61440,61440,61440)
	Button loadCantilever,pos={468,157},size={72,21},proc=UserInfoButtonProc,title="Load"
	Button loadCantilever,fColor=(61440,61440,61440)
	SetVariable useFastZero,pos={197,330},size={112,16},title="Use Fast Zero"
	SetVariable useFastZero,limits={0,1,1},value= root:Settings:Cryptid:vSettings[%useFastZero]
EndMacro


Window CryptidPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /K=1 /W=(739,102,1398,859) as "cryptidPanel"
	ModifyPanel cbRGB=(60928,60928,60928)
	SetDrawLayer UserBack
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,324,459,414
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,279,459,315
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,423,459,612
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 468,9,648,153
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 468,477,648,612
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,621,648,657
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 468,162,648,351
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,666,648,747
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 468,360,648,468
	ListBox StackDisplay,pos={288,9},size={171,261},proc=CryptidListBox
	ListBox StackDisplay,help={"Modify the stack using right-click"},fSize=16
	ListBox StackDisplay,listWave=root:Settings:Cryptid:experimentStack
	ListBox StackDisplay,selWave=root:Settings:Cryptid:stackSelWave,mode= 5
	ListBox StackDisplay,widths={119,33}
	Button Execute,pos={476,509},size={82,24},proc=CryptidButton,title="Execute"
	Button Execute,help={"Execute the experiment"},fColor=(61440,61440,61440)
	Button LoadExperiment,pos={297,286},size={72,22},proc=CryptidButton,title="Load"
	Button LoadExperiment,help={"Load a previously saved experiment"}
	Button LoadExperiment,fColor=(61440,61440,61440)
	Button SaveExperiment,pos={369,286},size={81,22},proc=CryptidButton,title="Save"
	Button SaveExperiment,help={"Save this experiment for later use"}
	Button SaveExperiment,fColor=(61440,61440,61440)
	Button EditSearchGrid,pos={297,356},size={81,27},proc=CryptidButton,title="Edit Grid"
	Button EditSearchGrid,help={"Edit the search grid settings"}
	Button EditSearchGrid,fColor=(61440,61440,61440)
	Button ViewSearchGrid,pos={297,382},size={153,27},proc=searchButtonProc,title="View Search Grid"
	Button ViewSearchGrid,help={"Bring the search grid window to the front"}
	Button ViewSearchGrid,fColor=(61440,61440,61440)
	PopupMenu xAxisOption,pos={477,630},size={64,22},bodyWidth=64,proc=CryptidPopupMenu,title="X-Axis:"
	PopupMenu xAxisOption,mode=0,value= #"\"zSensor;ZSensorV;Time\""
	TitleBox experimentInfoTB,pos={486,170},size={144,19},title="Experiment Information"
	TitleBox experimentInfoTB,help={"All information here is saved in the note of each wave"}
	TitleBox experimentInfoTB,fSize=15,anchor= MC,fixedSize=1
	SetVariable Cantilever,pos={297,458},size={153,16},title="Cantilever: "
	SetVariable Cantilever,help={"Cantilever name"}
	SetVariable Cantilever,value= root:Settings:ExperimentInfo:experimentTemplate[%Cantilever]
	SetVariable TotalPEGLength,pos={477,195},size={162,16},title="PEG Length: "
	SetVariable TotalPEGLength,help={"Total PEG length used in experiment in meters. Note that 1 PEG monomer is about 0.37 nm"}
	SetVariable TotalPEGLength,value= root:Settings:ExperimentInfo:experimentTemplate[%totalPEGLength]
	SetVariable TotalContourLength,pos={477,216},size={162,16},title="Protein Lc:    "
	SetVariable TotalContourLength,help={"Contour length of the molecule of intereset"}
	SetVariable TotalContourLength,value= root:Settings:ExperimentInfo:experimentTemplate[%TotalContourLength]
	SetVariable surfaceDensity,pos={477,237},size={162,16},title="Surface Density: "
	SetVariable surfaceDensity,help={"Surface density of surface molecule"}
	SetVariable surfaceDensity,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%surfaceDensity]
	PopupMenu molecule,pos={613,257},size={26,22},bodyWidth=20,proc=experimentInfoPopup,title=" "
	PopupMenu molecule,fSize=12
	PopupMenu molecule,mode=1,popvalue="SdrG",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%Molecule][%Options]+\";New;Remove\""
	PopupMenu TipChemistry,pos={619,293},size={20,22},bodyWidth=20,proc=experimentInfoPopup
	PopupMenu TipChemistry,mode=0,value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%TipChemistry][%Options]+\";New;Remove\""
	PopupMenu SurfaceChemistry,pos={619,326},size={20,22},bodyWidth=20,proc=experimentInfoPopup
	PopupMenu SurfaceChemistry,mode=0,value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%SurfaceChemistry][%Options]+\";New;Remove\""
	SetVariable FineNumX,pos={474,388},size={50,20},disable=1
	SetVariable FineNumY,pos={534,388},size={50,20},disable=1
	SetVariable FineDistX,pos={594,388},size={50,20},disable=1
	SetVariable FineDistY,pos={654,388},size={50,20},disable=1
	SetVariable FineIterationsPerspot,pos={714,388},size={50,20},disable=1
	TitleBox SearchGridTitleBox,pos={306,330},size={135,21},title="Search Grid"
	TitleBox SearchGridTitleBox,fSize=15,anchor= MC,fixedSize=1
	TitleBox experimentInfoTB2,pos={297,630},size={54,18},title="Graph:",fSize=15
	TitleBox experimentInfoTB2,anchor= MC,fixedSize=1
	Button Stop,pos={476,580},size={82,24},proc=CryptidButton,title="Stop (after run)"
	Button Stop,help={"Stop after the current run"},fColor=(61440,61440,61440)
	TitleBox searchGrid,pos={1,662},size={50,20}
	SetVariable SpringConstantSV,pos={297,477},size={153,16},title="k spring"
	SetVariable SpringConstantSV,help={"Spring Constant"},format="%.1W1PN/nm"
	SetVariable SpringConstantSV,valueBackColor=(60928,60928,60928)
	SetVariable SpringConstantSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%DisplaySpringConstant],noedit= 2
	TitleBox InformationTitle,pos={306,432},size={135,18},title="Cantilever Information"
	TitleBox InformationTitle,fSize=15,anchor= MC,fixedSize=1
	SetVariable involsSV,pos={297,497},size={153,16},title="InvOLS   "
	SetVariable involsSV,help={"InvOLS"},format="%.1W1Pm/V"
	SetVariable involsSV,valueBackColor=(60928,60928,60928)
	SetVariable involsSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%InvOLS],noedit= 2
	SetVariable DeflVOffsetSV,pos={477,393},size={162,16},title="ZeroVolts"
	SetVariable DeflVOffsetSV,help={"Last measured value of the zero-voltage"}
	SetVariable DeflVOffsetSV,format="%.1W1PV",valueBackColor=(60928,60928,60928)
	SetVariable DeflVOffsetSV,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%deflVOffset],noedit= 2
	Button Continue,pos={558,509},size={82,24},proc=CryptidButton,title="Continue"
	Button Continue,help={"Execute without resetting the counter, so tasks with \"iter\" defined don't run if not needed"}
	Button Continue,fColor=(61440,61440,61440)
	Button StopNow,pos={558,580},size={82,24},proc=CryptidButton,title="Stop Now!"
	Button StopNow,help={"Does what the button says (executes td_stop())"}
	Button StopNow,fColor=(61440,61440,61440)
	SetVariable Temperature,pos={477,426},size={124,16},title="Temperature"
	SetVariable Temperature,help={"Current cell temperature"},format="%.1f C"
	SetVariable Temperature,valueBackColor=(60928,60928,60928)
	SetVariable Temperature,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:EnvironVariablesWave[%EnvironSampleTemp],noedit= 2
	Button ResetEnviron,pos={601,425},size={38,16},proc=CryptidButton,title="Fix"
	Button ResetEnviron,help={"Reinitializes the enviroment since it freezes a lot (the software, not like ice freezing)"}
	Button ResetEnviron,fColor=(61440,61440,61440)
	SetVariable Iteration,pos={477,410},size={162,16},title="Iteration  "
	SetVariable Iteration,help={"Total iterations (not just sucessful ones)"}
	SetVariable Iteration,limits={-inf,inf,0},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration]
	SetVariable FullIterationCount,pos={477,443},size={124,16},title="Full Iter   "
	SetVariable FullIterationCount,help={"Number of full (sucessful) iterations. This is the suffix that the curve will be saved with"}
	SetVariable FullIterationCount,valueBackColor=(60928,60928,60928)
	SetVariable FullIterationCount,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%fullIterations],styledText= 1
	Button ResetSearchGrid,pos={378,356},size={72,27},proc=CryptidButton,title="Reset Grid"
	Button ResetSearchGrid,help={"Reset the search grid"},fColor=(61440,61440,61440)
	TitleBox experimentInfoTB4,pos={517,485},size={81,19},title="Run",fSize=15
	TitleBox experimentInfoTB4,fStyle=0,anchor= MC,fixedSize=1
	SetVariable CryptidStatusDisplay,pos={294,711},size={317,28},bodyWidth=317,title=" "
	SetVariable CryptidStatusDisplay,fSize=20,valueBackColor=(65280,16384,16384)
	SetVariable CryptidStatusDisplay,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%cryptidStatusDisplay],noedit= 2
	SetVariable CryptidStatusDisplay1,pos={294,675},size={348,28},bodyWidth=348,title=" "
	SetVariable CryptidStatusDisplay1,fSize=20,valueBackColor=(65535,65535,65535)
	SetVariable CryptidStatusDisplay1,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%currentStepName],noedit= 2
	Button ResetFullIter,pos={601,441},size={38,17},proc=CryptidButton,title="Reset"
	Button ResetFullIter,help={"Reset the full iteration counter"}
	Button ResetFullIter,fColor=(61440,61440,61440)
	TitleBox UserSettingsTitle,pos={478,17},size={161,19},title="Cryptid Settings"
	TitleBox UserSettingsTitle,fSize=15,anchor= MC,fixedSize=1
	Button SingleRun,pos={476,533},size={82,23},proc=CryptidButton,title="Run Once"
	Button SingleRun,help={"Run just once through"},fColor=(61440,61440,61440)
	Button ViewLog,pos={611,711},size={31,27},proc=CryptidButton,title="Log"
	Button ViewLog,fColor=(61440,61440,61440)
	PopupMenu yAxisOption,pos={351,630},size={61,22},bodyWidth=61,proc=CryptidPopupMenu,title="Y-Axis:"
	PopupMenu yAxisOption,mode=0,value= #"\"Force;Defl;DeflV;zSensor\""
	Button CharacterizeCantilever,pos={405,516},size={45,36},proc=CryptidButton,title="Test"
	Button CharacterizeCantilever,fColor=(61440,61440,61440)
	SetVariable Stability,pos={297,518},size={108,16},title="Stability   "
	SetVariable Stability,help={"This is the sub pN force stability of the cantilever. Get it by hitting the test button at ~100 nm from the surface"}
	SetVariable Stability,valueBackColor=(60928,60928,60928)
	SetVariable Stability,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%ForceStability],noedit= 2
	SetVariable TimeResponse,pos={297,538},size={108,16},title="Time Res."
	SetVariable TimeResponse,help={"This is time response of the cantilever. Get it by hitting the test button at ~100 nm from the surface."}
	SetVariable TimeResponse,valueBackColor=(60928,60928,60928)
	SetVariable TimeResponse,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%TimeResponse],noedit= 2
	TitleBox TipChemTitle,pos={477,274},size={135,19},title="Tip Chemisty"
	TitleBox TipChemTitle,help={"Tip chemistry being used. When adding new chemistries, do not use semicolons (use ctrl click to delete a value)"}
	TitleBox TipChemTitle,frame=0,anchor= LC,fixedSize=1
	TitleBox TipChemTitle1,pos={477,310},size={135,19},title="Surface Chemisty"
	TitleBox TipChemTitle1,help={"Surface chemistry being used. When adding new chemistries, do not use semicolons (use ctrl click to delete a value)"}
	TitleBox TipChemTitle1,frame=0,anchor= LC,fixedSize=1
	TitleBox RunInformation,pos={487,368},size={142,20},title="Run Information"
	TitleBox RunInformation,fSize=15,anchor= MC,fixedSize=1
	Button ExecuteStep,pos={558,533},size={82,23},proc=CryptidButton,title="Execute Step"
	Button ExecuteStep,help={"Execute just the selected step"}
	Button ExecuteStep,fColor=(61440,61440,61440)
	Button SkipRun,pos={476,556},size={82,24},proc=CryptidButton,title="Skip Run"
	Button SkipRun,help={"Skips the current run and starts over. Useful for long experiments (such as force clamps) where you know the current run is bad"}
	Button SkipRun,fColor=(61440,61440,61440)
	PopupMenu User,pos={478,39},size={70,22},bodyWidth=70,proc=UserInfoPopMenuProc,title="User:"
	PopupMenu User,help={"Current user. Click \"New\" to add a new user or hold ctrl to delete a user"}
	PopupMenu User,fSize=12,mode=0,value= #"listOfUsers()+\"New;Remove;Edit;\""
	SetVariable UserName,pos={547,41},size={91,16},title=" "
	SetVariable UserName,valueBackColor=(60928,60928,60928)
	SetVariable UserName,value= root:Settings:Cryptid:tSettings[%User],noedit= 1
	Button saveCantilever,pos={297,567},size={81,25},proc=UserInfoButtonProc,title="Save"
	Button saveCantilever,fColor=(61440,61440,61440)
	Button loadCantilever,pos={378,567},size={72,25},proc=UserInfoButtonProc,title="Load"
	Button loadCantilever,fColor=(61440,61440,61440)
	SetVariable useFastZero,pos={477,64},size={108,16},title="Use Fast Zero   "
	SetVariable useFastZero,help={"Normal zero collects 2ms of data at 50kHz. Fast zero collects a single point, which happens much quicker but won't be as accurate of a zero"}
	SetVariable useFastZero,limits={0,1,1},value= root:Settings:Cryptid:vSettings[%useFastZero]
	Button GetGraph,pos={606,630},size={36,23},proc=CryptidButton,title="Get"
	Button GetGraph,help={"Retrieve the graph"},fColor=(61440,61440,61440)
	SetVariable TipChemistryDisplay,pos={477,294},size={144,16},title=" "
	SetVariable TipChemistryDisplay,help={" (use ctrl click to delete a value)"}
	SetVariable TipChemistryDisplay,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%TipChemistry],noedit= 1
	SetVariable TipChemistryDisplay1,pos={477,326},size={144,16},title=" "
	SetVariable TipChemistryDisplay1,help={" (use ctrl click to delete a value)"}
	SetVariable TipChemistryDisplay1,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%SurfaceChemistry],noedit= 1
	TitleBox TipChemTitle2,pos={477,255},size={54,18},title="Molecule:"
	TitleBox TipChemTitle2,help={"Molecule being studied (use ctrl click to delete a value)"}
	TitleBox TipChemTitle2,frame=0,anchor= LC,fixedSize=1
	SetVariable TipChemistryDisplay2,pos={531,257},size={90,16},title=" "
	SetVariable TipChemistryDisplay2,help={"(use ctrl click to delete a value)"}
	SetVariable TipChemistryDisplay2,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%Molecule],noedit= 1
	SetVariable debugMode,pos={576,129},size={63,16},title="Debug"
	SetVariable debugMode,help={"Enters debug mode, which prints a lot of info to help diagnose issues"}
	SetVariable debugMode,limits={0,1,1},value= root:Settings:Cryptid:vSettings[%CryptidDebug]
	SetVariable debugMode1,pos={477,83},size={108,16},title="Save to Memory"
	SetVariable debugMode1,help={"Saves waves to memory so they can be viewed in the master force panel. Even when off, waves are still saved to disk. "}
	SetVariable debugMode1,limits={0,1,1},value= root:Settings:Cryptid:vSettings[%save2memory]
	SetVariable TipChemistryDisplay3,pos={411,631},size={54,20},title=" ",fSize=15
	SetVariable TipChemistryDisplay3,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%yAxisOption]
	SetVariable TipChemistryDisplay4,pos={540,631},size={63,20},title=" ",fSize=15
	SetVariable TipChemistryDisplay4,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%xAxisOption]
	Button NextSpot,pos={557,556},size={82,24},proc=SearchButtonProc,title="Next Spot"
	Button NextSpot,help={"Skips the current run and starts over. Useful for long experiments (such as force clamps) where you know the current run is bad"}
	Button NextSpot,fColor=(61440,61440,61440)
	Button UpdateDate,pos={477,108},size={99,27},proc=CryptidButton,title="Update save path"
	Button UpdateDate,fColor=(61440,61440,61440)
	ToolsGrid snap=1,visible=1
	SetWindow kwTopWin,hook=crytptidPanelHook,hookevents=1
	NewPanel/W=(0,0,0.43,0.99)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	DrawLine 50,50,60,60
	DrawLine 19,261,253,261
	DrawLine 19,375,253,375
	SetDrawEnv fstyle= 1
	DrawText 19,279,"Spot Numbers"
	SetDrawEnv fstyle= 1
	DrawText 19,392,"Iteration Info"
	DrawLine 19,488,253,488
	SetDrawEnv fstyle= 1
	DrawText 19,509,"Operation Status"
	SetDrawEnv fstyle= 1
	DrawText 19,572,"Move To Spot"
	DrawLine 19,554,253,554
	DrawLine 18,198,252,198
	SetDrawEnv fstyle= 1
	DrawText 18,216,"Image-Based Grid"
	SetVariable CoarseNumX,pos={24,46},size={207,16},proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable CoarseNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumX]
	SetVariable CoarseNumY,pos={24,88},size={210,16},proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable CoarseNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumY]
	SetVariable CoarseDistX,pos={24,67},size={210,16},proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable CoarseDistX,format="%.1W1Pm"
	SetVariable CoarseDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistX]
	SetVariable CoarseDistY,pos={24,111},size={209,16},proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable CoarseDistY,format="%.1W1Pm"
	SetVariable CoarseDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistY]
	SetVariable FineNumX,pos={28,43},size={207,16},disable=1,proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable FineNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumX]
	SetVariable FineDistX,pos={28,64},size={210,16},disable=1,proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable FineDistX,format="%.1W1Pm"
	SetVariable FineDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistX]
	SetVariable FineNumY,pos={28,85},size={210,16},disable=1,proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable FineNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumY]
	SetVariable FineDistY,pos={28,108},size={209,16},disable=1,proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable FineDistY,format="%.1W1Pm"
	SetVariable FineDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistY]
	SetVariable CoarseIterationsPerSpot,pos={24,135},size={209,16},proc=SearchSetVarProc,title="Iterations Per Spot"
	SetVariable CoarseIterationsPerSpot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseIterationsPerSpot]
	SetVariable FineIterationsPerspot,pos={28,134},size={209,16},disable=1,title="Iterations Per Spot"
	SetVariable FineIterationsPerspot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%FineIterationsPerSpot]
	TabControl tab0,pos={19,14},size={234,148},proc=SearchTabProc
	TabControl tab0,labelBack=(47872,47872,47872),tabLabel(0)="Coarse Grid Settings"
	TabControl tab0,tabLabel(1)="Fine Grid Settings",value= 0
	SetVariable SpotNumber,pos={19,280},size={209,16},title="SpotNumber"
	SetVariable SpotNumber,limits={1,1e+06,1},value= root:Settings:SearchGrid:SearchSettings[%SpotNumber]
	SetVariable CoarseSpotNumber,pos={19,300},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseSpotNumber]
	SetVariable FineSpotNumber,pos={19,321},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineSpotNumber]
	SetVariable FineLevel,pos={19,342},size={209,16},title="Fine Level"
	SetVariable FineLevel,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineLevel]
	SetVariable MasterIteration,pos={19,395},size={209,16},title="Master Iteration"
	SetVariable MasterIteration,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration],noedit= 1
	SetVariable IterationsCurrentSpot,pos={19,417},size={209,16},title="Iterations at Current Spot"
	SetVariable IterationsCurrentSpot,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtCurrentSpot],noedit= 1
	SetVariable LastGoodIteration,pos={19,440},size={209,16},title="Last Good Iteration"
	SetVariable LastGoodIteration,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%LastGoodIteration],noedit= 1
	SetVariable CurrentMode,pos={19,512},size={200,16},title="Current Mode"
	SetVariable CurrentMode,value= root:Settings:SearchGrid:SearchMode[%CurrentMode]
	SetVariable Callback,pos={19,531},size={200,16},title="Callback"
	SetVariable Callback,help={"Executes this function after moving to the next spot"}
	SetVariable Callback,value= root:Settings:SearchGrid:SearchMode[%Callback]
	SetVariable CoarseSpotNumber1,pos={19,573},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber1,limits={1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%CoarseSpotNumber]
	SetVariable FineSpotNumber1,pos={19,594},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber1,help={"Put -1 to not use a fine position"}
	SetVariable FineSpotNumber1,limits={-1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%FineSpotNumber]
	Button MoveToSpot,pos={18,617},size={79,27},proc=SearchButtonProc,title="Move To Spot"
	SetVariable IterationsPerHotSpot,pos={20,461},size={209,16},title="Iterations Per Hot Spot"
	SetVariable IterationsPerHotSpot,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtHotSpot]
	Button NextSpot,pos={99,617},size={79,27},proc=SearchButtonProc,title="Next Spot"
	PopupMenu SearchGridQuckSettingsPM,pos={19,649},size={143,22},proc=SearchGridQSPopMenuProc,title="Quick Settings"
	PopupMenu SearchGridQuckSettingsPM,mode=8,popvalue="ddFLN4",value= #"SearchQuickSettingsList()"
	Button GetGraphPos,pos={144,234},size={90,18},proc=SearchButtonProc,title="Get Image Pos"
	Button GetGraphPos,help={"Used to capture either the marquee (grid) or cursors (line) from an image to make the search grid/line"}
	SetVariable useGraphSearch2,pos={18,216},size={117,16},proc=SearchSetVarProc,title="Use Image Grid"
	SetVariable useGraphSearch2,help={"Will change from a set grid (0) to a grid based on an AFM image (1). To use, take an AFM image and then draw a marquee on it. Once drawn, hit \"Get Image Pos\" and the grid will be drawn inside the marquee, allowing for pulling at specific points on image"}
	SetVariable useGraphSearch2,limits={0,1,1},value= root:Settings:SearchGrid:SearchSettings[%UseGraphSearch]
	SetVariable Line2,pos={153,216},size={81,16},proc=SearchSetVarProc,title="Spot Line"
	SetVariable Line2,help={"Switches from a grid-based system to a line. To use, instead of placing a marquee, place the A and B cursors at the endpoints of the desired line, then click \"Get Image Pos\""}
	SetVariable Line2,limits={0,1,1},value= root:Settings:SearchGrid:SearchSettings[%UseSpotLine]
	SetVariable useFine,pos={18,171},size={90,16},proc=SearchSetVarProc,title="Fine Search"
	SetVariable useFine,limits={0,1,1},value= root:Settings:SearchGrid:SearchSettings[%UseFineSearch]
	SetVariable StayHere,pos={153,171},size={81,16},proc=SearchSetVarProc,title="Stay Here!"
	SetVariable StayHere,limits={0,1,1},value= root:Settings:SearchGrid:SearchSettings[%HotSpotManualOverride]
	ToolsGrid snap=1,visible=1
	RenameWindow #,settingsPanel
	SetActiveSubwindow ##
	NewPanel/W=(1,1,1,1)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={13,54},size={203,16},title="Surface Trigger"
	SetVariable SurfaceTrigger1,format="%.1W1PN"
	RenameWindow #,P0
	SetActiveSubwindow ##
EndMacro


Window CryptidPanelOld() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1997,109,3194,847)
	ModifyPanel cbRGB=(60928,60928,60928)
	SetDrawLayer UserBack
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,333,459,423
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,279,459,324
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,432,459,585
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 657,477,819,630
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 990,477,1188,630
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 828,477,981,630
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 468,477,648,720
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 657,639,1188,720
	SetDrawEnv fillpat= 45,fillfgc= (52224,52224,52224),fillbgc= (47872,47872,47872)
	DrawRect 288,594,459,720
	ListBox StackDisplay,pos={288,9},size={171,261},proc=CryptidListBox
	ListBox StackDisplay,help={"Modify the stack using right-click"},fSize=16
	ListBox StackDisplay,listWave=root:Settings:Cryptid:experimentStack
	ListBox StackDisplay,selWave=root:Settings:Cryptid:stackSelWave,mode= 5
	ListBox StackDisplay,widths={119,33}
	Button Execute,pos={999,513},size={90,27},proc=CryptidButton,title="Execute"
	Button Execute,help={"Execute the experiment"},fColor=(61440,61440,61440)
	Button LoadExperiment,pos={297,288},size={72,27},proc=CryptidButton,title="Load"
	Button LoadExperiment,help={"Load a previously saved experiment"}
	Button LoadExperiment,fColor=(61440,61440,61440)
	Button SaveExperiment,pos={369,288},size={81,27},proc=CryptidButton,title="Save"
	Button SaveExperiment,help={"Save this experiment/stack for later use"}
	Button SaveExperiment,fColor=(61440,61440,61440)
	Button EditSearchGrid,pos={297,365},size={81,27},proc=CryptidButton,title="Edit Grid"
	Button EditSearchGrid,help={"Edit the search grid settings"}
	Button EditSearchGrid,fColor=(61440,61440,61440)
	Button ViewSearchGrid,pos={297,391},size={153,27},proc=searchButtonProc,title="View Search Grid"
	Button ViewSearchGrid,help={"Bring the search grid window to the front"}
	Button ViewSearchGrid,fColor=(61440,61440,61440)
	PopupMenu xAxisOption,pos={837,540},size={130,22},bodyWidth=95,proc=CryptidPopupMenu,title="X-Axis:"
	PopupMenu xAxisOption,mode=3,popvalue="Time",value= #"\"zSensor;ZSensorV;Time\""
	TitleBox experimentInfoTB,pos={486,486},size={135,21},title="Experiment Information"
	TitleBox experimentInfoTB,anchor= MC,fixedSize=1
	SetVariable Cantilever,pos={297,468},size={153,16},title="Cantilever: "
	SetVariable Cantilever,value= root:Settings:ExperimentInfo:experimentTemplate[%Cantilever]
	SetVariable TotalPEGLength,pos={477,513},size={162,16},title="PEG Length: "
	SetVariable TotalPEGLength,value= root:Settings:ExperimentInfo:experimentTemplate[%totalPEGLength]
	SetVariable TotalContourLength,pos={477,531},size={162,16},title="Protein Lc:    "
	SetVariable TotalContourLength,help={"Contour length of just the molecule of intereset"}
	SetVariable TotalContourLength,value= root:Settings:ExperimentInfo:experimentTemplate[%TotalContourLength]
	SetVariable surfaceDensity,pos={477,549},size={162,16},title="Surface Density: "
	SetVariable surfaceDensity,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%surfaceDensity]
	PopupMenu molecule,pos={477,567},size={162,22},bodyWidth=110,proc=experimentInfoPopup,title="Molecule: "
	PopupMenu molecule,fSize=12
	PopupMenu molecule,mode=1,popvalue="SdrG",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%Molecule][%Options]"
	PopupMenu TipChemistry,pos={477,612},size={162,22},bodyWidth=162,proc=experimentInfoPopup
	PopupMenu TipChemistry,mode=1,popvalue="Silane:Amine:PEG:Mal:CoA:SdrG",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%TipChemistry][%Options]"
	PopupMenu SurfaceChemistry,pos={477,657},size={162,22},bodyWidth=162,proc=experimentInfoPopup
	PopupMenu SurfaceChemistry,mode=1,popvalue="Silane:Amine:PEG:Mal:CoA",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%SurfaceChemistry][%Options]"
	SetVariable FineNumX,pos={474,388},size={50,20},disable=1
	SetVariable FineNumY,pos={534,388},size={50,20},disable=1
	SetVariable FineDistX,pos={594,388},size={50,20},disable=1
	SetVariable FineDistY,pos={654,388},size={50,20},disable=1
	SetVariable FineIterationsPerspot,pos={714,388},size={50,20},disable=1
	TitleBox SearchGridTitleBox,pos={306,339},size={135,21},title="Search Grid"
	TitleBox SearchGridTitleBox,anchor= MC,fixedSize=1
	TitleBox experimentInfoTB2,pos={855,486},size={99,21},title="Graph Settings"
	TitleBox experimentInfoTB2,anchor= MC,fixedSize=1
	Button Stop,pos={999,594},size={90,27},proc=CryptidButton,title="Stop (after run)"
	Button Stop,help={"Stop after the current step"},fColor=(61440,61440,61440)
	TitleBox searchGrid,pos={1,662},size={50,20}
	SetVariable SpringConstantSV,pos={297,486},size={153,16},title="SpringC   "
	SetVariable SpringConstantSV,format="%.1W1PN/nm"
	SetVariable SpringConstantSV,valueBackColor=(60928,60928,60928)
	SetVariable SpringConstantSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%DisplaySpringConstant],noedit= 2
	TitleBox InformationTitle,pos={306,441},size={135,21},title="Cantilever Information"
	TitleBox InformationTitle,anchor= MC,fixedSize=1
	SetVariable involsSV,pos={297,504},size={153,16},title="InvOLS   "
	SetVariable involsSV,format="%.1W1Pm/V",valueBackColor=(60928,60928,60928)
	SetVariable involsSV,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:MasterVariablesWave[%InvOLS],noedit= 2
	SetVariable DeflVOffsetSV,pos={297,630},size={153,16},title="ZeroVolts"
	SetVariable DeflVOffsetSV,format="%.1W1PV",valueBackColor=(60928,60928,60928)
	SetVariable DeflVOffsetSV,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%deflVOffset],noedit= 2
	Button FixScale,pos={837,567},size={63,18},proc=CryptidButton,title="Fix Scale"
	Button FixScale,fColor=(61440,61440,61440)
	Button Continue,pos={1089,513},size={90,27},proc=CryptidButton,title="Continue"
	Button Continue,help={"Execute without resetting the counter, so tasks with \"iter\" defined don't run if not needed"}
	Button Continue,fColor=(61440,61440,61440)
	CheckBox CryptidDebug,pos={667,594},size={80,14},proc=CryptidCheckBox,title="Debug Mode"
	CheckBox CryptidDebug,help={"Prints a bunch of debuggin info while running"}
	CheckBox CryptidDebug,value= 0
	Button StopNow,pos={1089,594},size={90,27},proc=CryptidButton,title="Stop Now!"
	Button StopNow,help={"Does what the button says"},fColor=(61440,61440,61440)
	SetVariable Temperature,pos={297,666},size={117,16},title="Temp      "
	SetVariable Temperature,format="%.1f C",valueBackColor=(60928,60928,60928)
	SetVariable Temperature,limits={-inf,inf,0},value= root:packages:MFP3D:Main:Variables:EnvironVariablesWave[%EnvironSampleTemp],noedit= 2
	Button ResetEnviron,pos={414,664},size={36,18},proc=CryptidButton,title="Fix"
	Button ResetEnviron,help={"Reinitializes the enviroment since it freezes a lot (the software, not like ice freezing)"}
	Button ResetEnviron,fColor=(61440,61440,61440)
	SetVariable Iteration,pos={297,648},size={153,16},title="Iteration  "
	SetVariable Iteration,limits={-inf,inf,0},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration]
	SetVariable FullIterationCount,pos={297,684},size={117,16},title="Full Iter   "
	SetVariable FullIterationCount,valueBackColor=(60928,60928,60928)
	SetVariable FullIterationCount,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%fullIterations],styledText= 1
	Button ResetSearchGrid,pos={378,365},size={72,27},proc=CryptidButton,title="Reset Grid"
	Button ResetSearchGrid,help={"Reset the search grid"},fColor=(61440,61440,61440)
	TitleBox experimentInfoTB4,pos={1044,486},size={90,18},title="Run",fStyle=0
	TitleBox experimentInfoTB4,anchor= MC,fixedSize=1
	SetVariable CryptidStatusDisplay,pos={666,684},size={468,28},bodyWidth=468,title=" "
	SetVariable CryptidStatusDisplay,fSize=20,valueBackColor=(65280,16384,16384)
	SetVariable CryptidStatusDisplay,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%cryptidStatusDisplay],noedit= 2
	SetVariable CryptidStatusDisplay1,pos={666,648},size={513,28},bodyWidth=513,title=" "
	SetVariable CryptidStatusDisplay1,fSize=20,valueBackColor=(65535,65535,65535)
	SetVariable CryptidStatusDisplay1,limits={-inf,inf,0},value= root:Settings:Cryptid:tSettings[%currentStepName],noedit= 2
	Button ResetFullIter,pos={414,682},size={36,18},proc=CryptidButton,title="Reset"
	Button ResetFullIter,help={"Reinitializes the enviroment since it freezes a lot (the software, not like ice freezing)"}
	Button ResetFullIter,fColor=(61440,61440,61440)
	TitleBox UserSettingsTitle,pos={666,486},size={144,18},title="Cryptid Settings"
	TitleBox UserSettingsTitle,anchor= MC,fixedSize=1
	Button SingleRun,pos={999,540},size={90,27},proc=CryptidButton,title="Run Once"
	Button SingleRun,help={"Run just once through"},fColor=(61440,61440,61440)
	Button ViewLog,pos={1134,684},size={45,27},proc=CryptidButton,title="Log"
	Button ViewLog,fColor=(61440,61440,61440)
	PopupMenu yAxisOption,pos={837,513},size={130,22},bodyWidth=95,proc=CryptidPopupMenu,title="Y-Axis:"
	PopupMenu yAxisOption,mode=1,popvalue="Force",value= #"\"Force;Defl;DeflV;zSensor\""
	Button CharacterizeCantilever,pos={405,522},size={45,27},proc=CryptidButton,title="Test"
	Button CharacterizeCantilever,fColor=(61440,61440,61440)
	SetVariable Stability,pos={297,522},size={108,16},title="Stability   "
	SetVariable Stability,help={"This is the sub pN force stability of the cantilever. Get it by hitting the test button at ~100 nm from the surface"}
	SetVariable Stability,valueBackColor=(60928,60928,60928)
	SetVariable Stability,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%ForceStability],noedit= 2
	SetVariable TimeResponse,pos={297,540},size={108,16},title="Time Res."
	SetVariable TimeResponse,help={"This is time response of the cantilever. Get it by hitting the test button at ~100 nm from the surface"}
	SetVariable TimeResponse,valueBackColor=(60928,60928,60928)
	SetVariable TimeResponse,limits={-inf,inf,0},value= root:Settings:Cryptid:vSettings[%TimeResponse],noedit= 2
	TitleBox TipChemTitle,pos={477,594},size={135,21},title="Tip Chemisty",frame=0
	TitleBox TipChemTitle,anchor= LC,fixedSize=1
	TitleBox TipChemTitle1,pos={477,639},size={135,21},title="Surface Chemisty"
	TitleBox TipChemTitle1,frame=0,anchor= LC,fixedSize=1
	TitleBox RunInformation,pos={306,603},size={135,21},title="Run Information"
	TitleBox RunInformation,anchor= MC,fixedSize=1
	Button ExecuteStep,pos={1089,540},size={90,27},proc=CryptidButton,title="Execute Step"
	Button ExecuteStep,help={"Execute just the selected step"}
	Button ExecuteStep,fColor=(61440,61440,61440)
	CheckBox save2Memory,pos={666,612},size={95,14},proc=CryptidCheckBox,title="Save to Memory"
	CheckBox save2Memory,help={"Send a discord message upon completion of the experiment. Read the ReadMe file for info on how to set this up"}
	CheckBox save2Memory,value= 1
	Button SkipRun,pos={999,567},size={90,27},proc=CryptidButton,title="Skip Run"
	Button SkipRun,help={"Stop after the current step"},fColor=(61440,61440,61440)
	PopupMenu User,pos={666,509},size={63,22},bodyWidth=63,proc=CryptidPopupMenu,title="User:"
	PopupMenu User,fSize=12,mode=0,value= #"\"Brandon;Dylan;\""
	SetVariable UserName,pos={728,511},size={82,16},title=" "
	SetVariable UserName,valueBackColor=(60928,60928,60928)
	SetVariable UserName,value= root:Settings:Cryptid:tSettings[%User],noedit= 1
	Button EditUserInfo,pos={666,540},size={72,27},proc=UserInfoButtonProc,title="Edit User Info"
	Button EditUserInfo,help={"Stop after the current step"}
	Button EditUserInfo,fColor=(61440,61440,61440)
	Button SaveUserInfo,pos={738,540},size={72,27},proc=UserInfoButtonProc,title="Save Edits"
	Button SaveUserInfo,help={"Stop after the current step"}
	Button SaveUserInfo,fColor=(61440,61440,61440)
	Button saveCantilever,pos={297,558},size={81,18},proc=UserInfoButtonProc,title="Save"
	Button saveCantilever,fColor=(61440,61440,61440)
	Button loadCantilever,pos={378,558},size={72,18},proc=UserInfoButtonProc,title="Load"
	Button loadCantilever,fColor=(61440,61440,61440)
	SetVariable useFastZero,pos={665,576},size={100,16},title="Use Fast Zero"
	SetVariable useFastZero,limits={0,1,1},value= root:Settings:Cryptid:vSettings[%useFastZero]
	ToolsGrid snap=1,visible=1
	SetWindow kwTopWin,hook=crytptidPanelHook,hookevents=1
	String fldrSav0= GetDataFolder(1)
	SetDataFolder root:Settings:Cryptid:
	Display/W=(470,1,1188,466)/HOST=#  workingForce vs workingZSensor
	SetDataFolder fldrSav0
	ModifyGraph grid(left)=1
	ModifyGraph tick=2
	ModifyGraph gridStyle(left)=1
	Label left "Force (\\U)"
	Label bottom "Time (\\U)"
	RenameWindow #,G0
	SetActiveSubwindow ##
	NewPanel/W=(0,0,0.234,0.98)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	DrawLine 50,50,60,60
	DrawLine 19,207,253,207
	DrawLine 19,321,253,321
	SetDrawEnv fstyle= 1
	DrawText 19,225,"Spot Numbers"
	SetDrawEnv fstyle= 1
	DrawText 19,338,"Iteration Info"
	DrawLine 19,434,253,434
	SetDrawEnv fstyle= 1
	DrawText 19,455,"Operation Status"
	SetDrawEnv fstyle= 1
	DrawText 19,518,"Move To Spot"
	DrawLine 19,500,253,500
	SetVariable CoarseNumX,pos={24,46},size={207,16},proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable CoarseNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumX]
	SetVariable CoarseNumY,pos={24,88},size={210,16},proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable CoarseNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumY]
	SetVariable CoarseDistX,pos={24,67},size={210,16},proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable CoarseDistX,format="%.1W1Pm"
	SetVariable CoarseDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistX]
	SetVariable CoarseDistY,pos={24,111},size={209,16},proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable CoarseDistY,format="%.1W1Pm"
	SetVariable CoarseDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistY]
	SetVariable FineNumX,pos={28,43},size={207,16},disable=1,proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable FineNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumX]
	SetVariable FineDistX,pos={28,64},size={210,16},disable=1,proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable FineDistX,format="%.1W1Pm"
	SetVariable FineDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistX]
	SetVariable FineNumY,pos={28,85},size={210,16},disable=1,proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable FineNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumY]
	SetVariable FineDistY,pos={28,108},size={209,16},disable=1,proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable FineDistY,format="%.1W1Pm"
	SetVariable FineDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistY]
	SetVariable CoarseIterationsPerSpot,pos={24,135},size={209,16},proc=SearchSetVarProc,title="Iterations Per Spot"
	SetVariable CoarseIterationsPerSpot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseIterationsPerSpot]
	SetVariable FineIterationsPerspot,pos={28,134},size={209,16},disable=1,title="Iterations Per Spot"
	SetVariable FineIterationsPerspot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%FineIterationsPerSpot]
	TabControl tab0,pos={19,14},size={235,157},proc=SearchTabProc
	TabControl tab0,labelBack=(47872,47872,47872),tabLabel(0)="Coarse Grid Settings"
	TabControl tab0,tabLabel(1)="Fine Grid Settings",value= 0
	CheckBox UseFineSearch,pos={19,192},size={97,14},proc=SearchCheckProc,title="Use Fine Search"
	CheckBox UseFineSearch,value= 1
	SetVariable SpotNumber,pos={19,226},size={209,16},title="SpotNumber"
	SetVariable SpotNumber,limits={1,1e+06,1},value= root:Settings:SearchGrid:SearchSettings[%SpotNumber]
	SetVariable CoarseSpotNumber,pos={19,246},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseSpotNumber]
	SetVariable FineSpotNumber,pos={19,267},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineSpotNumber]
	SetVariable FineLevel,pos={19,288},size={209,16},title="Fine Level"
	SetVariable FineLevel,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineLevel]
	SetVariable MasterIteration,pos={19,341},size={209,16},title="Master Iteration"
	SetVariable MasterIteration,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration],noedit= 1
	SetVariable IterationsCurrentSpot,pos={19,363},size={209,16},title="Iterations at Current Spot"
	SetVariable IterationsCurrentSpot,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtCurrentSpot],noedit= 1
	SetVariable LastGoodIteration,pos={19,386},size={209,16},title="Last Good Iteration"
	SetVariable LastGoodIteration,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%LastGoodIteration],noedit= 1
	SetVariable CurrentMode,pos={19,458},size={200,16},title="Current Mode"
	SetVariable CurrentMode,value= root:Settings:SearchGrid:SearchMode[%CurrentMode]
	SetVariable Callback,pos={19,477},size={200,16},title="Callback"
	SetVariable Callback,help={"Executes this function after moving to the next spot"}
	SetVariable Callback,value= root:Settings:SearchGrid:SearchMode[%Callback]
	SetVariable CoarseSpotNumber1,pos={19,519},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber1,limits={1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%CoarseSpotNumber]
	SetVariable FineSpotNumber1,pos={19,540},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber1,help={"Put -1 to not use a fine position"}
	SetVariable FineSpotNumber1,limits={-1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%FineSpotNumber]
	Button MoveToSpot,pos={18,563},size={79,27},proc=SearchButtonProc,title="Move To Spot"
	CheckBox HotSpotManualOverride,pos={129,193},size={68,14},proc=SearchCheckProc,title="Stay Here!"
	CheckBox HotSpotManualOverride,help={"This will prevent the algorithm from moving the stage from this spot.  Good if you want to keep hitting this spot."}
	CheckBox HotSpotManualOverride,value= 0
	SetVariable IterationsPerHotSpot,pos={20,407},size={209,16},title="Iterations Per Hot Spot"
	SetVariable IterationsPerHotSpot,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtHotSpot]
	Button NextSpot,pos={99,563},size={79,27},proc=SearchButtonProc,title="Next Spot"
	PopupMenu SearchGridQuckSettingsPM,pos={19,595},size={143,22},proc=SearchGridQSPopMenuProc,title="Quick Settings"
	PopupMenu SearchGridQuckSettingsPM,mode=8,popvalue="ddFLN4",value= #"SearchQuickSettingsList()"
	CheckBox UseGraphSearch,pos={19,172},size={106,14},proc=SearchCHeckProc,title="Use Graph Search"
	CheckBox UseGraphSearch,value= 0
	CheckBox UseSpotLine,pos={220,172},size={38,14},proc=SearchCHeckProc,title="Line"
	CheckBox UseSpotLine,value= 0
	Button GetGraphPos,pos={129,172},size={80,18},proc=SearchButtonProc,title="Get Graph Pos"
	ToolsGrid snap=1,visible=1
	RenameWindow #,settingsPanel
	SetActiveSubwindow ##
	NewPanel/W=(1,1,1,1)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={13,54},size={203,16},title="Surface Trigger"
	SetVariable SurfaceTrigger1,format="%.1W1PN"
	RenameWindow #,P0
	SetActiveSubwindow ##
EndMacro

Window cryptidGraph() : Graph
	PauseUpdate; Silent 1		// building window...
	String fldrSav0= GetDataFolder(1)
	SetDataFolder root:Settings:Cryptid:
	Display/K=1 /W=(2122.5,95.75,2656.5,445.25) root:Settings:Cryptid:workingForce vs root:Settings:Cryptid:workingZSensor
	SetDataFolder fldrSav0
	ModifyGraph grid(left)=1
	ModifyGraph tick=2
	ModifyGraph mirror=1
	ModifyGraph gridStyle(left)=1
	Label left "Force (\\U)"
	Label bottom "Time (\\U)"
EndMacro


Window cryptidDynamicPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1988,124,2275,796) as "cryptidDynamicPanel"
	ModifyPanel cbRGB=(60928,60928,60928)
	SetVariable FineNumX,pos={474,388},size={50,20},disable=1
	SetVariable FineNumY,pos={534,388},size={50,20},disable=1
	SetVariable FineDistX,pos={594,388},size={50,20},disable=1
	SetVariable FineDistY,pos={654,388},size={50,20},disable=1
	SetVariable FineIterationsPerspot,pos={714,388},size={50,20},disable=1
	TitleBox searchGrid,pos={1,662},size={50,20}
	ToolsGrid snap=1,visible=1
	NewPanel/W=(0,0,0.234,0.98)/FG=(,,FR,)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	DrawLine 50,50,60,60
	DrawLine 19,207,253,207
	DrawLine 19,321,253,321
	SetDrawEnv fstyle= 1
	DrawText 19,225,"Spot Numbers"
	SetDrawEnv fstyle= 1
	DrawText 19,338,"Iteration Info"
	DrawLine 19,434,253,434
	SetDrawEnv fstyle= 1
	DrawText 19,455,"Operation Status"
	SetDrawEnv fstyle= 1
	DrawText 19,518,"Move To Spot"
	DrawLine 19,500,253,500
	SetVariable CoarseNumX,pos={24,46},size={207,16},proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable CoarseNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumX]
	SetVariable CoarseNumY,pos={24,88},size={210,16},proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable CoarseNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumY]
	SetVariable CoarseDistX,pos={24,67},size={210,16},proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable CoarseDistX,format="%.1W1Pm"
	SetVariable CoarseDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistX]
	SetVariable CoarseDistY,pos={24,111},size={209,16},proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable CoarseDistY,format="%.1W1Pm"
	SetVariable CoarseDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistY]
	SetVariable FineNumX,pos={28,43},size={207,16},disable=1,proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable FineNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumX]
	SetVariable FineDistX,pos={28,64},size={210,16},disable=1,proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable FineDistX,format="%.1W1Pm"
	SetVariable FineDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistX]
	SetVariable FineNumY,pos={28,85},size={210,16},disable=1,proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable FineNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumY]
	SetVariable FineDistY,pos={28,108},size={209,16},disable=1,proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable FineDistY,format="%.1W1Pm"
	SetVariable FineDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistY]
	SetVariable CoarseIterationsPerSpot,pos={24,135},size={209,16},proc=SearchSetVarProc,title="Iterations Per Spot"
	SetVariable CoarseIterationsPerSpot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseIterationsPerSpot]
	SetVariable FineIterationsPerspot,pos={28,134},size={209,16},disable=1,title="Iterations Per Spot"
	SetVariable FineIterationsPerspot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%FineIterationsPerSpot]
	TabControl tab0,pos={19,14},size={235,157},proc=SearchTabProc
	TabControl tab0,labelBack=(47872,47872,47872),tabLabel(0)="Coarse Grid Settings"
	TabControl tab0,tabLabel(1)="Fine Grid Settings",value= 0
	CheckBox UseFineSearch,pos={19,192},size={97,14},proc=SearchCheckProc,title="Use Fine Search"
	CheckBox UseFineSearch,value= 1
	SetVariable SpotNumber,pos={19,226},size={209,16},title="SpotNumber"
	SetVariable SpotNumber,limits={1,1e+06,1},value= root:Settings:SearchGrid:SearchSettings[%SpotNumber]
	SetVariable CoarseSpotNumber,pos={19,246},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseSpotNumber]
	SetVariable FineSpotNumber,pos={19,267},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineSpotNumber]
	SetVariable FineLevel,pos={19,288},size={209,16},title="Fine Level"
	SetVariable FineLevel,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineLevel]
	SetVariable MasterIteration,pos={19,341},size={209,16},title="Master Iteration"
	SetVariable MasterIteration,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration],noedit= 1
	SetVariable IterationsCurrentSpot,pos={19,363},size={209,16},title="Iterations at Current Spot"
	SetVariable IterationsCurrentSpot,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtCurrentSpot],noedit= 1
	SetVariable LastGoodIteration,pos={19,386},size={209,16},title="Last Good Iteration"
	SetVariable LastGoodIteration,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%LastGoodIteration],noedit= 1
	SetVariable CurrentMode,pos={19,458},size={200,16},title="Current Mode"
	SetVariable CurrentMode,value= root:Settings:SearchGrid:SearchMode[%CurrentMode]
	SetVariable Callback,pos={19,477},size={200,16},title="Callback"
	SetVariable Callback,help={"Executes this function after moving to the next spot"}
	SetVariable Callback,value= root:Settings:SearchGrid:SearchMode[%Callback]
	SetVariable CoarseSpotNumber1,pos={19,519},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber1,limits={1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%CoarseSpotNumber]
	SetVariable FineSpotNumber1,pos={19,540},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber1,help={"Put -1 to not use a fine position"}
	SetVariable FineSpotNumber1,limits={-1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%FineSpotNumber]
	Button MoveToSpot,pos={18,563},size={79,27},proc=SearchButtonProc,title="Move To Spot"
	CheckBox HotSpotManualOverride,pos={129,193},size={68,14},proc=SearchCheckProc,title="Stay Here!"
	CheckBox HotSpotManualOverride,help={"This will prevent the algorithm from moving the stage from this spot.  Good if you want to keep hitting this spot."}
	CheckBox HotSpotManualOverride,value= 0
	SetVariable IterationsPerHotSpot,pos={20,407},size={209,16},title="Iterations Per Hot Spot"
	SetVariable IterationsPerHotSpot,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtHotSpot]
	Button NextSpot,pos={99,563},size={79,27},proc=SearchButtonProc,title="Next Spot"
	PopupMenu SearchGridQuckSettingsPM,pos={19,595},size={143,22},proc=SearchGridQSPopMenuProc,title="Quick Settings"
	PopupMenu SearchGridQuckSettingsPM,mode=8,popvalue="ddFLN4",value= #"SearchQuickSettingsList()"
	CheckBox UseGraphSearch,pos={19,172},size={106,14},proc=SearchCHeckProc,title="Use Graph Search"
	CheckBox UseGraphSearch,value= 0
	CheckBox UseSpotLine,pos={220,172},size={38,14},proc=SearchCHeckProc,title="Line"
	CheckBox UseSpotLine,value= 0
	Button GetGraphPos,pos={129,172},size={80,18},proc=SearchButtonProc,title="Get Graph Pos"
	ToolsGrid snap=1,visible=1
	RenameWindow #,settingsPanel
	SetActiveSubwindow ##
	NewPanel/W=(1,1,1,1)/HOST=# 
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={13,54},size={203,16},title="Surface Trigger"
	SetVariable SurfaceTrigger1,format="%.1W1PN"
	RenameWindow #,P0
	SetActiveSubwindow ##
EndMacro


Window cryptidDynamicPanelTEMP() : Panel

	NewPanel/N=cryptidDynamicPanel/W=(0,0,0.234,0.98)
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	DrawLine 50,50,60,60
	DrawLine 19,207,253,207
	DrawLine 19,321,253,321
	SetDrawEnv fstyle= 1
	DrawText 19,225,"Spot Numbers"
	SetDrawEnv fstyle= 1
	DrawText 19,338,"Iteration Info"
	DrawLine 19,434,253,434
	SetDrawEnv fstyle= 1
	DrawText 19,455,"Operation Status"
	SetDrawEnv fstyle= 1
	DrawText 19,518,"Move To Spot"
	DrawLine 19,500,253,500
	SetVariable CoarseNumX,pos={24,46},size={207,16},proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable CoarseNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumX]
	SetVariable CoarseNumY,pos={24,88},size={210,16},proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable CoarseNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumY]
	SetVariable CoarseDistX,pos={24,67},size={210,16},proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable CoarseDistX,format="%.1W1Pm"
	SetVariable CoarseDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistX]
	SetVariable CoarseDistY,pos={24,111},size={209,16},proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable CoarseDistY,format="%.1W1Pm"
	SetVariable CoarseDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistY]
	SetVariable FineNumX,pos={28,43},size={207,16},disable=1,proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable FineNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumX]
	SetVariable FineDistX,pos={28,64},size={210,16},disable=1,proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable FineDistX,format="%.1W1Pm"
	SetVariable FineDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistX]
	SetVariable FineNumY,pos={28,85},size={210,16},disable=1,proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable FineNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumY]
	SetVariable FineDistY,pos={28,108},size={209,16},disable=1,proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable FineDistY,format="%.1W1Pm"
	SetVariable FineDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistY]
	SetVariable CoarseIterationsPerSpot,pos={24,135},size={209,16},proc=SearchSetVarProc,title="Iterations Per Spot"
	SetVariable CoarseIterationsPerSpot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseIterationsPerSpot]
	SetVariable FineIterationsPerspot,pos={28,134},size={209,16},disable=1,title="Iterations Per Spot"
	SetVariable FineIterationsPerspot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%FineIterationsPerSpot]
	TabControl tab0,pos={19,14},size={235,157},proc=SearchTabProc
	TabControl tab0,labelBack=(47872,47872,47872),tabLabel(0)="Coarse Grid Settings"
	TabControl tab0,tabLabel(1)="Fine Grid Settings",value= 0
	CheckBox UseFineSearch,pos={19,192},size={97,14},proc=SearchCheckProc,title="Use Fine Search"
	CheckBox UseFineSearch,value= 1
	SetVariable SpotNumber,pos={19,226},size={209,16},title="SpotNumber"
	SetVariable SpotNumber,limits={1,1e+06,1},value= root:Settings:SearchGrid:SearchSettings[%SpotNumber]
	SetVariable CoarseSpotNumber,pos={19,246},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseSpotNumber]
	SetVariable FineSpotNumber,pos={19,267},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineSpotNumber]
	SetVariable FineLevel,pos={19,288},size={209,16},title="Fine Level"
	SetVariable FineLevel,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineLevel]
	SetVariable MasterIteration,pos={19,341},size={209,16},title="Master Iteration"
	SetVariable MasterIteration,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration],noedit= 1
	SetVariable IterationsCurrentSpot,pos={19,363},size={209,16},title="Iterations at Current Spot"
	SetVariable IterationsCurrentSpot,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtCurrentSpot],noedit= 1
	SetVariable LastGoodIteration,pos={19,386},size={209,16},title="Last Good Iteration"
	SetVariable LastGoodIteration,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%LastGoodIteration],noedit= 1
	SetVariable CurrentMode,pos={19,458},size={200,16},title="Current Mode"
	SetVariable CurrentMode,value= root:Settings:SearchGrid:SearchMode[%CurrentMode]
	SetVariable Callback,pos={19,477},size={200,16},title="Callback"
	SetVariable Callback,help={"Executes this function after moving to the next spot"}
	SetVariable Callback,value= root:Settings:SearchGrid:SearchMode[%Callback]
	SetVariable CoarseSpotNumber1,pos={19,519},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber1,limits={1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%CoarseSpotNumber]
	SetVariable FineSpotNumber1,pos={19,540},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber1,help={"Put -1 to not use a fine position"}
	SetVariable FineSpotNumber1,limits={-1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%FineSpotNumber]
	Button MoveToSpot,pos={18,563},size={79,27},proc=SearchButtonProc,title="Move To Spot"
	CheckBox HotSpotManualOverride,pos={129,193},size={68,14},proc=SearchCheckProc,title="Stay Here!"
	CheckBox HotSpotManualOverride,help={"This will prevent the algorithm from moving the stage from this spot.  Good if you want to keep hitting this spot."}
	CheckBox HotSpotManualOverride,value= 0
	SetVariable IterationsPerHotSpot,pos={20,407},size={209,16},title="Iterations Per Hot Spot"
	SetVariable IterationsPerHotSpot,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtHotSpot]
	Button NextSpot,pos={99,563},size={79,27},proc=SearchButtonProc,title="Next Spot"
	PopupMenu SearchGridQuckSettingsPM,pos={19,595},size={143,22},proc=SearchGridQSPopMenuProc,title="Quick Settings"
	PopupMenu SearchGridQuckSettingsPM,mode=8,popvalue="ddFLN4",value= #"SearchQuickSettingsList()"
	CheckBox UseGraphSearch,pos={19,172},size={106,14},proc=SearchCHeckProc,title="Use Graph Search"
	CheckBox UseGraphSearch,value= 0
	CheckBox UseSpotLine,pos={220,172},size={38,14},proc=SearchCHeckProc,title="Line"
	CheckBox UseSpotLine,value= 0
	Button GetGraphPos,pos={129,172},size={80,18},proc=SearchButtonProc,title="Get Graph Pos"
	ToolsGrid snap=1,visible=1
	RenameWindow #,settingsPanel




End

//Determine the "ZeroVoltage"
Function DetermineDeflectionOffset([callback])
	
	string callback

	if(paramIsDefault(callback))
		callback="cryptidMain(4)"
	endif

	Make/O/N=100 root:Settings:Cryptid:DeflectionOffsetData
	
	Wave DeflectionOffsetData=root:Settings:Cryptid:DeflectionOffsetData
	Variable Error=0
	
	wave/t tSettings = getCryptidSettings(1)
	
	//Removed td_stop, as it (hopefully) wasn't needed and could cause issues with high-bandwith data collection
	//Error+=td_stop()
	
	Error+= td_xSetInWave(0, "0", tSettings[%primaryDeflectionChannel], DeflectionOffsetData, "deflectionOffsetCallback("+callback+")",100)

	// Execute motion
	Error +=td_WriteString("Event.0", "once")

	if (Error>0)
		print "Error in DetermineFCOffset: "+num2str(Error)
	endif
End

Function deflectionOffsetCallback(callback)

	string callback
	
	td_stopInWaveBank(0)
	wave vSettings = getCryptidSettings(0)
	Wave DeflectionOffsetData=root:Settings:Cryptid:DeflectionOffsetData
	
	waveStats/Q DeflectionOffsetData
	Variable deflectionOffset=v_avg
	 killWaveStats()
	vSettings[%deflVOffset]=deflectionOffset
	
	execute callback
	
End

///////////////////////GENERAL UTILITIES/////////////////////////////



Function cryptidStop()

	wave vSettings = getCryptidSettings(0)
	vSettings[%stop] = 1
	doScanFunc("StopScan_0")
	listbox StackDisplay disable=0, win=$getCStr("DynamicPanelName")
	updateStatus("STOPPED",error=1)
	//kill background tasks
	ARBackground("Kill",0,"")
	//stop data collection
	td_stopInWaveBank(-1)
	td_stopOutWaveBank(-1)

End

Function test1()
	cryptidStop()
	
	doAlert 0, "TEST"

End

Function cryptidContinue()

	wave vSettings = getCryptidSettings(0)
	vSettings[%stop] = 0
	
	//stop any alterations from being made to the listbox (controls the current DF)
	listbox StackDisplay disable=2, win=$getCStr("DynamicPanelName")
	updateStatus("Starting...")
	cryptidMain(0)

End

Function openDNACalibrate()

	wave temp = waveRefIndexed("",1,1)
	if (!WaveExists(temp))
		Wave temp = waveRefIndexed("",0,1)
	endif

	if(windowExists("DNACalibrateWindow"))
		killWindow DNACalibrateWindow
	endif
	
	display/K=1/N=DNACalibrateWindow temp
	showInfo/CP=0
	
	//Place the cursors approximately where they need to go
	Variable ignoreTime = 2 //s, ~600 nm
	Variable lastTime = pnt2x(temp, dimsize(temp,0)-1)
	WaveStats/Q/R=(ignoreTime,lastTime) temp
	
	Variable minLocTime = v_minLoc
	
	Variable top2H = -0.07782
	Variable h2g = -0.07048
	Variable g2f = -0.2965
	Variable f2e = -0.6028
	Variable e2d = -0.35466
	Variable d2c = -0.04888
	Variable top2A = + 0.31098
	Variable B = lastTime
	
	Cursor/A=1 A $waveName("DNACalibrateWindow",0,1) v_minLoc+top2A
	Cursor/A=1 B $waveName("DNACalibrateWindow",0,1) B
	
	Cursor/A=1 H $waveName("DNACalibrateWindow",0,1) v_minLoc+top2H
	Cursor/A=1 G $waveName("DNACalibrateWindow",0,1) v_minLoc+top2H+h2g
	
	Cursor/A=1 F $waveName("DNACalibrateWindow",0,1) v_minLoc+top2H+h2g+g2f
	Cursor/A=1 E $waveName("DNACalibrateWindow",0,1) v_minLoc+top2H+h2g+g2f+f2e
	
	Cursor/A=1 D $waveName("DNACalibrateWindow",0,1)  v_minLoc+top2H+h2g+g2f+f2e+e2d
	Cursor/A=1 C $waveName("DNACalibrateWindow",0,1) v_minLoc+top2H+h2g+g2f+f2e+e2d+d2c
	

End

Function/S cryptidTimerProgress(title, estTime, [background])
	
	string title
	variable estTime, background
	
	if(paramIsDefault(background))
		background = 0
	endif
	
			
	if(windowExists("progressWindow"))
		killWindow progressWindow
	endif
	
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1199,631,1582,752)/N=progressWindow as title

	ValDisplay CryptidProgress,pos={32,52},size={324,24},font="Arial",fSize=20, win=progressWindow
	ValDisplay CryptidProgress,format="%4.2f",limits={0,10,0},barmisc={0,0},mode= 3, win=progressWindow
	TitleBox progressUpdatePanel,pos={33,17},size={43,25},title=title,fSize=20, win=progressWindow
	TitleBox progressUpdatePanel,frame=0,fStyle=1, win=progressWindow
	
	wave vSettings = getCryptidSettings(0)
	vSettings[%random] = ticks/60
	
	ValDisplay CryptidProgress,value= #"ticks/60 - root:Settings:Cryptid:vSettings[%random]",limits={0,estTime,0}, win=progressWindow
	
	
	doUpdate/E=1/W=progressWindow
	setWindow progressWindow hook(cryptidTimerHook)=cryptidProgressHook
	
	if (backGround)
		NVAR timerTime
		if(!NVAR_Exists(timerTime))
			variable/G timerTime
		endif
		NVAR totalTimerTime
		if(!NVAR_Exists(totalTimerTime))
			variable/G totalTimerTime
		endif
		
		timerTime = 0
		totalTimerTime = estTime
		
		ARBackground("cryptidTimerBackground",1,"")
	endif

	return "progressWindow"

End

Function cryptidTimerBackground()

	NVAR timerTime, totalTimerTime
	timerTime += 1
	controlUpdate cryptidProgress
	if (timerTime >= totalTimerTime)
		return 1
	endif
	
	return 0

End

Function cryptidProgressHook(s)
	STRUCT WMWinHookStruct &s

	Variable hookResult = 0

	switch(s.eventCode)
		case 23:
			controlUpdate cryptidProgress
			break
		case 7:
			controlUpdate cryptidProgress
			break
	endswitch

	return hookResult		// 0 if nothing done, else 1
End

Window progressPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1199,631,1582,752)
	ShowTools/A
	
	NewPanel /W=(1199,631,1582,720) as "Test"
	ValDisplay CryptidProgress,pos={32,52},size={324,24},font="Arial",fSize=20
	ValDisplay CryptidProgress,format="%4.2f",limits={0,10,0},barmisc={0,0},mode= 3
	ValDisplay CryptidProgress,value= #"ticks/60 - root:Settings:Cryptid:vSettings[%random]"
	TitleBox progressUpdatePanel,pos={33,17},size={43,25},title="Test",fSize=20
	TitleBox progressUpdatePanel,frame=0,fStyle=1
	SetWindow kwTopWin,hook(cryptidCount)=cryptidProgressHook
	
	ValDisplay CryptidProgress,value= #"Root:Packages:MFP3D:Meter:ReadMeterRead[%DetectorSum][0]",limits={0,10,0}
EndMacro


//This function will be ran every time an experiment is loaded
//This solves a version issue, where the loaded experiment contains older versions of the module, which
//are missing certain settings. This function checks all settings waves and dim labels against the current
//version, and adds the missing settings/waves. The user must resave the experiment once this has been done

//(I'm proud of how shitty this looks and well it works)
Function checkAndFixOldSettingsWaves()

	string OGDF = getDataFolder(1)
	wave/t CStack = getCryptidStack()
	Variable numberOfSteps = dimsize(Cstack,0)
	Variable i
	Variable changed = 0
	
	string changeLog = ""
	
	
	//Go through every step in the current stack. In each one, check every wave and every label against the newest version
	for(i=0;i<numberOfSteps;i+=1)

		//Set up the new waves in the temp folder
		killDataFolder/Z root:temp
		newDataFolder/S root:temp
		
		//Build the newest version settings inside of it
		wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
		wave/t tSettings = getCryptidSettings(1)
		string expType = getStepType(stepName = CStack[i][%Name])
		execute experimentExecutables[%$expType][%tWaveSetup]
		execute experimentExecutables[%$expType][%vWaveSetup]
		
		//Make a wave wave with all of the new settings waves 
		string newWaveList = waveList("*",";","")
		variable numberOfNewWaves = itemsInList(newWaveList)
		Make/Wave/O/N=(numberOfNewWaves) root:Temp:newWaves
		Wave/Wave newWaves = root:Temp:newWaves
		Variable j = 0
		for(j=0;j<numberOfNewWaves;j+=1)
			string currentWaveName = stringFromList(j, newWaveList)
			newWaves[j] = $stringFromList(j,newWaveList)
			SetDimLabel 0,j,$currentWaveName,newWaves
		endFor
		
		//Make a wave wave with all of the old settings waves
		string oldFolderLoc = getWorkingFolder(CStack[i][%Name])
		setDataFolder $oldFolderLoc
		string oldWaveList = waveList("*",";","")
		variable numberOfOldWaves = itemsInList(oldWaveList)
		Make/Wave/O/N=(numberOfOldWaves) root:Temp:OldWaves
		Wave/Wave oldWaves = root:Temp:OldWaves
		j = 0
		for(j=0;j<numberOfOldWaves;j+=1)
			currentWaveName = stringFromList(j, oldWaveList)
			oldWaves[j] = $currentWaveName
			SetDimLabel 0,j,$currentWaveName,oldWaves
		endFor

		//Crosscheck all of the waves, adding copies of the default from the new if the old folder doesn't have it
		//Then check the labels of all waves, and add the ones that need to be added
		for(j=0;j<numberOfNewWaves;j+=1)
			currentWaveName = getDimLabel(newWaves, 0, j)
			Wave currentWave = newWaves[j]
			
			//Add any new waves if there are any
			if (FindDimLabel(oldWaves, 0, currentWaveName) == -2)
				//Copy that wave into the old folder
				Changed = 1
				
				string change =  CStack[i][%Name]+": Wave added: "+currentWaveName+"\r"
				changeLog += change
				
				duplicate/o currentWave $oldFolderLoc+currentWaveName
			else
			
				Wave tempOldWave = oldWaves[%$currentWaveName]
				//Go through each dimlabel in the settings to make sure its there, add if not
				Variable size = dimsize(currentWave,0)
				Variable k
				for(k=0;k<size;k+=1) 
					string currentLabel = getDimLabel(currentWave,0,k)
					//If the wave doesn't have labels, dont copy them
					If (stringMatch(currentLabel,""))
						k=size
					elseif (FindDimLabel(tempOldWave, 0, currentLabel) == -2 )
						//Add that settings to the new Wave
						//Might not work for multidimensional waves
						Variable newWaveSize = dimsize(tempOldWave,0)+1
						redimension/N=(newWaveSize,-1) tempOldWave
						setDimLabel 0, newWaveSize-1, $currentLabel, tempOldWave
						Changed = 1
						change =  CStack[i][%Name]+":"+currentWaveName+": Label added: "+currentLabel+"\r"
						
						changeLog += change
						
						//Set the value equal
						tempOldWave[%$currentLabel][0] = currentWave[%$currentLabel][0]
						
					endif
					
				endFor
			
			endif
			
		endFor
		
	endFor

	killDataFolder/Z root:temp

	if (changed)
		doAlert 0, "A setting in this experiment was outdated and changed. It's recommended that you resave the experiment\r\r"
		print "ChangeLog:\r"+changeLog
	endif

End


Function MakeZPositionFinalCryptid(Zposition,[ForceDist,Indexes,DirInfo])
	Wave Zposition
	Variable ForceDist
	String Indexes, DirInfo

	String FPName, DataName, BaseName, Suffix, SectionStr, DataType

	if (ParamIsDefault(Indexes) || ParamIsDefault(DirInfo) || ParamIsDefault(ForceDist))
		DataName = NameOfWave(ZPosition)
		ExtractForceWaveName(DataName,BaseName,Suffix,DataType,SectionStr)
		FPName = BaseName+Suffix
		String DataFolder = GetForceDataFolderByWave(ZPosition)
		Variable ColIndex
		Wave/T HeaderWave = $GetForceHeaderWave(DataFolder,FPName,ColIndex)
		if (ColIndex < 0)
			String StackList = GetRTStackInfo(0)
			Print "Bad Wave in "+GetFuncName()
			Print "See Function "+StringFromList(ItemsInList(StackList,";")-3,StackList,";")+" -> "+StringFromList(ItemsInList(StackList,";")-2,StacKList,";")
			Print "WaveName: "+GetWavesDataFolder(Zposition,2)
			DoWindow/H
			return(0)
		endif
	
		Indexes = GetHeaderParm(HeaderWave,"Indexes",ColIndex)
		DirInfo = GetHeaderParm(HeaderWave,"Direction",ColIndex)
		
		
		if (Str2num(GetHeaderParm(HeaderWave,"DwellSetting",ColIndex)) == 0)
			ForceDist = Inf
		else
			ForceDist = Str2num(GetHeaderParm(HeaderWave,"ForceDist",ColIndex))
		endif

	endif

	Variable Nop = DimSize(ZPosition,0)
	Variable SampleRate = 1/DimDelta(ZPosition,0)
	
	Variable Rate = ZPosRateFunc(SampleRate,ForceDist,RightX(ZPosition),nop,DirInfo)
	
	if (Nop < 400)
		MakeZPositionOldCryptid(Zposition,Indexes=Indexes,DirInfo=DirInfo)
	else
		MakeZPositionNew(Zposition,Rate,Indexes=Indexes,DirInfo=DirInfo)
	endif
	
	return(Rate)	
End //MakeZPositionFinal


//Copy of the function makeZPositionOld with modifications to
//prevent issues with the stopIndex being out of range for some reason
//I think a lot of these issues stem from using a pathway designed for saving CTFCs for non CTFCs..
Function MakeZPositionOldCryptid(Zposition,[Indexes,DirInfo])
	Wave Zposition
	String Indexes, DirInfo
	
	String DataName, FPName, BaseName, Suffix, SectionStr, DataType
	String ParmFolder = ARGetForceFolder("Parameters","","")
	
	if (ParamIsDefault(Indexes) || ParamIsDefault(DirInfo))
		DataName = NameOfWave(ZPosition)
		ExtractForceWaveName(DataName,BaseName,Suffix,DataType,SectionStr)
		FPName = BaseName+Suffix
		String DataFolder = GetForceDataFolderByWave(ZPosition)
		Variable ColIndex
		Wave/T HeaderWave = $GetForceHeaderWave(DataFolder,FPName,ColIndex)
		if (ColIndex < 0)
			String StackList = GetRTStackInfo(0)
			Print "Bad Wave in "+GetFuncName()
			Print "See Function "+StringFromList(ItemsInList(StackList,";")-3,StacKList,";")+" -> "+StringFromList(ItemsInList(StackList,";")-2,StacKList,";")
			Print "WaveName: "+GetWavesDataFolder(Zposition,2)
			DoWindow/H
			return(0)
		endif
	
		Indexes = GetHeaderParm(HeaderWave,"Indexes",ColIndex)
		DirInfo = GetHeaderParm(HeaderWave,"Direction",ColIndex)
	endif
	
	
	
	Variable DoFilter = numtype(str2num(StringFromList(0,DirInfo,","))) == 1
	//this means that the dwells are a defl -> Z%output feedback loop
	//we don't know where things are moveing to
	//so we can only filter.
	
	Variable nop = ItemsInList(Indexes,",")
	if (Nop <= 0)
		return(0)
	endif
	Wave IndexWave = InitOrDefaultWave(ParmFolder+"IndexWave",nop)
	Wave PullDirWave = InitOrDefaultWave(ParmFolder+"PullDirWave",nop)
	
	Str2ArrayFast(Indexes,",",IndexWave)
	Str2ArrayFast(DirInfo,",",PullDirWave)
	IndexWave[Nop-1] += 1		//These Indexes are indexes to the START of the next section.
	//as the last index is only used as the stop index, we need to add 1 to make sure we get that last point.
	
	
	Wave FitCoef = InitOrDefaultWave(ParmFolder+"ZposCoef",nop-1)
	Redimension/N=(nop-1) FitCoef
	FitCoef[] = Mod(p+1,2)*2+5		//7,5,7,5,7,5,7....
//	LinSpace2(7,5,nop-1,FitCoef)
	
	FitCoef = round(FitCoef)
	
	if (nop == 3)				//single pull, no dwell
		FitCoef = 7
	elseif ((SumAbs(PullDirWave,1,nop-2) == 4) && (nop == 5))			//dual pull, no dwell
		FitCoef[1,nop-2] = 6
	elseif (nop == 7)		//for now this is a dual pull with dual dwell.
		FitCoef[3] = 5			//this is the pull between the dwells, if it is a 6th or higher Igor spits out a sigualar value message.
	elseif (nop == 5)		//single pull, dual dwell.
		Variable FirstDwell = WhichListItem("0",DirInfo,",",0,0)
		if (StringMatch(StringFromList(FirstDwell+1,DirInfo,","),"0"))
			//indent force plot
			//those are marked, which ones get fit, and which get filtered
		else
			//Probably force clamp.
			DoFilter = 1
		endif
		
		//This is an older style, that does not have the inf in the indexes
		//so we will put it in.
	endif
	
	Wave/D AR_Coef = InitOrDefaultWave(ParmFolder+"AR_Coef",0,Wave_Type=0x4)
	IndexWave = Round(IndexWave)
	Variable BoxSizeRamp = 20e-3		//seconds
	Variable BoxSize = 10e-3
	BoxSize = round(BoxSize/DimDelta(ZPosition,0))
	BoxSizeRamp = round(BoxSizeRamp/DimDelta(ZPosition,0))
	//this is also the size of the turn around that is filtered.
	
	Variable A, DirNum, BoxStart, BoxStop
	Variable StartIndex, StopIndex
	for (A = 1;A < nop;A += 1)
		DirNum = str2num(StringFromList(A,DirInfo,","))
		StartIndex = IndexWave[A-1]+(A>1)*(BoxSizeRamp+2)
		StopIndex = IndexWave[A]-1
		if (StopIndex < StartIndex)
			Continue		//give up in <edit> fustration
		endif
		BoxStart = IndexWave[A-1]+(A>1)
		if (!DirNum && DoFilter)
			BoxStop = StopIndex
			StopIndex = 0
		else
			BoxStop = StartIndex
		endif
	
		if (!DirNum && DoFilter)
			if (BoxStop-BoxStart+1 >= BoxSize+2)
				Duplicate/O/R=[BoxStart,BoxStop] Zposition,$ParmFolder+"TempSmooth"
				Wave TempSmooth = $ParmFolder+"TempSmooth"
				Smooth/B=1/E=3 BoxSize,TempSmooth
				ZPosition[BoxStart,BoxStop] = TempSmooth(X)
			endif
		else
			if (BoxStop-BoxStart+1 >= BoxSizeRamp+2)
		
				//5th order poly on the start of the ramp
				Redimension/N=(5) AR_coef
				CurveFit/Q poly 5,kwCWave=AR_coef,Zposition[BoxStart,BoxStop]
				ZPosition[BoxStart,BoxStop] = Poly(AR_Coef,X)
			endif
		endif
		
		if (StopIndex-StartIndex > FitCoef[A-1]+1)
			Redimension/N=(FitCoef[A-1]) AR_coef
			
			//BDEdit to fix z_snsr_save issue
			variable zSize = dimsize(zPosition,0)
			if ( stopIndex > (zSize-1))
				stopIndex = zSize - 1
			endif
			
			CurveFit/Q poly FitCoef[A-1],kwCWave=AR_coef,Zposition[StartIndex,StopIndex]
			Zposition[StartIndex,StopIndex] = poly(AR_Coef,x)
		endif
			
	endfor
End //MakeZPositionOld

Function CryptidPopupMenu(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa
	
	string ctrlName = pa.ctrlName
	string popStr = pa.popStr
	variable popNum = pa.popNum
	
	switch( pa.eventCode )
		case 2: // mouse up
			wave/t tSettings = getCryptidSettings(1)
			tSettings[%$ctrlName] = popStr	
			
			strSwitch(ctrlName)
			
				case "yAxisOption":
					updateCryptidGraph()
					break
				case "xAxisOption":	
					updateCryptidGraph()
					break

			endSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function LDMotorButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			string ctrlName = ba.ctrlName
			strSwitch(ctrlName)
				variable umStep = 1
				case "LDUP":
					print MotorCheckForWithdrawn()
					print DoLDMove(0, umStep)
					break
				case "LDDown":
					DoLDMove(0, -umStep)
					break
				case "LDLeft":
					DoLDMove(-umStep,0)
					break
				case "LDRight":
					DoLDMove(+umStep,0)
					break
			endSwitch
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

//Used to diagnose speed issues
Function cryptidTimer(num)

	variable num
	
	return 1 	//Comment out if you want to use
	wave/T cryptidTimes =  root:cryptidTimes
	if(!WaveExists(cryptidTimes))
		make/T/O/N=(0,3) root:cryptidTimes
		Wave/T cryptidTimes =  root:cryptidTimes
	endif
	
	if(num > dimsize(cryptidTimes,0)-1)
		insertPoints num, 1, cryptidTimes
	endif
	
	NVAR lastTime = root:lastTime
	if (!NVAR_exists(lastTime) || lastTime == 0)
		variable/G root:lastTime = ticks
		NVAR lastTime = root:lastTime
	endif
	
	variable current = ticks
	variable timeDelta = (current - lastTime)/60
	lastTime = current
	
	cryptidTimes[num][0] = GetRTStackInfo(2)
	cryptidTimes[num][1] = num2str(num)
	cryptidTimes[num][2] = num2str(timeDelta)
	
	//print GetRTStackInfo(2)+"						num: "+num2str(num)+ "	delta: "+num2str(timeDelta)+"\r"
End

Function resetCryptidTimer()
	
	NVAR lastTime = root:lastTime
	lastTime=0
	
End



//Moves the graph next to the cryptidWindow
Function updateGraphPosition()

	string panelName = getCStr("panelName")
	string graphName = getCStr("cryptidGraphName")
	
	if(!windowExists(graphName))
		execute "cryptidGraph()"
	endif
	
	GetWindow $panelName, wSize
	variable Left = v_left
	variable Top = v_top
	variable Right = v_right
	variable bottom = v_bottom
	
	GetWindow $graphName, wSize
	variable width = v_right - v_left
	variable height = v_bottom - v_top
	
	variable gap = 12
	
	MoveWindow/W=$graphName right+gap,Top,right+width+gap,top+height
End

Function CryptidButton(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	
	string controlName = ba.ctrlName
	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			strSwitch(controlName)
				case "EditSearchGrid":
					doWindow/F searchGridDisplay
					replaceSettingsPanel(getCStr("SettingsPanelName"))
					break
				case "ViewSearchGrid":
					doWindow/F searchGridDisplay
					break
				case "resetSearchGrid":
					initSearch(showUserInterface=0,justReset=1)
					break
				case "CharacterizeCantilever":
					CantileverTest()
					break
				case "getGraph":
					updateGraphPosition()
					break
				case "resetFullIter":
					wave vSettings = getCryptidSettings(0)
					Vsettings[%fullIterations] = 0
					break
				case "viewLog":
					viewEL()
					break
				case "AddStep":
					cryptidAddStep()
					break
				case "AddStepBeforeSelected":
					cryptidAddStep(position=getSelectedStep())
					break
				case "SingleRun":
					wave vSettings=getCryptidSettings(0)
					vSettings[%singleRun] = 1
					vSettings[%stop] = 0
					vSettings[%iterationsSinceLastButton] = -1
					
					//Show the search Grid panel
					replaceSettingsPanel(getCStr("SettingsPanelName"))
					listbox StackDisplay disable=2, win=$getCStr("DynamicPanelName")
					updateStatus("Starting...")
					cryptidMain(4)
					break
					
				case "Execute":
					wave vSettings = getCryptidSettings(0)
					vSettings[%stop] = 0
					vSettings[%iterationsSinceLastButton] = -1
					
					//Show the search Grid panel
					replaceSettingsPanel(getCStr("SettingsPanelName"))
					listbox StackDisplay disable=2, win=$getCStr("DynamicPanelName")
					updateStatus("Starting...")
					cryptidMain(0)
					//stop any alterations from being made to the listbox (controls the current DF)

					break
					
				case "ExecuteStep":
					
					cryptidMain(3)
					break
				case "Continue":
					cryptidContinue()
					break
				case "Stop":
					//Changed to that instead of stopping after the current step, finishes the current run
					//so data can be saved if it's good
					wave vSettings = getCryptidSettings(0)
					//vSettings[%stop] = 1
					vSettings[%singleRun]=1
					updateStatus("Stopping after run...")
					break
				case "StopNow":
					cryptidStop()
					break
				case "SkipRun":
					cryptidStop()
					cryptidContinue()
					break
				case "removeStep":
					replaceSettingsPanel(getCStr("SettingsPanelName"))
					cryptidRemoveStep(getSelectedStep())
					break
				case "singleForce":
					wave vSettings = getCryptidSettings(0)
					vSettings[%stop]=0
					replaceSettingsPanel(getCStr("SettingsPanelName"))
					cryptidMain(3)					
					break
				case "fixScale":
					setAxis/A/W=$"CryptidPanel#G0" bottom
					setAxis/A/W=$"CryptidPanel#G0" left
					break
				case "SaveExperiment":
					cryptidSaveExperiment() 
					break
					
				case "LoadExperiment":
					cryptidLoadExperiment()
					break
				case "OpenDNACalibrate":
					openDNACalibrate()
		
					break
				case "ReplaceThermal":
				//	replaceThermal()
					break
				case "DNACalibrate":
					DNACalibrate()
					break
				case "resetEnviron":
					InitEnviron()
					break
				case "saveDNACalibration":
					string DateCal = Secs2Date(DateTime,-2)
					string TimeCal = Secs2Time(DateTime,0)
					timeCal = replaceString(":",timeCal,"-")
					timeCal = replaceString(" ",timeCal,"-")
					string saveName = "DNA"+DateCal//+"_"+timeCal
					print "Saved as "+ saveName
					string startDF = getDataFolder(1)
					setDataFolder root:
					duplicate/O root:DNACalibration $saveName
					duplicate/O root:DNACalibrationZSensor $"Z"+saveName
					cryptidSaveWaves(root:DNACalibration,root:DNACalibrationZSensor, saveName = saveName)
					setDataFolder $startDF
					break
				case "RenameStep":
					renameCryptidStep()
					break
				case "StartDriftWait":
				
					break
				case "StopDrift":
				
					break
				case "UpdateDate":
					PS("SaveImage;SaveForce;","")
					SetupDefaultSavePaths()
					break
			endSwitch
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End
