#pragma rtGlobals=1		// Use modern global access method.
#pragma version=9.2

//Empty functions to allow compiling in offline mode
Function initEnviron()

End
Function zeroPD()

End
Function disableFocusAutoCorrect()

End
Function findLDMotorsHome()

End
Function MotorCheckForWithdrawn()

End
Function DoLDMove(a,b)
	variable a,b
end