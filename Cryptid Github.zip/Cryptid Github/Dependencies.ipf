#pragma rtGlobals=1		// Use modern global access method.
#pragma version=9.2

//Software written by Brandon Dzuba in order to automate various data acquisition protocols
#include ":Packages:SearchGrid:SearchGrid"
#include ":Packages:ExperimentInfo:ExperimentInfo"
#include ":Packages:InvolsThermalUpdate:InvolsThermalUpdate"
#include ":Packages:ZeroThePD:ZeroThePD"
#include ":Packages:Centering:BDThermalDNACalibration"
#include ":Packages:CryptidFunctions"
#include ":Dependencies:CantileverCharacterization"
#include ":Dependencies:UserInfo"

//Packages to include
#include ":Packages:ForceRamp:ForceRamp"
#include ":Packages:ForceClamp:ForceClamp"
#include ":Packages:zWave:zWave"
#include ":Packages:Centering:Centering"
#include ":Packages:ParamChange:ParamChange"
#include ":Packages:Dwell:Dwell"
#include ":Packages:DataCapture:DataCapture"
#include ":Packages:Repeat:Repeat"
#include ":Packages:FunctionCall:FunctionCall"
#include ":Packages:OIASubtract:OIASubtract"
#include ":Packages:DiscordMessage:DiscordMessage"
#include ":Packages:zRamp:zRamp"
#include ":Packages:HighSpeedRamp:HighSpeedRamp"