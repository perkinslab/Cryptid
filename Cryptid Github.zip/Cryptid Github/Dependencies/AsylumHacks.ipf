#pragma rtGlobals=3		// Use modern global access method and strict wave access.


Function clearMFP()

	//Push deleteAll button
	Variable HowMuch = ~2

//Bit 0, ForceCurves...
//Bit 1, Stored Data...

	DoWindow/K $cARGFGN
	DoWindow/K SelectFPByFolderPanel

	String SavedDataFolder = ActuallyQuoteName(GetDataFolder(1))

	Variable DoubleCheck = 0
	String ParmFolder = ARGetForceFolder("Parameters","","")
	Wave/T/Z ForceLoadDirs = $ParmFolder+"ForceLoadDirs"
	Wave/T/Z ForceUnLoadDirs = $ParmFolder+"ForceUnLoadDirs"

	String FolderList = ""
	FolderList += "SubFolders;Data;Locks;Undo;Restore;Parameters:Modify;Parameters:Delete;"

	Variable A, nop = ItemsInList(FolderList,";")
	Variable B, nopB
	String DeathList, DeathFolder

	for (A = 0;A < nop;A += 1)
		if (!(HowMuch & 2^A))
			Continue			//LET it Live!
		endif
		DeathFolder = ARGetForceFolder(StringFromList(A,FolderList,";"),"","")
		SafeKillDataFolderTree(DeathFolder,0)
		if (!A)
			DeathFolder = UpDir(DeathFolder)		//We started 1 level down in this case.
		endif
		SetDataFolder(DeathFolder)
		DeathList = WaveList("*",";","")
		nopB = ItemsInList(DeathList,";")
		for (B = 0;B < nopB;B += 1)
			SafeKillWaves($StringFromList(B,DeathList,";"))
		endfor
		
		
	endfor
	
	
	DeathList = ARWaveList(ParmFolder,"*ForceHeaderWave",";","")		//MFS [Multi Folder Support]
	nop = ItemsInList(DeathList,";")
	for (A = 0;A < nop;A += 1)
		Wave/T ForceHeaderWave = $ParmFolder+StringFromList(A,DeathList,";")
		Redimension/N=(-1,1) ForceHeaderWave
		SetDimLabel 1,0,DefaultValue,ForceHeaderWave
		Note/K ForceHeaderWave
		if (!StringMatch(StringFromList(A,DeathList,";"),"ForceHeaderWave"))
			ReallySafeKillWaves(ForceHeaderWave)
		endif
	endfor
	
	ClearUserCalculatedForceTypes()
	
	
	DeathList = ARWaveList(ParmFolder,"*LookUpTable",";","")
	DeathList += ARWaveList(ParmFolder,"*AutoOffset*DoneList",";","")
	DeathList += ARWaveList(ParmFolder,"*ElasticParms*",";","")
	DeathList = ListMultiply(ParmFolder,DeathList,";")
	DeathList += ListMultiply(ARGetForceFolder("Data","",""),"MasterFPList;MasterFPBuddy;",";")
	DeathList += ListMultiply(ARGetForceFolder("Parameters:Modify","",""),"MasterFPList;MasterFPBuddy;",";")
	DeathList += ListMultiply(ARGetForceFolder("Parameters:Delete","",""),"MasterFPList;MasterFPBuddy;",";")	

	SafeKillWaveList(DeathList,";")
	ReallySafeKillDataFolder(ARGetForceFolder("Elastic","",""))
	
	
	if (DatafolderExists(SavedDataFolder))
		SetDataFolder(SavedDataFolder)
	else
		SetDataFolder root:
	endif
	
	Wave/Z InvolsKStorage = $ParmFolder+"FMapInvolsK"
	if (WaveExists(InvolsKStorage))
		Redimension/N=(0) InvolsKStorage
	endif
	
	
	
	SVAR/Z RIP = $ParmFolder+"LastParm"
	if (SVAR_EXISTS(RIP) == 1)
		RIP = ""
		KillStrings/Z RIP
	endif
	
	SVAR/Z RIP = $ParmFolder+"LastMod"
	if (SVAR_EXISTS(RIP) == 1)
		RIP = ""
		KillStrings/Z RIP
	endif
	
	SVAR/Z RIP = $ParmFolder+"CleanUpNameList"
	if (SVAR_EXISTS(RIP) == 1)
		RIP = ""
		KillStrings/Z RIP
	endif
	
	PTS("FMapCheckTime;FMapAnalyzeInput;FMapModifyInput;","")
	
	SafeKillWaves(ForceLoadDirs)
	SafeKillWaves(ForceUnLoadDirs)
	UpdateForceList()
	
	UpdateForceParmButtons()
	GhostForceModifyPanel()
	GhostForceAnalyzePanel()
	ARLinkForceSpots("LinkForceSpots_"+num2str(cForceSpotTabNum),0)
	Variable FileRef = GV("ARDFOfflineFileRef")
	//if (FileRef != GV("ARDFFileRef"))
	ARFMap_Close(FileRef,FileName=GTS("ARDFOfflineFileRef"))//offline

End