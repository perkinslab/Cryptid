import os, sys
import discord_notify as dn

file_path = os.path.dirname(__file__)

textPath = file_path+"\\CDNotificationText.txt"
discordFilePath = file_path+"\\DiscordAddress.txt"

with open(textPath) as f:
    message = f.readline().strip()

with open(discordFilePath) as fr:
    discordPath = fr.readline().strip()


notifier = dn.Notifier(discordPath)
notifier.send(message,print_message=False)
