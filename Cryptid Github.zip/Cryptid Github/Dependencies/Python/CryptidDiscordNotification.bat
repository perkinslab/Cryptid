@echo off
python %~dp0\CryptidDiscordNotification.py %*