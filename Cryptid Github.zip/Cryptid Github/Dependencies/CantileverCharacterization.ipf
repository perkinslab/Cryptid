#pragma rtGlobals=3		// Use modern global access method and strict wave access.

Function cantileverTest()
//Collects 5MHz and lower-speed data, calculates the AV of both, and plots and saves the results as a way
//of mesuring both the cantilever time response and long-time drift.
	
	if (!DataFolderExists("root:Drift"))
		//string dateTime
		newDataFolder root:Drift
	endif
	setDataFolder root:Drift
	
	Variable AC_toshow = 10 //additional time factor beyond the 1/e point to save in the AC
	
	Variable/G root:testStartTime = ticks/60
	cryptidTimerProgress("Characterizing Cantilever...",310,background=1)
	
	
	//Collect 20 MHz data (for autocorrelation)
	Variable FClength = 0.1
	td_writevalue("Cypher.Capture.0.Rate", 1) //20MHz
	td_writevalue("Cypher.Capture.0.Length", FClength*20e6)
	td_writevalue("Cypher.Capture.0.Trigger", 1) 
	updateStatus("Collecting 20 MHz data")
	sleep/s FClength //Hold during DAQ
	updateStatus( "20 MHz collection complete; reading out")
	Make/O FC_20
	td_ReadCapture("Cypher.Capture.0", FC_20, "") //transfer to PC
	
	do
		sleep/s 1
	while (FC_20[numpnts(FC_20)-1] == 0)
	updateStatus( "Readout complete; computing AC")
	//Since these data will only be used for autocorrelation analysis, we do not need to change the units to pN
	
	//Analysis of 20 MHz data
	autocorrelation(FC_20)
	Wave FC_20_AC
	Duplicate/O FC_20_AC FC_AC
	Killwaves FC_20_AC
	Variable k 
	Variable reflection_pnt =  floor(numpnts(FC_AC)/2)
	for (k = reflection_pnt; k < numpnts(FC_AC); k+=1)
		if (FC_AC[k] < 1/e)
			Variable time_response = pnt2x(FC_AC, k)
			Variable cutoff_time = AC_toshow*time_response
			break
		endif
	endfor
	Duplicate/O/R=(0, cutoff_time) FC_AC AC
	//Save time response as the note of AC
	note AC num2str(time_response)

	//Collect 5 MHz data
	FClength = 0.1 // in s
	td_writevalue("Cypher.Capture.0.Rate", 2)
	td_writevalue("Cypher.Capture.0.Length", FClength*5e6)
	td_writevalue("Cypher.Capture.0.Trigger", 1) 
	updateStatus( "Collecting 5 MHz data")
	sleep/s FClength //Hold during DAQ
	updateStatus( "5 MHz collection complete; reading out")
	Make/O FC
	td_ReadCapture("Cypher.Capture.0", FC, "") //transfer to PC   
	do
		sleep/s 1
	while (FC[numpnts(FC)-1] == 0)
	//Convert to pN units
	Variable conv_factor = GV("invOLS")*GV("SpringConstant")*1e12
	fastop FC = (conv_factor)*FC
	updateStatus( "Readout complete; computing AV")

	//Analysis of 5 MHz data
	//AllanVar(FC,max_octave=18)
	AllanVar(FC)
	Wave FC_AV, FC_tau, FC_dAVp, FC_dAVm
	updateStatus( "Analysis of 5 MHz data complete")

	//Collect 1 kHz data (called directly so we don't have to use the freq. set in the master panel)
	Variable smplRate = 1000
	Variable SC_runtime = 300 //s
	Make/O SC //slowcapture of deflection data
	Variable nop = smplRate*SC_runtime
	nop += (32-mod(nop,32))*(!!mod(nop,32))
	Variable Bank = 0
	String Event = "14,Never" //Start aquisition on Event 14 hard-coded here
	String ChannelA = "Deflection"
	Variable Deci = ARGetDeci(smplRate)
	Redimension/N=(nop) SC
	IR_XSetInWave(Bank,Event,ChannelA,SC,"cantileverTestCallback("+num2str(conv_factor)+")",Deci)
	td_writestring("Event.14", "Once")
	
//	liveDeflection(windowToDisplay="Characterization",length=SC_runtime)
	
	updateStatus( "Collecting 1 kHz data")

	
End

Function cantileverTestCallback(conv_factor)
	
	variable conv_factor
	wave SC
	
//	endLiveDeflection()
	
	//Convert to pN units
	fastop SC = (conv_factor)*SC
	updateStatus( "1 kHz collection complete; computing AV")
	
	//Analysis of 1 kHz data
	AllanVar(SC)
	Wave SC_AV, SC_tau, SC_dAVp, SC_dAVm
	updateStatus( "Analysis of 1 kHz data complete")
	
	wave FC_AV, FC_dAVp, FC_dAVm, SC_AV, SC_dAVp, SC_dAVm
	
	//Convert to Allan deviation (pN units)
	Duplicate/O FC_AV FC_AD
	FC_AD = sqrt(FC_AV)
	Duplicate/O FC_dAVp FC_dADp
	FC_dADp = sqrt(FC_dAVp)
	Duplicate/O FC_dAVm FC_dADm
	FC_dADm = sqrt(FC_dAVm)
	Duplicate/O SC_AV SC_AD
	SC_AD = sqrt(SC_AV)
	Duplicate/O SC_dAVp SC_dADp
	SC_dADp = sqrt(SC_dAVp)
	Duplicate/O SC_dAVm SC_dADm
	SC_dADm = sqrt(SC_dAVm)
	
	killwaves FC_AV, FC_dAVp, FC_dAVm, SC_AV, SC_dAVp, SC_dAVm
	
	//Save data to an IGOR binary; the user will be prompted to choose file name and destination
//	save/I/T  FC_AD, FC_tau, FC_dADp, FC_dADm, SC_AD, SC_tau, SC_dADp, SC_dADm, AC
	
	variable offset = SC[0]
	SC -= offset
	
	plotCalAD()
	display SC

End

Function loadCalAD()
//User is prompted to choose the location of a ibw file containing a save calibration AD, then the results are plotted
	loadwave/T/O
	
	plotCalAD()
End

Function plotCalAD()
//Plots the eight AV waves (converted to Allan deviation) generated in cantileverTest(), assuming the naming is just right.
//Also plots the autocorrelation wave, if it exists.
	Wave FC_AD, FC_tau, FC_dADp, FC_dADm, SC_AD, SC_tau, SC_dADp, SC_dADm,FC,SC
	//Determine if AC wave exists:
	String AC_list = WaveList("AC",";","")
	Variable has_AC
	if (strlen(AC_list) != 0)
		has_AC = 1
		Wave AC
	else
		has_AC = 0
	endif
	//Duplicate the waves so that more than one can be plotted at once:
	String key = num2str(floor(abs(enoise(999))))
	Duplicate FC_AD $("FC_AD_" + key)
	Duplicate FC_tau $("FC_tau_" + key)
	Duplicate FC_dADp $("FC_dADp_" + key)
	Duplicate FC_dADm $("FC_dADm_" + key)
	Duplicate SC_AD $("SC_AD_" + key)
	Duplicate SC_tau $("SC_tau_" + key)
	Duplicate SC_dADp $("SC_dADp_" + key)
	Duplicate SC_dADm $("SC_dADm_" + key)
	Duplicate/O SC $"SC_"+key
	Duplicate/O FC $"FC_"+key
	
	Wave FC_ADk = $("FC_AD_" + key)
	Wave FC_tauk = $("FC_tau_" + key)
	Wave FC_dADpk =$("FC_dADp_" + key)
	Wave FC_dADmk =$("FC_dADm_" + key)
	Wave SC_ADk = $("SC_AD_" + key)
	Wave SC_tauk = $("SC_tau_" + key)
	Wave SC_dADpk = $("SC_dADp_" + key)
	Wave SC_dADmk = $("SC_dADm_" + key)
	
	//Make the plot
	Display FC_ADk vs FC_tauk
	Appendtograph SC_ADk vs SC_tauk
	ModifyGraph log=1
	ModifyGraph mode=2,lsize=3
	ModifyGraph rgb($("SC_AD_"+key))=(0,0,65280)
	ErrorBars $("FC_AD_"+key) Y,wave=(FC_dADpk,FC_dADmk)
	ErrorBars $("SC_AD_"+key) Y,wave=(SC_dADpk,SC_dADmk)
	
	Variable forceStabilityLevel = 1 //1pN force stability
	Variable forceStability = 0
	//Estimate the stability
	findLevel/EDGE=1/Q/R=[dimsize(FC_ADk,0)-1,0] FC_ADk forceStabilityLevel
	if(!V_flag)
		forceStability = FC_tauk(V_LevelX)
	endif 
	findLevel/EDGE=1/Q/R=[dimsize(SC_ADk,0)-1,0] SC_ADk forceStabilityLevel
	if(!V_flag)
		Variable newStab = SC_tauk(V_LevelX)
		if (newStab > forceStability)
			forceStability = newStab
		endif
	endif 
	

	if (has_AC == 1)
		Duplicate AC $("AC_"+key)
		Wave ACk = $("AC_"+key)
		Display ACk
		ModifyGraph log(bottom)=1
		String time_response = note(ACk)
		printf "Time response: %g s (\# %d) \n", str2num(time_response), str2num(key)
		print "Force stability: "+num2str(forceStability)
		
		
		killwaves AC
	endif
	
	//If graph never rises above 1/e, we get a false value of 5e-8
	if (str2num(time_response) < 1e-7)
		time_response = "0"
	endif
	
	
	//Store both
	Wave/Z/T experimentInfo = root:Settings:ExperimentInfo:ExperimentTemplate
	if (waveExists(experimentInfo))
		experimentInfo[%subpNForceStability] = num2str(forceStability)
		experimentInfo[%timeResponse] = time_response
	endif
	
		//Store both
	Wave/Z cryptidSettings = getCryptidSettings(0)
	if (waveExists(cryptidSettings))
		cryptidSettings[%forceStability] = forceStability
		cryptidSettings[%timeResponse] = str2num(time_response)
	endif
	
	
	killwaves FC_AD, FC_tau, FC_dADp, FC_dADm, SC_AD, SC_tau, SC_dADp, SC_dADm
	//...so you don't carry over AC data from the wrong experiment
	
	NVAR temp = root:testStartTime
	temp = ticks/60 - temp
	
	print "Total test time: "+num2str(temp)

	killWindow progressWindow
	
End


Function plotAD(trace)
//Uses AllanVar() to compute the Alan variance, then computes its square root, the Alan deviation
	Wave trace
	String tracename = nameofwave(trace)
	
	AllanVar(trace)
	
	Wave AV = $(tracename + "_AV")
	Wave tau = $(tracename + "_tau")
	Wave dAVp = $(tracename + "_dAVp")
	Wave dAVm = $(tracename + "_dAVm")
	
	Duplicate/O AV $(tracename+"_AD")
	Wave AD = $(tracename + "_AD")
	AD = sqrt(AV)
	Duplicate/O dAVp $(tracename+"_dADp")
	Wave dADp = $(tracename + "_dADp")
	dADp = sqrt(dAVp)
	Duplicate/O dAVm $(tracename+"_dADm")
	Wave dADm = $(tracename + "_dADm")
	dADm = sqrt(dAVm)
	
	Display AD vs tau
	ModifyGraph log=1
	ModifyGraph mode=2,lsize=3
	ErrorBars $(tracename + "_AD") Y,wave=(dADp,dADm)
End

Function AllanVar(trace, [max_octave])
//Computes the Allan Variance of a time series, returning four waves:
//	_AV: the Allan Variance (y-axis)
//	_tau: the corresponding values of tau (x-axis)
//	_dAVp: the error bar on the AV in the postive direction
//	_dAVm: the error bar on the AV in the negative direction
//The function assumes that the time values are correctly encoded in the x-axis of the trace data
	Wave trace
	Variable max_octave
	
	String tracename = nameofwave(trace)
	
	Make/O onesigma = {0.16, 0.84}
	
	//Determine number of octaves contained in the data:
	Variable octaves = floor(log(numpnts(trace))/log(2))
	Variable tau_c = dimDelta(trace, 0)
	
	if(ParamIsDefault(max_octave))
		octaves = octaves
	else
		octaves = min(octaves, max_octave)
	endif
	
	//Computation of trace-length parameters:
	Variable N = numpnts(trace)
	Variable k 
	Make/O/N=(octaves) m
	for (k=0; k<octaves; k+=1)
		m[k] = 2^k //bin size for each octave
	endfor
	Make/O/N=(octaves) shape
	shape = 1/2*(N/m-1)
	
	//Calculation of the values for 'z' from Eq. 18b of the correction to Lansdorp and Saleh (2017)
	Make/O/N=(N) zRaw
	zRaw[0] = 0
	zRaw[1] = trace[0] 
	zRaw[2,] = zRaw[p-1] + trace[p]
	FastOp zRaw = (tau_c)*zraw

	
	//Make the waves that will store the output:
	Make/O/N=(octaves) $(tracename + "_AV")
	Make/O/N=(octaves) $(tracename + "_tau")
	Make/O/N=(octaves) $(tracename + "_dAVp")
	Make/O/N=(octaves) $(tracename + "_dAVm")
	Wave AV = $(tracename + "_AV")
	Wave tau = $(tracename + "_tau")
	Wave dAVp = $(tracename + "_dAVp")
	Wave dAVm = $(tracename + "_dAVm")
	
	//Iterate and calculate the AV in each octave:
	for (k=0; k<octaves; k+=1)
		//Value of tau corresponding to this octave:
		tau[k] = m[k]*tau_c
		
		Make/O/N=(N-2*m[k]) summands
		Variable c
		for (c=0; c<(N-2*m[k]); c+=1)
			summands[c] = (zRaw[c]+zRaw[c+2*m[k]]-2*zRaw[c+m[k]])^2
		endfor
		//Multithread summands =  (zRaw[p]+zRaw[p+2*m[k]]-2*zRaw[p+m[k]])^2
		
		Variable adduct = sum(summands)

		
		AV[k] = 1/2/(N-2*m[k]+1)/(m[k]*tau_c)^2*adduct
		
		//Determination of the error bars by integration of the gamma distribution
		Variable scale = AV[k]/shape[k]
		dAVp[k] = abs(AV[k] - StatsInvGammaCDF(onesigma[1], 0, scale, shape[k]))
		dAVm[k] = abs(AV[k] - StatsInvGammaCDF(onesigma[0], 0, scale, shape[k]))

	endfor
	
	//Display AV vs tau
	//ModifyGraph log=1
	//ModifyGraph mode=2,lsize=3
	//ErrorBars $(tracename + "_AV") Y,wave=(dAVp,dAVm)
	
	Killwaves m, shape, zRaw, onesigma, summands
	
	NVAR progress

End

Function genWhiteNoise(length, freq, destwavename)
//Uses random number generation to create Gaussian-distributed white noise for a particular length of time and
//at a particular frequency
	Variable length, freq
	String destwavename
	
	Variable length_pnts = length*freq
	make/o/n=(length_pnts) $destwavename
	Wave noisewave = $destwavename
	SetScale/I x 0,length,"", noisewave
	
	Variable c
	for (c = 0; c<length_pnts; c+=1)
		noisewave[c] = gnoise(1)
	endfor
End

Function autocorrelation(signal)
//Computes the autocorrelation of the input signal.  Result has name of wave, but _AC appended.
	Wave signal 
	
	Duplicate/O signal $(nameofwave(signal)+"_AC")
	Wave signal_AC = $(nameofwave(signal)+"_AC")
	Correlate/NODC/AUTO signal, signal_AC
End