#pragma rtGlobals=3		// Use modern global access method and strict wave access.

//Brandon Dzuba 2025/08/05
//Ability to add users and store cantilevers added in this ipf file

//Cryptid user functions////////////////////

//Gives the specified info for the given user
//default to currently selected user
Function/T userInfoCryptid(info,[userName])

	string info, userName
	
	if(paramIsDefault(userName))
		userName =getCStr("User")
	endif
	
	Wave/T userList = getCryptidSettings(1, setting="UserList")
	
	return userList[%$info][%$userName]
	
End

//Edits the userinfo wave
Function editUserInfo()

	Wave/T userList = getCryptidSettings(1, setting="UserList")
	
	string editUser
	prompt editUser, "Edit which user?", popup, listOfUsers()
	doPrompt "Edit which user?", editUser
	if (v_flag)
		return 1
	endif
	
	string userName = userList[%Name][%$editUser]
	string discord = userList[%discordServer][%$editUser]
	
	prompt userName, "User Name:"
	prompt discord, "Discord Server:"
	
	doPrompt "User Update", userName, discord
	
	if(cmpstr(userList[%Name][%$editUser] ,userName,1) != 0)
		//Then user name was updated
		string oldUserName = userList[%Name][%$editUser]
		string oldFolderName =  getCryptidPath("Users:"+oldUserName)
		string newFolderName = getCryptidPath("Users:"+userName)
		MoveFolder/O oldFolderName as newFolderName
		userList[%Name][%$editUser] = userName
		
		setDimLabel 1, findDimLabel(userList,1,oldUserName), $userName, userList
		edituser = userName
		if (stringMatch(getCStr("User"),oldUserName))
			setCStr("User", userName)
		endif
		
	endif
	
	userList[%discordServer][%$editUser] = discord
	
	saveCryptidSetting(userList)
	//controlUpdate 
	//
End



//Lists all current users. Primarily for the popupMenu
Function/S listOfUsers()

	Wave/T userList = getCryptidSettings(1, setting="UserList")
	variable numUsers = dimsize(userList,1)
	
	string userListString = ""
	variable i
	for(i=0;i<numUsers;i+=1)
		userListString += getDimLabel(userList,1, i)+";"
	endfor
	
	return userListString

End


//Add a new user to the program
//creates a local path (in cryptid\Users)
//creates a cantilever folder in that path
//creates a cantilever wave for storing cantilever info
Function createNewUser()
	
	Wave/T userList = getCryptidSettings(1, setting="UserList")
	
	string newUserName
	prompt newUserName, "New user name:"
	doPrompt "New User Name", newUserName
	
	if (v_flag)
		return 1
	endif
	
	if (findDimLabel(userList,1,newUserName) != -2)
		doAlert 0, "User already exists"
		
		return 1
		
	endif
	

	//Need to make the folder structure
	string pathName = getCryptidPath("Users:"+newUserName)
	newPath/O/C/Q newUserPath pathname
	pathName = getCryptidPath("Users:"+newUserName+":Cantilevers")
	newPath/O/C/Q cantileverPath pathName
	
	//Make the cantilever wave
	wave/T cantTemplate = getCryptidSettings(1, setting="cantileversTemplate")
	duplicate/O cantTemplate cantilevers
	save/O/P=newUserPath cantilevers
	killWaves cantilevers
	
	if (v_flag)
		return 1
	endif
	
	variable oldSize = dimsize(userList,1)
	redimension/N=(-1,oldSize+1) userList
	
	setDimLabel 1, oldSize, $newUserName, userList
	userList[%name][%$newUserName] = newUserName
	
	saveCryptidSetting(userList)
	wave/t tSettings = getCryptidSettings(1)
	tSettings[%user] = newUserName
	
End

//Remove a user
Function removeUser([user2remove])

	string user2remove
	if(paramIsDefault(user2remove))
		prompt user2Remove, "Remove which user?", popup, listOfUsers()
		doPrompt "Remove which user?", user2Remove
		if (v_flag)
			return 1
		endif
	endif
	
	doAlert 1, "Are you sure you want to remove "+user2remove+"?"
	if (v_flag == 2)
		return 1
	endif
	
	
	//Actually remove the user (don't delete the folder just in case though....
	Wave/T userList = getCryptidSettings(1, setting="UserList")
	variable userLoc = findDimLabel(userList,1,user2remove)
	deletePoints/M=1 userLoc, 1, userList
	
	//Instead of deleting, we'll copy to a new folder
	string OriginalpathName = getCryptidPath("Users:"+user2remove)
	string newPathName =  getCryptidPath("Users:OldUsers:"+user2remove)
	string newPathbasic = getCryptidPath("Users:OldUsers")

	newPath/O/C/Q/Z oldUserPath, newPathbasic
	
	MoveFolder/O originalPathName as newPathName

	
	saveCryptidSetting(userList)
	setCStr("user","")

End

//Load a wave from the user folder on the disk
Function/Wave LoadCryptidUserWaves(theWaveName)

	string theWaveName
	string user = getCStr("User")
	string pathLoc = getCryptidPath("Users:"+user)
	newPath/Q/O currentUserPath pathLoc
	string currentDF = getDataFolder(1)
	setDataFolder root:Settings:Cryptid
	LoadWave/H/Q/O/P=currentUserPath theWaveName+".ibw"
	
	wave returnWave = $theWaveName
	
	setDataFolder $currentDF
	
	return returnWave

End

//Save a wave to the user folder on the disk
Function SaveCryptidUserWaves(theWave)

	wave theWave
	string user = getCStr("User")
	string pathLoc = getCryptidPath("Users:"+user)
	newPath/Q/O currentUserPath pathLoc
	
	Save/O/P=currentUserPath theWave


End

//Saves the current cantilever info to the users cantilever wave
Function saveCantilever()

	string user = getCStr("User")
	string pathLoc = getCryptidPath("Users:"+user)
	
	//Load the current cantilever wave
	LoadCryptidUserWaves("cantilevers")
	wave/T cantilevers = getCryptidSettings(1, setting="cantilevers")
	
	//Check if the cantilever exists already
	Wave/t experimentTemplate = getCryptidSettings(1,package="experimentInfo",setting="experimentTemplate")
	string cantileverName = experimentTemplate[%cantilever]
	Variable overwrite = findDimLabel(cantilevers,1,cantileverName)
	if (overwrite != -2)
		doAlert 1, "Cantilever already exists. Overwrite?"
		if (v_flag ==2)
			return 1
		endif
	else
		overwrite = 0
	endif
	
	//Save a backup just in case
	duplicate/O cantilevers cantileversBackup
	saveCryptidUserWaves(cantileversBackup)
	
	//Check if first
	if (stringMatch(getDimLabel(cantilevers,1,0),""))
		variable currentSize = 0
	else
		currentSize = dimsize(cantilevers,1)
	endif
	
	//Check that it matches the current template, update if not
	cantileverCheckAgainstTemplate(cantilevers)
	
	//Add the appropriate things
	Wave vSettings = getCryptidSettings(0)
	
	//First make sure the loaded cantilevers wave has the same dim labels
	variable old
	
	Variable colNum = currentSize
	if (!overwrite)
		redimension/N=(-1,currentSize+1) cantilevers
		setDimLabel 1, currentSize, $cantileverName, cantilevers
	else
		colNum = overwrite
	endif
	
	cantilevers[%Name][colNum] = cantileverName
	cantilevers[%SpringConstant][colNum] = num2str(GV("SpringConstant"))
	cantilevers[%invOLS][colNum] = num2str(GV("Invols"))
	cantilevers[%Stability][colNum] = num2str(vSettings[%Forcestability])
	cantilevers[%TimeResponse][colNum] = num2str(vSettings[%timeResponse])
	cantilevers[%Date][colNum] = Secs2Date(DateTime,-2,"")
	
	saveCryptidUserWaves(cantilevers)
	
End

//Check the loaded cantilever file against the template. If you want to add more cantilever properties in the future,
//Simply modify the template
Function cantileverCheckAgainstTemplate(cantilevers)

	Wave/T cantilevers
	
	wave/T cantileverTemplate = getCryptidSettings(1, setting="cantileversTemplate")
	variable templateSize = dimsize(cantileverTemplate,0)
	variable cantileverSize = dimsize(cantilevers,0)
	if (cantileverSize == templateSize)
		return 0
	endif
	
	variable i
	for(i=0;i<templateSize;i+=1)
		string currentDimLabel = getDimLabel(cantileverTemplate,0,i)
		if ( findDimLabel(cantilevers,0,currentDimLabel) == -2)
			redimension/N=(cantileverSize+1,-1) cantilevers
			setDimLabel 0, cantileverSize, $currentDimLabel, cantilevers
		endif
	endFor

End

//Load the cantilever file from the user folder
Function loadCantilever()

	//Load the wave for the current user
	wave/T cantilevers = LoadCryptidUserWaves("cantilevers")//getCryptidSettings(1, setting="cantilevers")
	Wave/t experimentTemplate = getCryptidSettings(1,package="experimentInfo",setting="experimentTemplate")
	string cantileverName = experimentTemplate[%cantilever]
	
	//Check if the cantilever exists in the wave
	variable cantileverColumnLoc = findDimLabel(cantilevers,1,cantileverName)
	
	if (cantileverColumnLoc == -2)
		cryptidDebug(diagString="Cantilever not found for current user ("+getCStr("User")+")",alert=1,alwaysPrint=1)
		return 1
	endif
	
	//Now that it does exists, load the important bits (for now, just the time response and spring constant
	wave vSettings = getCryptidSettings(0)
	vSettings[%timeResponse] = str2num(cantilevers[%timeResponse][%$cantileverName])
	vSettings[%Forcestability] = 0 //Blank stability
	
	setSpringConstant(str2num(cantilevers[%springConstant][%$cantileverName]))
	
	updateStatus("Cantilever loaded!")
End

Function UserInfoButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			
			string ctrlName = ba.ctrlName
			
			strSwitch(ctrlName)
			
				case "SaveCantilever":
					saveCantilever()
					break
				case "LoadCantilever":
					loadCantilever()
					break
				case "EditUserInfo":
					editUserInfo()
					break

			EndSwitch

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function UserInfoPopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa
	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			
			string ctrlName = pa.ctrlName
			strSwitch(ctrlName)
				case "user":
					Wave/t tSettings = getCryptidSettings(1)
					if (stringMatch(pa.popStr,"New"))
						createNewUser()
					elseif(stringMatch(pa.popStr,"Remove"))
						removeUser()
					elseif(stringMatch(pa.popStr,"Edit"))
						editUserInfo()
					else
						tSettings[%user] = pa.popStr
					endif
					
					break
			endSwitch
			
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

