#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//TIP: Copy this file into the desired package folder, rename it to your package name,
//Then run ctrlF and use ctr+V to replace "Example" with you actual package name


//************EXECUTE COMMAND*************
//This is a wrapper function for cryptid to call
//Put the name in the executables file
Function cryptidExecuteExample()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	DoExample(vSettings,tSettings)
	

End


//This is the actual function that does things. This stucture is so you can pass
//Around the settings files, hopefully making the program work outside of cryptid
Function DoExample(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings
	
	Variable Error=0
	
	//We need to set up an event. Best to put this in your settings and set a default value
	String EventString=tSettings[%eventEnable]
	
	//Clear the event we are going to use
	Error += td_WS(EventString,"Clear")
	
	//Use cryptidDebug to print. Check optional parameters for more info
	cryptidDebug(diagString="Asylum Error in td_WS: "+num2str(Error))
	
	//There is a function for loading/making tSettings and vSettings, however it is called
	//by cryptid upon adding the module to the experiment, so it is already done
	
	//Here we set up and load/change any ARC/Cypher parameters. Feedback loops, CTFCs, ect...
	SetupExampleParameters(vSettings,tSettings)
	
	//Here we set up our inWaves. Make the waves, set up the td_xSetInWave stuff ect....
	SetupExampleData(vSettings,tSettings)
	
	//Here we execute
	ExecuteExample(vSettings, tSettings)
End

//Here we set up any ARC/Cypher parameters
Function setupExampleParameters(vSettings,tSettings)

	wave vSettings
	wave/t tSettings
	
	cryptidDebug()

	//Code here to set up feedbacks, ctfc, out/inwaves, ect..
	
End //SetupForceRamp


//Here we set up our data recording
//I've left this example from the package "Dwell" as a good example.
Function SetupExampleData(vSettings,tSettings)

	Wave vSettings
	Wave/t tSettings
	
	cryptidDebug()

	Variable dwellTime = vSettings[%dwellTime]
	Variable captureRate = vSettings[%captureRate]
	
	if(!vSettings[%DwellsaveCollectedData])
		captureRate = 100
	Endif

	make/O/N=(0) zSensor
	make/O/N=(0) Deflection
	prepWavesForSC(Deflection,zSensor,captureRate,dwellTime)
	
	//get the Event we set up earlier
	String eventString = tSettings[%eventEnable]
	String deflectionChannel = tSettings[%deflectionChannelString]
	
	//set up the in wave pair. Callback can be here or in the CTFC/SetOutWave/ect..
	//NOTE: noe that the callback here is designed to pass the waves, just as the rest of the function
	//This ensure the program can be run independently
	
	string callback = "exampleCallback()"
	td_XSetInWavePair(0,EventString,deflectionChannel,deflection,"Cypher.LVDT.Z",zSensor,callback,ARGetDeci(captureRate))


End

//This function actually starts the program, usually through td_WS
Function ExecuteExample(vSettings,tSettings)

	Wave/t tSettings
	wave vSettings
	
	String EventString="Event."+tSEttings[%eventEnable]
	
	updateStatus("Begining "+num2str(vSettings[%dwellTime])+" s Dwell")
	
	//Actually execute the thing
	td_WS(EventString,"Once")	

End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeExampleSettings()
	
	String packageName = "Dwell"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End


//Called at the end of you function. Must call cryptid back from here.
Function ExampleCallback()

	Wave/T tSettings
	Wave vSettings
	
	td_WS("Event."+tSettings[%eventStop],"Once")	
	td_stopinwavebank(0)
	
	wave deflection, zSensor
	
	//Update graph of Cryptid to show your data (doesn't save)
	updateCryptidGraph(deflvolts=deflection,zSensorVolts=zSensor)
	
	//Here we write to stdOut. This is primarily used to store information to add to the note
	//E.G.: if params="DwellTime;DwellCount;" and values="100;5;" then the end of the note will read:
	//DwellTime:100
	//DwellCount:5
	string params = "DwellTime;"
	string values = num2str(vSettings[%dwellTime])+";"
	writeToStdOut(params,values)
		
//	Variable


End

//Cryptid calls this function by passing its own values to panelName, widowName, and hostName
//This function is written so that if you call it with defaults, it will make its own window
//I highly recommend copying large parts of this function, and just replacing that last part
// 
//For easiest modification, make your panel using the graphical tools for panel making,
//Save it, and then copy the control's code to the bottom of this function
//You will need to replace all values to vSettings,tSettings instead of absolute paths to 
//make it work (I.E.): value=root:Settings:ExamplePackage:vSettings[%someValue] will need to be changed
//to 						value=vSettings[%someValue] to work with cryptid
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeExamplePanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="examplePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="exampleWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	
	PauseUpdate; Silent 1		// building window...
	
		//Put all of your panel stuffs here

	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	
	TitleBox ExampleTitle,pos={85.00,11.00},size={104.00,25.00}
	TitleBox ExampleTitle,title="Force Clamp",fSize=18,frame=0,fStyle=1
	TitleBox ExampleEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox ExampleEventTitle,fSize=18,frame=0,fStyle=1
	
	
	SetVariable exampleVariable,pos={72.00,72.00},size={144.00,18.00},title="Dwell Time"
	SetVariable exampleVariable,format="%.1W1Ps"
	SetVariable exampleVariable,value=vSettings[%dwellTime]

End


//Put your controls down here (setVariableControl, buttonControl, ect...)


Function ExampleCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			wave vSettings
			
			Variable checked = cba.checked
			vSettings[%$cba.ctrlName] = checked
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function ExampleButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
			
				case "StartDwellNow":

			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End
