#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1
//#include ":Dependencies:SaveAsAsylumForceRamp"

//This is an example file with empty function meant to illustrate the layout of a cryptid package


//This function is called to actually run the experiment
////////////////////////////////////Execute Command////////////////////////////////////
Function cryptidExecuteParamChange()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	wave mainSettings = getCryptidSettings(0)
	Variable goodCurveCount = mainSettings[%fullIterations]
	
	
	string paramToChange = "ParamToChange"
	string ChangeTo = "ChangeTo"
	string EveryThisMany = "EveryThisMany"
	string numberOfChanges = "numberOfChanges"
	string waveToChange = "waveToChange"
	
	variable i
	variable iters = 2
	
	if (stringMatch(tSettings[%paramToChange1],""))
		iters = 1
	endif
	
	//For every parameter to change
	for(i=0;i<iters;i+=1)
	
		Variable ETM = vSettings[%$everyThisMany+num2str(i)]
		if (ETM == 0)
			vSettings[%$numberOfChanges+num2str(i)]=0
			break
		endif
		
		//If it is time to change
		if ( (vSettings[%$numberOfChanges+num2str(i)]==0 || mod(goodCurveCount,ETM)==0) && goodCurveCount != 0)

			String paramChange = tSettings[%$paramToChange+num2str(i)]
			String changeToList = tSettings[%$changeTo+num2str(i)]
			Variable numChanges =  vSettings[%$numberOfChanges+num2str(i)]
			Variable numberOfItems = itemsInList(changeToList)
			
			Wave temp = $tSettings[%$waveToChange+num2str(i)]
			
			//Start from top of list if at end
			if (vSettings[%$numberOfChanges+num2str(i)] >= numberOfItems)
				vSettings[%$numberOfChanges+num2str(i)] = 0
			endif
			
			//Verify wave and param exists
			if (!WaveExists(temp))
				doAlert 0, "ParamChange: Wave Doesn't Exists: "+tSettings[%$waveToChange+num2str(i)]
				cryptidMain(1)
				return 0
			endif
			
			String changeThis = tSettings[%$paramToChange+num2str(i)]	
			if (findDimLabel(temp, 0, changeThis) < 0)
				doAlert,0, "ParamChange: Parameter Doesn't Exist: "+changeThis
				cryptidMain(1)
				return 0
			endif
			
			//Actually change
			
			variable newValue = str2num(stringFromList(vSettings[%$numberOfChanges+num2str(i)], changeToList))
			print "ParamChange: "+changeThis+" to "+num2str(newValue)
			temp[%$changeThis] = newValue
			vSettings[%$numberOfChanges+num2str(i)] += 1
		endif
	Endfor
	
	cryptidMain(1)
End


Function makeParamChangeWaves()

	loadCryptidSettings("ParamChange","vSettings;tSettings", useCurrentDF=1)

End



//Here is the function to set up the experiment panel. You can make this through the panel GUI,
//but will need to edit it when you are done to add the tSettings and vSettings waves as passable parameters.
//This is to allow multiples of you package to run in the stack
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeParamChangePanel([PanelName,WindowName,hostName]) : Panel
	
	String PanelName,WindowName, hostName
	
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(panelName))
		panelName="ParamChangePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="ParamChangeWindow"
	EndIf
	Variable panelWidth = 280
	Variable panelHeight = 700
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(0,0,280,700)/N=$PanelName as WindowName
	else
		
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif


	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable WaveToChange0,pos={15,81},size={246,16},bodyWidth=161,proc=ParamChangeSetVarProc,title="Wave to Change"
	SetVariable WaveToChange0,help={"This wave will be changed. Must have full path to wave (turns red if wave not found)"}
	SetVariable WaveToChange0,limits={-inf,inf,0},value= tSettings[%waveToChange0]
	SetVariable ParamToChange0,pos={19,104},size={242,16},bodyWidth=156,proc=ParamChangeSetVarProc,title="Param to Change"
	SetVariable ParamToChange0,help={"This parameter in the wave will be changed. Must be the dim label of the value to be changed"}
	SetVariable ParamToChange0,limits={-inf,inf,0},value= tSettings[%paramToChange0]
	SetVariable ChangeToValues,pos={15,126},size={246,16},bodyWidth=190,title="Change to:"
	SetVariable ChangeToValues,limits={-inf,inf,0},value= tSettings[%ChangeTo0]
	SetVariable EveryThisMany,pos={13,149},size={247,16},bodyWidth=136,title="Every __ Good Curves"
	SetVariable EveryThisMany,help={"Change will happen every **this number** of good curves collected"}
	SetVariable EveryThisMany,limits={-inf,inf,0},value= vSettings[%everyThisMany0]
	TitleBox FirstParameterTitle,pos={9,54},size={78,21},title="First Parameter"
	TitleBox SecondParameterTitle1,pos={10,184},size={96,21},title="Second Parameter"
	SetVariable WaveToChange1,pos={15,216},size={246,16},bodyWidth=161,proc=ParamChangeSetVarProc,title="Wave to Change"
	SetVariable WaveToChange1,help={"This wave will be changed. Must have full path to wave (turns red if wave not found)"}
	SetVariable WaveToChange1,limits={-inf,inf,0},value= tSettings[%waveToChange1]
	SetVariable ParamToChange1,pos={19,239},size={242,16},bodyWidth=156,proc=ParamChangeSetVarProc,title="Param to Change"
	SetVariable ParamToChange1,help={"This parameter in the wave will be changed. Must be the dim label of the value to be changed"}
	SetVariable ParamToChange1,limits={-inf,inf,0},value= tSettings[%paramToChange1]
	SetVariable ChangeToValues1,pos={15,261},size={246,16},bodyWidth=190,title="Change to:"
	SetVariable ChangeToValues1,limits={-inf,inf,0},value= tSettings[%ChangeTo1]
	SetVariable EveryThisMany1,pos={14,284},size={247,16},bodyWidth=136,title="Every __ Good Curves"
	SetVariable EveryThisMany1,help={"Change will happen every **this number** of good curves collected"}
	SetVariable EveryThisMany1,limits={-inf,inf,0},value= vSettings[%everyThisMany1]
	TitleBox ParamChangeTitle,pos={68,11},size={174,24},title="Parameter Change"
	TitleBox ParamChangeTitle,fSize=18,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetWindow kwTopWin,hook(thisPanelHook)=cryptidPanelHook
End


//Put your controls down here (setVariableControl, buttonControl, ect...)


Function ParamChangePopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa

	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			
			wave/t tSettings
			tSettings[%ParamToModify] = pa.popStr
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Window ParamChangePanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1915,243,2195,943) as "ParamChangeWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable WaveToChange0,pos={9.00,81.00},size={252.00,18.00},bodyWidth=161,proc=ParamChangeSetVarProc
	SetVariable WaveToChange0,title="Wave to Change"
	SetVariable WaveToChange0,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%waveToChange0]
	SetVariable ParamToChange0,pos={9.00,104.00},size={252.00,18.00},bodyWidth=156,proc=ParamChangeSetVarProc
	SetVariable ParamToChange0,title="Param to Change"
	SetVariable ParamToChange0,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%paramToChange0]
	SetVariable ChangeToValues,pos={9.00,126.00},size={252.00,18.00},bodyWidth=190
	SetVariable ChangeToValues,title="Change to:"
	SetVariable ChangeToValues,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%ChangeTo0]
	SetVariable EveryThisMany,pos={9.00,149.00},size={252.00,18.00},bodyWidth=136
	SetVariable EveryThisMany,title="Every __ Good Curves"
	SetVariable EveryThisMany,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:vSettings[%everyThisMany0]
	TitleBox FirstParameterTitle,pos={9.00,54.00},size={87.00,23.00}
	TitleBox FirstParameterTitle,title="First Parameter"
	TitleBox SecondParameterTitle1,pos={10.00,184.00},size={104.00,23.00}
	TitleBox SecondParameterTitle1,title="Second Parameter"
	SetVariable WaveToChange1,pos={9.00,216.00},size={252.00,18.00},bodyWidth=161,proc=ParamChangeSetVarProc
	SetVariable WaveToChange1,title="Wave to Change"
	SetVariable WaveToChange1,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%waveToChange1]
	SetVariable ParamToChange1,pos={9.00,239.00},size={252.00,18.00},bodyWidth=156,proc=ParamChangeSetVarProc
	SetVariable ParamToChange1,title="Param to Change"
	SetVariable ParamToChange1,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%paramToChange1]
	SetVariable ChangeToValues1,pos={9.00,261.00},size={252.00,18.00},bodyWidth=190
	SetVariable ChangeToValues1,title="Change to:"
	SetVariable ChangeToValues1,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:tSettings[%ChangeTo1]
	SetVariable EveryThisMany1,pos={9.00,284.00},size={252.00,18.00},bodyWidth=136
	SetVariable EveryThisMany1,title="Every __ Good Curves"
	SetVariable EveryThisMany1,limits={-inf,inf,0},value=root:Settings:Cryptid:WorkingFolders:ParamChange_8:vSettings[%everyThisMany1]
	TitleBox ParamChangeTitle,pos={68.00,11.00},size={157.00,25.00}
	TitleBox ParamChangeTitle,title="Parameter Change",fSize=18,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox DCEventTitle,fSize=18,frame=0,fStyle=1
	ToolsGrid snap=1,visible=1
EndMacro

//PUT CHECKS IN HERE
Function ParamChangeSetVarProc(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva

	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
			string name = sva.ctrlName
			Variable index = str2num(name[strlen(name)-1])
			string firstLetter = name[0]
		
			//Check a wave
			if (stringMatch(firstLetter,"W"))
				string temp = sva.sVal
				wave tempWave = $temp
				//Verify wave and param exists
				if (!WaveExists(tempWave))
					setVariable $sva.ctrlName, valueBackColor = (2^15, 0, 0)
				else
					setVariable $sva.ctrlName, valueBackColor =0
				endif
			endif
			
			//Check a param
			if (stringMatch(firstLetter,"P"))
				wave/t tSettings
				string theWaveName = tSettings[%$"waveToChange"+num2str(index)]
				wave theWave = $theWaveName
				
				temp = sva.sVal
				//Verify wave and param exists
				if (findDimLabel(theWave, 0, temp) < 0)
					setVariable $sva.ctrlName, valueBackColor = (2^15, 0, 0)
				else
					setVariable $sva.ctrlName, valueBackColor =0
				endif
			endif
			
		
		case 3: // Live update
		case -1: // control being killed
			break
	endswitch

	return 0
End

			
			String changeThis = tSettings[%$paramToChange+num2str(i)]	
			if (findDimLabel(temp, 0, changeThis) < 0)
				doAlert,0, "ParamChange: Parameter Doesn't Exist: "+changeThis
				cryptidMain(1)
				return 0
			endif