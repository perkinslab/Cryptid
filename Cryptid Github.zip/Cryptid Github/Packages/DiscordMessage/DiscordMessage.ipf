#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//This package sends a message to a discord channel once called.
//Discord is a messaging client
//To use, make a discord account, make a new discord channel, and get the address of that channel
//Channel - Settings - integrations - WebHooks - webhook URL
//Add that to the current user (edit user info then save edits)

Function cryptidExecuteDiscordMessage()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	discordMessage(tSettings[%message],discordAddress = tSettings[%discordAddress], callback="CryptidMain(1)")
	
End

Function discordMessage(message, [discordAddress, callback])

	string message, discordAddress, callback
	
	if(paramIsDefault(callback))
		callback = ""
	endif
	
	if (paramIsDefault(discordAddress))
		
		string currentUser = getCStr("user")
		wave/t users = getCryptidSettings(1, setting="userList")
		discordAddress = users[%DiscordServer][%$currentUser]
		
	endif
	
	if(stringMatch(discordAddress,""))
		return 1
	endif
	
	placeDiscordMessageInfo(discordAddress, "DiscordAddress")
	
	//Place the text and photo and channel in the text files
	placeDiscordMessageInfo(message, "CDNotificationText")
	
	//Execute the script
	callDiscordScript("CryptidDiscordNotification")
	
	//Execute callback
	execute callback
End


//A wrapper function to call a python script
//I do not know why this takes so long
Function/S callDiscordScript(scriptName)
	
	string scriptName
	string path = getCryptidPath("Packages:DiscordMessage:Dependencies:"+scriptName+".bat")

	executeScriptText path

End

Function placeDiscordMessageInfo(text, fileName)

	string text, fileName
	string path = getCryptidPath("Packages:DiscordMessage:Dependencies:")
	newPath/O/Q savePath path
	make/O/T textWave = {text}
	save/O/G/P=savePath textWave as fileName+".txt"
	
	//Place a picture of the last data
	string graphName = getCstr("cryptidGraphName")
	SavePICT/P=savePath/WIN=$graphName/O/E=-5/RES=600 as "photo.png"
	
	killWaves/z textWave
	
End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeDiscordMessageSettings()
	
	String packageName = "discordMessage"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End



//Cryptid calls this function by passing its own values to panelName, widowName, and hostName
//This function is written so that if you call it with defaults, it will make its own window
//I highly recommend copying large parts of this function, and just replacing that last part
// 
//For easiest modification, make your panel using the graphical tools for panel making,
//Save it, and then copy the control's code to the bottom of this function
//You will need to replace all values to vSettings,tSettings instead of absolute paths to 
//make it work (I.E.): value=root:Settings:ExamplePackage:vSettings[%someValue] will need to be changed
//to 						value=vSettings[%someValue] to work with cryptid
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeDiscordMessagePanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="DiscordMessagePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="DiscordMessageWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
	
	PauseUpdate; Silent 1		// building window...
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	TitleBox DiscordMessageTitle,pos={63,12},size={161,24},title="Discord Message"
	TitleBox DiscordMessageTitle,fSize=18,frame=0,fStyle=1
	TitleBox DiscordMessageEventTitle,pos={115,470},size={63,24},title="Events"
	TitleBox DiscordMessageEventTitle,fSize=18,frame=0,fStyle=1
	SetVariable MessageText,pos={18,54},size={243,16},title="Message Text",help={"The text to send to the discord address stored in the current user. To edit this address, click Edit User Info in the main panel"}
	SetVariable MessageText,limits={-inf,inf,0},value= tSettings[%message]
	Button SendMessage,pos={18,106},size={126,20},proc=DiscordMessageButtonProc,title="Send Message"

End


//Put your controls down here (setVariableControl, buttonControl, ect...)


Function DiscordMessageCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			wave vSettings
			
			Variable checked = cba.checked
			vSettings[%$cba.ctrlName] = checked
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function DiscordMessageButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
			
				case "sendMessage":
					wave/t tSettings
					discordMessage(tSettings[%message], callback="")
				break
			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Window DiscordMessagePanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1011,424,1289,1135) as "DiscordMessageWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	TitleBox DiscordMessageTitle,pos={63,12},size={161,24},title="Discord Message"
	TitleBox DiscordMessageTitle,fSize=18,frame=0,fStyle=1
	TitleBox DiscordMessageEventTitle,pos={115,470},size={63,24},title="Events"
	TitleBox DiscordMessageEventTitle,fSize=18,frame=0,fStyle=1
	SetVariable MessageText,pos={18,54},size={243,16},title="Message Text"
	SetVariable MessageText,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DiscordMessage_1:tSettings[%message]
	SetVariable DiscordAddress,pos={18,74},size={243,16},title="Discord Address"
	SetVariable DiscordAddress,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DiscordMessage_1:tSettings[%discordAddress]
	Button SendMessage,pos={18,106},size={126,20},proc=DiscordMessageButtonProc,title="Send Message"
	ToolsGrid snap=1,visible=1
EndMacro
