import os
import json
import requests

file_path = os.path.dirname(__file__)

textPath = os.path.join(file_path, "CDNotificationText.txt")
discordFilePath = os.path.join(file_path, "DiscordAddress.txt")
imagePath = os.path.join(file_path, "photo.png")   # change this

with open(textPath) as f:
    message = f.readline().strip()

with open(discordFilePath) as fr:
    discordPath = fr.readline().strip()

with open(imagePath, "rb") as img:
    payload = {
        "content": message
    }

    files = {
        "payload_json": (None, json.dumps(payload)),
        "files[0]": ("photo.png", img, "image/png")
    }

    r = requests.post(discordPath, files=files)
    r.raise_for_status()