#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//This one will be a bit "Hacky"...


Function cryptidExecuteRepeat()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	ExecuteRepeat(vSettings,tSettings)
	

End


//This is the one that does things
Function ExecuteRepeat(vSettings,tSettings)

	Wave/t tSettings
	wave vSettings
	
	variable numRepeats = vSettings[%numberOfRepeats]
	variable startIndex = vSettings[%startIndex]
	
	//Set cryptid repeat counter for naming purposes
	wave cryptidSettings = getCryptidSettings(0)
	cryptidSettings[%repeatCounter] = vSettings[%repeatCounter]
	
	//Simply set the current step back one
	if (vSettings[%repeatCounter] < numRepeats)
		
		//I think we just need to adjust cryptids current step counter to be one before 
		//the desired start point
		
		//0 Should work now.....
		//I am just going to prohibit this I think...
		
		updateStatus("Repeat "+num2str(vSettings[%repeatCounter]) +"//"+num2str(numRepeats))
		
		cryptidSettings[%currentStep] = startIndex - 1
		vSettings[%repeatCounter] += 1
		cryptidSettings[%repeatCounter] += 1
		
		//NVM. going to try adjusting the save name in cryptid's main code if a repeat
		//I think I also need to increment the "full iterations" in cryptid to not cause problems with saving data?
		//cryptidSettings[%fullIterations]+=1
		
	//Reset if needed
	else
		cryptidSettings[%repeatCounter] = 0
		vSettings[%repeatCounter] = 0
		updateStatus("Repeats Completed")
	endif
	
	cryptidMain(1)
End

Function makeRepeatSettings()
	
	String packageName = "Repeat"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End





Function MakeRepeatPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="RepeatPanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="RepeatWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	//You can use getRTStackInfo to pass the name of the function that called this function, which can be helpful
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	
	//Put all of your panel stuffs here
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503

	
	
	TitleBox RepeatTitle,pos={112.00,11.00},size={60.00,25.00},title="Repeat"
	TitleBox RepeatTitle,fSize=18,frame=0,fStyle=1
	TitleBox ExampleEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox ExampleEventTitle,fSize=18,frame=0,fStyle=1
	SetVariable startIndex,pos={72.00,54.00},size={144.00,18.00},title="Start Index"
	SetVariable startIndex,help={"What stack item to start the repeats on?"}
	SetVariable startIndex,limits={0,inf,1},value=vSettings[%StartIndex]
	SetVariable NumberOfRepeats,pos={72.00,77.00},size={144.00,18.00}
	SetVariable NumberOfRepeats,title="Repeats"
	SetVariable NumberOfRepeats,help={"Number of repeats does not count the first iteration. Really it is number of repeats *after* the first one"}
	SetVariable NumberOfRepeats,limits={0,inf,1},value=vSettings[%NumberOfRepeats]

End




Window RepeatPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1048,338,1326,1049) as "RepeatWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	TitleBox RepeatTitle,pos={112,11},size={66,24},title="Repeat",fSize=18,frame=0
	TitleBox RepeatTitle,fStyle=1
	TitleBox ExampleEventTitle,pos={115,470},size={63,24},title="Events",fSize=18
	TitleBox ExampleEventTitle,frame=0,fStyle=1
	SetVariable startIndex,pos={72,54},size={144,16},title="Start Index"
	SetVariable startIndex,help={"What stack item to start the repeats on?"}
	SetVariable startIndex,limits={0,inf,1},value= root:Settings:Cryptid:WorkingFolders:Repeat_1:vSettings[%StartIndex]
	SetVariable NumberOfRepeats,pos={72,77},size={144,16},title="Repeats"
	SetVariable NumberOfRepeats,help={"Number of repeats does not count the first iteration. Really it is number of repeats *after* the first one"}
	SetVariable NumberOfRepeats,limits={0,inf,1},value= root:Settings:Cryptid:WorkingFolders:Repeat_1:vSettings[%NumberOfRepeats]
EndMacro
