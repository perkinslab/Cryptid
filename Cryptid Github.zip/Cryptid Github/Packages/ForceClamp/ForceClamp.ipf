#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=3.1

#include ":Dependencies:ConstantForceMotion"

Function setupForceClampWaves()

	//Just load the settings from the cryptid folder
	loadCryptidSettings("ForceClamp","vSettings;tSettings;",useCurrentDF=1)
	
	MakeMoveToPointCLSettingsWave(outputWaveName="XYPIDLoopSettings")
End

Function cryptidExecuteForceClamp()

	cryptidDebug()
	
	wave vSettings
	wave/t tSettings

	
	
	//I dont think keeping td_stop() will be an issue, but unsure?
	//Variable Error=td_stop()
	//If(Error>0)
	//	Print "Error in DoForceClamp: "+num2str(Error)
	//EndIf
	
	doForceClamp(vSettings,tSettings)

End


Function doForceClamp(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings

	string eventString="Event."+num2str(vSettings[%eventEnable])
	
	
	//If centering, record positoins as you go
	if (vSettings[%useCentering])
		make/O/N=(1,2) centeringMovement
		centeringMovement[0][0] = td_RV("Cypher.LVDT.X")*GV("XLVDTSens")
		centeringMovement[0][1] = td_RV("Cypher.LVDT.Y")*GV("YLVDTSens")
		setFCCenteringSettings()
	endif
	
	//Clear the event we are going to use
//	Variable Error = td_WS(EventString,"Clear")
//	Error+= td_WS("Event."+num2str(vSettings[%eventstop]),"Clear")
	
	//Report any errors. cryptidDebug will give the function, the time, and will only be enabled if cryptid:vSettings[%cryptidDebug] = 1
//	cryptidDebug(diagString="Asylum Error in td_WS: "+num2str(Error))
	
	setupForceClamp(vSettings,tSettings)


	//This is a background function to monitor for when the zSensor "rails"
	DoTipMoleculeMonitor()
	updateStatus("Clamp: "+num2str(vSettings[%Force_N]*10^12)+"pN")
	
	//This variable is used to keep track of time for possible centering
	variable/G lastCenterTime = ticks/60

	//Execute the command (callback is on SetInWave pair *AND* in MonitorTipMoleculeConnection()
	td_WriteString(eventString, "once")

End

Function setupFCFeedback()

	wave vSettings
	wave/t tSettings
	
	variable deflvOffset = getCVar("DeflVOffset")
	
	Variable Error = 0
	Variable Force_Volts = ForceToDeflection(vSettings[%Force_N],Offset=deflvOffset)
	cryptidDebug(diagString="PID Set to : "+num2str(Force_Volts))

	string eventString = num2str(vSettings[%eventEnable])+","+num2str(vSettings[%eventStop])

	//  Setup feedback loops
	Error +=	vs_setPISLoop(vSettings[%PISLoopBank],eventString,tSettings[%deflectionChannel],Force_Volts,vSettings[%P_Deflection], vSettings[%I_Deflection], vSettings[%S_Deflection],"Output.Z",-10,150)	
	
	return error

End

Function setupForceClamp(vSettings, tSettings)

	wave vSettings
	wave/t tSettings
	
	// Now figure out the decimation factor to give the closest sampling rate possible
	Variable DecimationFactor=Round(50000/vSettings[%$"SamplingRate_Hz"])
	Variable EffectiveSamplingRate=50000/DecimationFactor
	// How many points should we make these waves
	Variable NumPoints=Floor(vSettings[%$"MaxTime_s"]*EffectiveSamplingRate)

	// Make all waves and setup the wave references.  
	Make/N=(NumPoints)/O zSensorVolts, DeflVolts

	variable error = setupFCFeedback()
	
	// Setup input waves for x,y,z and deflection.  After the motion is done, callback will execute
	Error += td_xSetInWavePair(vSettings[%SCBank], num2str(vSettings[%eventEnable]), tSettings[%zSensorChannel], zSensorVolts, tSettings[%deflectionChannel], DeflVolts,"setZVoltage(0,\"ForceClampFinish()\")", DecimationFactor)
	
	if (error)
		cryptidDebug(diagString="Asylum Error in PISLoop or SetInWavePair: "+num2str(Error))
	endif
End


Function ForceClampFinish()
		
	Wave vSettings
	Wave/T tSettings
	//Stop the data recording
	td_StopInWaveBank(vSettings[%SCBank])
	StopForceClamp()

	//TEMPORARY FOR CENTERING DIAGNOSTICS
//	if (!DataFolderExists("root:TestCentering"))
//		newDataFolder root:TestCentering
//	endif
	variable masterIter = getCVar("totalIterations")
	variable fullIter = getCVar("fullIterations")
//	string newLoc = "root:TestCentering:"+"Centering"+num2str(masterIter)+"_"+num2str(fullIter)
	
//	DuplicateDataFolder $getDataFolder(1), $newLoc

	Wave DeflVolts 
	Wave zSensorVolts
	
	//added by bd
	Variable FCtol = vSettings[%forceTolerance]
	
	//Get rid of any NANS from ending early maybe? Unsure why Rob had this
	WaveTransform zapNaNs, DeflVolts
	WaveTransform zapNaNs, zSensorVolts
	
	//Railing seems to put the position off? Going to reset it here (move to spot we are currently at)
	Wave searchSettings = root:Settings:SearchGrid:SearchSettings
	SGmoveToSpot(searchSettings[%coarseSpotNumber],fineSpotNum=searchSettings[%fineSpotNumber])
	
	//Saving data externally here (Brandon Dzuba). Checked first to verify target was reached
	///////////////////////////////////////////////////////////////////
	Variable forceFC = vSettings[%Force_N]
	
	variable deflvOffset = getCVar("DeflVOffset")
	
	Variable highVolt = waveMin(DeflVolts)
	Variable maxForce = (deflVOffset - highVolt)*GV("InvOLS")*GV("SpringConstant")

	Variable targetReached = 0 //Only say a molecule is found if correct peak is reached
 	
 	//Check if the resulting wave ever got to the defined force 
 	//Will chage to work with the saved DeflV0 later *ADD ZERO FORCE NEXT"
	if (MaxForce > (ForceFC-FCtol))	
 		targetReached = 1
	else
		targetReached = 0
	endif
	
	updateCryptidGraph(deflVolts = DeflVolts, zSensorVolts = zSensorVolts)
	
	
	if (targetReached)
		updateStatus("Target Reached")
		string params = "TargetForce;"
		string values = num2str(vSettings[%Force_N])+";"
		writeToStdOut(params,values)

		cryptidMain(1, deflVolts = DeflVolts, zSensorVolts = zSensorVolts)
	else
		updateStatus("Not Reached :(")
		cryptidMain(0)
	endif
	
End


Function StopForceClamp()
	
	wave vSettings
	
	// Here we stop the z feedback loop and reset it.  Without this code, our next force ramp will just be stuck.  
	//td_stop()
	string eventString = "Event."+num2str(vSettings[%eventStop])
	td_WS(eventString,"Once")
	
	ir_StopPISLoop(-2)
	Struct ARFeedbackStruct FB
	ARGetFeedbackParms(FB,"outputZ")

	
	FB.StartEvent = num2str(vSettings[%eventEnable])
	FB.StopEvent =  num2str(vSettings[%eventStop])
	String ErrorStr
	ErrorStr += vs_writePIDSLoop(FB)
	ARBackground("MonitorTipMoleculeConnection",0,"")

End


Function MonitorTipMoleculeConnection()
	Wave HackMeterWave
	Variable DeflOffset=0
	Variable ZPztOffset=0
	Wave vSettings
	String DataFolder = GetDF("Meter")
	Wave UpdateMeterUpdate = $DataFolder+"UpdateMeterUpdate"
	Variable Height_V =UpdateMeterUpdate[%Height]
	
	
	If (Height_V<=0) // Zsensor railed, probably because the tip has disconnected from the molecule.
//		print "Railed"
		ForceClampFinish()
		Return 1  // Forces this background process to stop
	EndIf
	
	
	//We will also now handle the option of centering here
	Wave vSettings
	//If we cant find the useCentering dim label, something has gone wrong
	if (FindDimLabel(vSettings, 0, "useCentering" ) == -2)
		cryptidDebug(diagString="FC background process failed", alert=1)
		return 1
	endif
	
	if (vSettings[%useCentering])
		NVAR lastCenterTime
		variable currentTime = ticks/60
		if ((currentTime-lastCenterTime) > vSettings[%centeringFrequency])
			//Stop the background process..
			ARBackground("MonitorTipMoleculeConnection",0,"")
			lastCenterTime = currentTime
			
			setDataFolder Centering
			
			//Do the centering
			StartCFP(successCallback="ForceClampFinishCenter(1)",failCallback="ForceClampFinishCenter(0)")					

			return 1
		Endif
	Endif
	
	
	Return 0 // Must return 0 to keep background process repeating.

End

Function ForceClampFinishCenter(success)

	Variable success
	
	//Move back to parent folder
	setDataFolder ::
	
	//Restart the force clamp
	//  Setup feedback loops
	setupFCFeedback()
	wave vSettings
	td_WS("Event."+num2str(vSettings[%eventEnable]),"Once")
	
	//Update the centering time
	NVAR lastCenterTime
	lastCenterTime = ticks/60
	
	//Will want to make a wave to keep track of all of the movements done.
	Wave centeringMovement
	variable currentSize = dimsize(centeringMovement, 0)
	InsertPoints/M=0 currentSize, 1, centeringMovement
	
	//If success, record it and restart the PID loop at that spot
	Wave XYPIDLoopSettings
	if (success)
		print "Centering Successful"
		centeringMovement[currentSize][0] = td_RV("Cypher.LVDT.X")*GV("XLVDTSens")
		centeringMovement[currentSize][1] = td_RV("Cypher.LVDT.Y")*GV("YLVDTSens")
	
		Variable change = sqrt( (centeringMovement[currentSize][0]-centeringMovement[currentSize-1][0])^2 + (centeringMovement[currentSize][1]-centeringMovement[currentSize-1][1])^2 ) * 10^9
	
		updateStatus("Centering Change: "+num2str(change)+" nm" )
		
		
		FCXYPID(1, XYPIDLoopSettings)
	else //Move back to the previous position
		print "Centering Failed"
		centeringMovement[currentSize][0] =centeringMovement[currentSize-1][0]
		centeringMovement[currentSize][1] = centeringMovement[currentSize-1][1]
		FCXYPID(1, XYPIDLoopSettings, xPosV= centeringMovement[currentSize-1][0]/GV("XLVDTSens"), yPosV = centeringMovement[currentSize-1][1]/GV("YLVDTSens"))
	endif
	
	//Back up the entire centering folder for later use
	string newDF = "centering"+num2str(currentSize)
	if (dataFolderExists(newDF))
		killDataFolder $newDF
	endif
	duplicateDataFolder centering $newDF
	
	//save x,y,z waves for now
	Wave xSensorFine = :centering:xSensorFine
	Wave ySensorFine = :centering:ySensorFine
	Wave zSensorFine = :centering:ZSensorFine
	Wave xPos = :centering:XPos
	Wave yPos = :centering:YPos
	Wave zSensor_X = :centering:zSensor_X
	Wave zSensor_Y =  :centering:zSensor_Y
	Wave yFit = :Centering:yfit
	wave xFit = :Centering:xFit
	
	Variable xlvdtSens = GV("XLVDTSens")
	variable ylvdtSens = GV("YLVDTSens")
	variable zLVDTSens = GV("ZLVDTSens")

	
	duplicate/O xSensorFine $"XSF_"+num2str(currentSize)
	Wave XSF = $"XSF_"+num2str(currentSize)
	duplicate/O ySensorFine $"YSF_"+num2str(currentSize)
	Wave YSF = $"YSF_"+num2str(currentSize)
	duplicate/O xFit $"XFIT_"+num2str(currentSize)
	Wave XFitNew = $"XFIT_"+num2str(currentSize)
	duplicate/O yFit $"YFIT_"+num2str(currentSize)
	Wave yFitNew =  $"YFIT_"+num2str(currentSize)
	duplicate/O zSensorFine $"ZSF_"+num2str(currentSize)
	Wave ZSF = $"ZSF_"+num2str(currentSize)
	duplicate/O zSensor_x $"ZSX_"+num2str(currentSize)
	Wave ZSX = $"ZSX_"+num2str(currentSize)
	duplicate/O zSensor_y $"ZSY_"+num2str(currentSize)
	Wave ZSY = $"ZSY_"+num2str(currentSize)
	duplicate/O xPos $"xPos_"+num2str(currentSize)
	Wave xPosNew = $"xPos_"+num2str(currentSize)
	duplicate/O yPos $"yPos_"+num2str(currentSize)
	Wave yPosNew = $"yPos_"+num2str(currentSize)
	
//	XSF *= xlvdtSens
//	YSF *= ylvdtSens
//	ZSF *= zLVDTSens
//	xFitNew *= zlvdtSens
//	yFitNew *= yLVDTSens
	
	
	//Why not display them as we go?
	if (!windowExists("FineDisplay"))
		display/N=fineDisplay zSensorFine vs xSensorFine
		appendToGraph XFit vs XPos
		ModifyGraph LSize(XFit)=2
		appendToGraph/C=(0,0,0)/B=X2 zSensorFine vs ySensorFine
		appendToGraph/C=(0,0,0)/B=X2 YFit vs YPos
		ModifyGraph LSize(YFit)=2
		ModifyGraph freePos(X2)={1,kwFraction}
	endif

	
	doTipMoleculeMonitor()

End

Function DoTipMoleculeMonitor()
	ARBackground("MonitorTipMoleculeConnection",10,"")
End

Function makeForceClampPanel([PanelName,WindowName,hostName]):Panel

	String PanelName,WindowName, hostName
		
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(WindowName))
		WindowName="Force Clamp"
	EndIf
	If(ParamIsDefault(PanelName))
		PanelName="ForceClampPanel"
	EndIf
	
	//String WaveNameList="ClampSettings="+GetWavesDataFolder(vSettings,2)+";ClampSettingsStr="+GetWavesDataFolder(tSettings,2)+";"

	PauseUpdate; Silent 1		// building window...
	Variable panelWidth = 280
	Variable panelHeight = 700
	if (paramIsDefault(hostName))
		NewPanel/W=(0,0,280,700)/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
		
	ModifyPanel cbRGB=(47872,47872,47872)
	
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	
	
	SetVariable TargetForceSV,pos={9.00,54.00},size={207.00,18.00}
	SetVariable TargetForceSV,title="Target Force",format="%.1W1PN"
	SetVariable TargetForceSV,limits={0,inf,5e-12},value=vSettings[%Force_N]
	SetVariable forceTolerance,pos={9.00,81.00},size={207.00,18.00}
	SetVariable forceTolerance,title="Force Tolerance",format="%.1W1PN"
	SetVariable forceTolerance,value=vSettings[%forceTolerance]
	SetVariable SampleRateSV,pos={9.00,126.00},size={207.00,18.00}
	SetVariable SampleRateSV,title="Sample Rate",format="%.1W1PHz"
	SetVariable SampleRateSV,value=vSettings[%SamplingRate_Hz]
	SetVariable MaxTimeSV,pos={9.00,153.00},size={207.00,18.00},title="Max Time"
	SetVariable MaxTimeSV,format="%.0W1Ps"
	SetVariable MaxTimeSV,value=vSettings[%MaxTime_s]
	CheckBox useCentering,pos={9.00,261.00},size={90.00,15.00},proc=ForceClampCheckProc
	CheckBox useCentering,title="Use Centering",value=0
	SetVariable centerFrequency,pos={9.00,279.00},size={144.00,18.00}
	SetVariable centerFrequency,title="Center frequency",format="%.0W1Ps"
	SetVariable centerFrequency,value=vSettings[%CenteringFrequency]
	TitleBox ForceClampTitle,pos={85.00,11.00},size={104.00,25.00}
	TitleBox ForceClampTitle,title="Force Clamp",fSize=18,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox DCEventTitle,fSize=18,frame=0,fStyle=1
	SetVariable FCEventEnable,pos={9.00,513.00},size={207.00,18.00}
	SetVariable FCEventEnable,title="Event Enable"
	SetVariable FCEventEnable,value=vSettings[%eventEnable]
	SetVariable FCEventStop,pos={9.00,536.00},size={207.00,18.00},title="Event Stop"
	SetVariable FCEventStop,value=vSettings[%eventStop]
	SetVariable FCDeflectionChannel,pos={9.00,198.00},size={207.00,18.00}
	SetVariable FCDeflectionChannel,title="Deflection Channel",format="%.0W1Ps"
	SetVariable FCDeflectionChannel,value=tSettings[%deflectionChannel]
	SetVariable FCZSensorChannel,pos={9.00,225.00},size={207.00,18.00}
	SetVariable FCZSensorChannel,title="ZSensorChannel",format="%.0W1Ps"
	SetVariable FCZSensorChannel,value=tSettings[%zSensorChannel]



End

Function ForceClampButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	String ButtonName=ba.CtrlName
	Wave vSettings=root:ForceClamp:vSettings

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function setZVoltage(zVoltage, callback)

	Variable zVoltage
	String Callback
	
	print "Time Ran Out"
	stopForceClamp()
	td_WV("Output.z", zVoltage)
	sleep/s 0.5
	Execute callback
	
end

Function ForceClampCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			string ctrlName = cba.ctrlName
			
			wave vSettings
			vSettings[%$ctrlName] = cba.checked
						
			
			strSwitch(ctrlName)
				case "useCentering":
					
					if (cba.checked)
						initializeSubModule("Centering")
						//Set up the defaults we want
						setFCCenteringSettings()
					else
						string windowName = getDataFolder(0)+"_Centering"
						
						if(windowExists(windowName))
							killWindow $windowName
						endif
						killDataFolder/Z centering
					endif
					
					break
			
			endSwitch
			
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function setFCCenteringSettings()

	Wave CFPSettings = :centering:CFPSettings
	Wave vSettings
	
	//Unsure the best settings, gunna start from here
	CFPSettings[%$"Critical Fit Difference"] =10e-9			//OG was 1e-8, but that seems to much...
	CFPSettings[%TargetForce] = vSettings[%Force_N]		//Gotta use the same force
	CFPSettings[%circleRadius] = 1.5e-8					//15 nm radius. Again seems large but in the settings list
	CFPSettings[%$"Distance to move from center"] = 30e-9	//Cross size. Gunna start small

	//Need to move this to two to prevent issues with centering
	vSettings[%SCBank] = 2
	//Defaults
	//Uses (and stops) in wave banks 0,1
	//Uses out wave banks 0
	//Uses event.0
	
	//DistanceFromCenter_m is the length of the cross on either side 
End




Window ForceClampPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1472,264,1752,964) as "Force Clamp"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable TargetForceSV,pos={9.00,54.00},size={207.00,18.00}
	SetVariable TargetForceSV,title="Target Force",format="%.1W1PN"
	SetVariable TargetForceSV,limits={0,inf,5e-12},value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%Force_N]
	SetVariable forceTolerance,pos={9.00,81.00},size={207.00,18.00}
	SetVariable forceTolerance,title="Force Tolerance",format="%.1W1PN"
	SetVariable forceTolerance,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%forceTolerance]
	SetVariable SampleRateSV,pos={9.00,126.00},size={207.00,18.00}
	SetVariable SampleRateSV,title="Sample Rate",format="%.1W1PHz"
	SetVariable SampleRateSV,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%SamplingRate_Hz]
	SetVariable MaxTimeSV,pos={9.00,153.00},size={207.00,18.00},title="Max Time"
	SetVariable MaxTimeSV,format="%.0W1Ps"
	SetVariable MaxTimeSV,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%MaxTime_s]
	CheckBox useCentering,pos={9.00,261.00},size={90.00,15.00},proc=ForceClampCheckProc
	CheckBox useCentering,title="Use Centering",value=0
	SetVariable centerFrequency,pos={9.00,279.00},size={144.00,18.00}
	SetVariable centerFrequency,title="Center frequency",format="%.0W1Ps"
	SetVariable centerFrequency,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%CenteringFrequency]
	TitleBox ForceClampTitle,pos={85.00,11.00},size={104.00,25.00}
	TitleBox ForceClampTitle,title="Force Clamp",fSize=18,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox DCEventTitle,fSize=18,frame=0,fStyle=1
	SetVariable FCEventEnable,pos={9.00,513.00},size={207.00,18.00}
	SetVariable FCEventEnable,title="Event Enable"
	SetVariable FCEventEnable,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%eventEnable]
	SetVariable FCEventStop,pos={9.00,536.00},size={207.00,18.00},title="Event Stop"
	SetVariable FCEventStop,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:vSettings[%eventStop]
	SetVariable FCDeflectionChannel,pos={9.00,198.00},size={207.00,18.00}
	SetVariable FCDeflectionChannel,title="Deflection Channel",format="%.0W1Ps"
	SetVariable FCDeflectionChannel,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:tSettings[%deflectionChannel]
	SetVariable FCZSensorChannel,pos={9.00,225.00},size={207.00,18.00}
	SetVariable FCZSensorChannel,title="ZSensorChannel",format="%.0W1Ps"
	SetVariable FCZSensorChannel,value=root:Settings:Cryptid:WorkingFolders:ForceClamp_2:tSettings[%zSensorChannel]
	ToolsGrid snap=1,visible=1
EndMacro


Function FCXYPID(start, settingsWave, [xposV,yPosV])

	variable start, xPosV,yPosV
	wave settingsWave
	
	if(paramIsDefault(xposV))
		xposV = td_RV("Cypher.LVDT.X")
	endif
	if(paramIsDefault(yPosV))
		yPosV =  td_RV("Cypher.LVDT.Y")
	endif
	
	if (start)
		vs_setPISLoop(0,"Always,Never","Cypher.LVDT.X",xPosV,settingsWave[%P_X], settingsWave[%I_X], settingsWave[%S_X],"ARC.Output.X",-10,150)
		vs_setPISLoop(1,"Always,Never","Cypher.LVDT.Y",yPosV,settingsWave[%P_Y], settingsWave[%I_Y], settingsWave[%S_Y],"ARC.Output.Y",-10,150)
	else
		ir_StopPISLoop(0)
		ir_StopPISLoop(1)
	endif
End

Function checkCentering()

	Wave centeringMovement
	duplicate/O centeringMovement CM
	CM *= 10^9
	variable xoffset = CM[0][0]
	variable yoffset = CM[0][1]
	
	CM[*][0] -= xOffset
	CM[*][0] -= yOffset
	
	display CM[*][1] vs CM[*][0]
	ModifyGraph mode=3,marker=19,msize=3
End