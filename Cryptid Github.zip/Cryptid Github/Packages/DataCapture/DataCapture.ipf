#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1




//************EXECUTE COMMAND*************
//This is a wrapper function for cryptid to call
//Put the name in the executables file
Function cryptidExecuteDataCapture()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	DoDataCapture(vSettings,tSettings)
	

End


//This is the actual function that does things. This stucture is so you can pass
//Around the settings files, hopefully making the program work outside of cryptid
Function DoDataCapture(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings
	
	//Bail if no max time is given (its a feature, trust me)
	if (vSettings[%maxTime] == 0)
		cryptidMain(1)
		return 0
	endif
	
	Variable Error=0
	
	tSettings[%mainLocation] = getDataFolder(1)
	
	//We need to set up an event. Best to put this in your settings and set a default value
	String EventString=tSettings[%eventEnable]//+","+tSettings[%eventStop]
	
	//Clear the event we are going to use
	Error += td_WS(tSettings[%eventEnable],"Clear")
//	Error += td_WS(tSettings[%eventStop],"Clear")
	
	//Use cryptidDebug to print. Check optional parameters for more info
	cryptidDebug(diagString="Asylum Error in td_WS: "+num2str(Error))

	//Here we set up our inWaves. Make the waves, set up the td_xSetInWave stuff ect....
	SetupDataCaptureData(vSettings,tSettings)
	
	//Update the waves in the stop panel
	DCUpdateStopWaves()
	
	//Here we execute
	ExecuteDataCapture(vSettings, tSettings)
End



//Here we set up our data recording
//I've left this example from the package "Dwell" as a good example.
Function SetupDataCaptureData(vSettings,tSettings)

	Wave vSettings
	Wave/t tSettings
	td_StopStream("Cypher.Stream.0")
	cryptidDebug()

	//Decide what kind of data to set up, and do that
	string eventString = tSettings[%eventEnable]//+","+tSettings[%eventStop]
	
	Variable captureRate = -1
	if (vSettings[%DCFastCapture])
		//Do Fast capture
		strSwitch(tSettings[%DCFCaptureRate])
		
			//These cases will use the dataStream method
			case "500 KHz":
				vSettings[%CaptureRate] = 500000
				//Deflection must be inFastB for now
				Make/O/N=0 deflectionWaveStream, zSensorWaveStream
				setupStream(0, vSettings[%maxTime], deflectionWaveStream, zSensorWaveStream,event=tSettings[%EventEnable])
				break
			case "2 MHz":
				vSettings[%CaptureRate] = 2000000
				Make/O/N=0 deflectionWaveStream, zSensorWaveStream
				setupStream(1, vSettings[%maxTime], deflectionWaveStream, zSensorWaveStream,event=tSettings[%EventEnable])
				break
			//These will use fast capture. SC must be completed if FC is being used?
			case "5 MHz":
				vSettings[%CaptureRate] = 5e6
				//td_wv("cypher.input.fastA.filter.freq",1e3)
				setupFastCapture(vSettings[%maxTime], 5e6)
				break
			case "20 MHz":
				vSettings[%CaptureRate] = 20e6
				setupFastCapture(vSettings[%maxTime], 20e6)
				break
			case "80 MHz":
				vSettings[%CaptureRate] = 80e6
				setupFastCapture(vSettings[%maxTime], 80e6)
				break
			
		EndSwitch
		
		//Also setup standard capture if using > 5Mhz
		if (vSettings[%captureRate] >= 5e6)
			//Setup standard capture
			Variable deci = ARGetDeci(50000)
			Variable effectiveSamplingRate = 50000 / deci
			
			// How many points should we make these waves
			Variable NumPoints=Floor(vSettings[%maxTime]*EffectiveSamplingRate)
			
			Make/O/N=(NumPoints) deflectionWave, zSensorWave
			
			Wave deflectionWave, zSensorWave
			prepWavesForSC(deflectionWave,zSensorWave,effectiveSamplingRate,vSettings[%maxTime])
			
			td_XSetInWavePair(vSettings[%Whichbank],eventString,tSettings[%deflectionChannel],deflectionWave,tSettings[%zSensorChannel],ZSensorWave,"",Deci)
		endif
		
	else
		
		//Setup standard capture
		deci = ARGetDeci(vSettings[%captureRate])
		effectiveSamplingRate = 50000 / deci
		
		// How many points should we make these waves
		NumPoints=Floor(vSettings[%maxTime]*EffectiveSamplingRate)
		
		Make/O/N=(NumPoints) deflectionWave, zSensorWave
		
		Wave deflectionWave, zSensorWave
		prepWavesForSC(deflectionWave,zSensorWave,effectiveSamplingRate,vSettings[%maxTime])
		
		td_XSetInWavePair(vSettings[%Whichbank],eventString,tSettings[%deflectionChannel],deflectionWave,tSettings[%zSensorChannel],ZSensorWave,"print \"Data Collection Completed\"",Deci)
	endif
	
	cryptidDebug(diagString="Capture rate set at : "+num2str(vSettings[%captureRate]))
	
End

//This function actually starts the program, usually through td_WS
Function ExecuteDataCapture(vSettings,tSettings)

	Wave/t tSettings
	wave vSettings
	
	String EventString="Event."+tSettings[%eventEnable]
	
	cryptidDebug()

	
	if(vSettings[%DCStartNow] || (vSettings[%captureRate] >= 5e6)) //Actually execute the thing
		updateStatus("Begining "+num2str(vSettings[%captureRate]/1000)+ " KHz Capture")
		
		//If using FC, start it
		if (vSettings[%captureRate] >= 5e6)
			executeFastCapture()
		endif
		//Devin has td_WS("ARC.Events.Once","1"), though I haven't seen this syntax before
		td_WS(EventString,"Once")

	endif
	
	cryptidMain(1)
End


Function cryptidExecuteDataCaptureStop()

	//These should be copies of the ones in the DC folder 
	SVAR mainLocation
	wave vSettings = $mainLocation+"vSettings"
	wave/t tSettings = $mainLocation+"tSettings"
	
	//Bail if no max time is given (its a feature, trust me)
	if (vSettings[%maxTime] == 0)
		cryptidMain(1)
		return 0
	endif
	
	
	if(!WaveExists(vSettings))
		CryptidDebug(diagString="Issue with DataCapture. Try remaking EndDataCapture", alwaysPrint=1, Alert=1,updateDisplay=1)
	endif
		
	cryptidDebug()
	if (vSettings[%DCFastCapture])
		//if using debugstream to do 500KHz or 2MHz
		if (vSettings[%captureRate] <= (2e6+1))
			td_StopStream("Cypher.Stream.0")
			//For some reason the unfilled portion of the waves is filled with a random value?

			Wave deflectionWaveStream = $mainLocation+"deflectionWaveStream"
			Wave zSensorWaveStream = $mainLocation+"zSensorWaveStream"
			
			WaveTransform zapNans deflectionWaveStream
			WaveTransform zapNans zSensorWaveStream
			
			//Need to remove trailing 0's there for some reason
			killTrailingZeroes(deflectionWaveStream)
			redimension/N=(dimsize(deflectionWaveStream,0)) zSensorWaveStream
			
			updateStatus("FC Completed, saving waves...")

			//Might get rid of this if it is slow
			//updateCryptidGraph(deflVolts = deflectionWaveStream, zSensorVolts=zSensorWaveStream)

			cryptidMain(1, deflVolts=deflectionWaveStream, zSensorVolts=zSensorWaveStream, saveName=tSettings[%saveName]+"_",FC=1)
			
			
		else //using normal fastcapture
			
			//Stop both captures
			//I'm pretty sure stopcapture does nothing....
			//td_StopCapture("Cypher.Capture.0")
			td_StopInWaveBank(vSettings[%Whichbank])
			Wave deflectionWave =  $mainLocation+"deflectionWave"
			Wave zSensorWave =  $mainLocation+"zSensorWave"
			waveTransform zapNaNs deflectionWave
			waveTransform zapNaNs zSensorWave
			updateCryptidGraph(deflVolts = deflectionWave, zSensorVolts=zSensorWave)
			
			//Stop the wave (will need to use a callback here
			updateStatus("FC Completed, pulling data...")
			variable estTime = (vSettings[%maxTime]*vSettings[%captureRate])/(8.08808e+06 * 1.1)
			cryptidTimerProgress("Pulling FC Wave...", estTime)
			pullFastCapture("DCFastCaptureCallback()","root:FCData")
			
		endif
		
	//If using standard capture
	//Should modify to allow both kinds of capture	
	else
		td_StopInWaveBank(vSettings[%Whichbank])
		Wave deflectionWave =  $mainLocation+"deflectionWave"
		Wave zSensorWave =  $mainLocation+"zSensorWave"
		
		waveTransform zapNaNs deflectionWave
		waveTransform zapNaNs zSensorWave
		updateCryptidGraph(deflVolts = deflectionWave, zSensorVolts=zSensorWave)
		
		cryptidMain(1, deflVolts=deflectionWave, zSensorVolts=zSensorWave, saveName=tSettings[%saveName]+"_")
	endif

End

Function DCFastCaptureCallback()

	SVAR mainLocation
	Wave/t tSettings = $mainLocation+"tSettings"
	
	killWindow progressWindow
	
	Wave FCData = root:FCData
	saveFastCapture(FCData, tSettings[%saveName], getCVar("FullIterations"))
	
	//Continue the program
	Wave deflectionWave =  $mainLocation+"deflectionWave"
	Wave zSensorWave =  $mainLocation+"zSensorWave"
	cryptidMain(1, deflVolts=deflectionWave, zSensorVolts=zSensorWave, saveName=tSettings[%saveName]+"_")

End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeDataCaptureSettings()
	
	String packageName = "DataCapture"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End




Function MakeDataCaptureStopPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="DataCapturePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="DataCaptureWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	//You can use getRTStackInfo to pass the name of the function that called this function, which can be helpful
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	

End



//Put your controls down here (setVariableControl, buttonControl, ect...)


Function DataCaptureCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			wave vSettings
			vSettings[%$cba.ctrlName] = cba.checked
			
			
			strSwitch(cba.ctrlName)
			
				case "DCFastCapture":
					
				//	setVariable DCSCaptureRate, disable=cba.checked
				//	popupMenu DCFCaptureRate, disable=!cba.checked
						
				
					break
			
			EndSwitch
			
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function PopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa

	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			
			wave/t tSettings
			tSettings[%$pa.ctrlName] = pa.popStr
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function DataCaptureButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
				
				case "DCSetEndStep":
				
					wave vSettings
					wave/t tSEttings
					variable spot = vSettings[%DCEndStep]
						
					string currentDF = getDataFolder(1)
					
					cryptidAddStep(expType="DataCaptureStop",position = spot)
					
					String/G mainLocation = currentDF
					
					setDataFolder $currentDF
					//Need to copy our waves into the dew dataFolder
					DCUpdateStopWaves()
					
					break
			
			EndSwitch
			
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function DCUpdateStopWaves()

	wave vSettings
	wave/t tSettings
	
	Wave/T cryptidStack = getCryptidStack()
	string newDF = getWorkingFolder(cryptidStack[vSettings[%DCEndStep]][%Name])
	
	duplicate/O tSettings $newDF+"tSettings"
	duplicate/o vSettings $newDF+"vSettings"

End


//Cryptid calls this function by passing its own values to panelName, widowName, and hostName
//This function is written so that if you call it with defaults, it will make its own window
//I highly recommend copying large parts of this function, and just replacing that last part
// 
//For easiest modification, make your panel using the graphical tools for panel making,
//Save it, and then copy the control's code to the bottom of this function
//You will need to replace all values to vSettings,tSettings instead of absolute paths to 
//make it work (I.E.): value=root:Settings:ExamplePackage:vSettings[%someValue] will need to be changed
//to 						value=vSettings[%someValue] to work with cryptid
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeDataCapturePanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="DataCapturePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="DataCaptureWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	//You can use getRTStackInfo to pass the name of the function that called this function, which can be helpful
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	
	//Put all of your panel stuffs here
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	
	SetVariable DCSCaptureRate,pos={27,263},size={144,16},disable=1,title="Capture Rate"
	SetVariable DCSCaptureRate,format="%.1W1PHz"
	SetVariable DCSCaptureRate,limits={-inf,inf,0},value= vSettings[%CaptureRate]
	TitleBox DataCaptureTitle,pos={85,11},size={120,24},title="Data Capture"
	TitleBox DataCaptureTitle,fSize=18,frame=0,fStyle=1
	PopupMenu DCFCaptureRate,pos={214,99},size={20,22},bodyWidth=20,proc=PopMenuProc,title=" "
	PopupMenu DCFCaptureRate,mode=0,value= #"\"500 KHz;2 MHz;5 MHz;20 MHz;80 MHz;\""
	SetVariable DCMaxTime,pos={18,126},size={144,16},title="Max Time"
	SetVariable DCMaxTime,help={"Max time recording will last. Needed to prevent waves from being too large"}
	SetVariable DCMaxTime,format="%.1W1Ps"
	SetVariable DCMaxTime,limits={-inf,inf,0},value= vSettings[%MaxTime]
	SetVariable DCEndStep,pos={18,150},size={144,16},title="End Step"
	SetVariable DCEndStep,help={"Where to put the \"end step\". This step, in the experiment stack, will end the data capture"}
	SetVariable DCEndStep,format="%.0W1P"
	SetVariable DCEndStep,value= vSettings[%DCEndStep]
	Button DCSetEndStep,pos={166,149},size={50,20},proc=DataCaptureButtonProc,title="Set"
	SetVariable DCDeflectionChannel,pos={18,200},size={198,16},title="Deflection Channel"
	SetVariable DCDeflectionChannel,format="%.1W1Ps"
	SetVariable DCDeflectionChannel,limits={-inf,inf,0},value= tSettings[%DeflectionChannel]
	SetVariable DCZSensorChannel1,pos={18,225},size={198,16},title="ZSensor Channel"
	SetVariable DCZSensorChannel1,format="%.1W1Ps"
	SetVariable DCZSensorChannel1,limits={-inf,inf,0},value= tSettings[%ZSensorChannel]
	SetVariable DCSaveName2,pos={18,178},size={198,16},title="Save Name"
	SetVariable DCSaveName2,format="%.1W1Ps"
	SetVariable DCSaveName2,limits={-inf,inf,0},value= tSettings[%SaveName]
	SetVariable DCEventEnable,pos={9,513},size={144,16},title="Event Enable"
	SetVariable DCEventEnable,format="%.1W1Ps"
	SetVariable DCEventEnable,limits={-inf,inf,0},value= tSettings[%EventEnable]
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable DCSCBank,pos={9,534},size={144,16},title="SC Bank"
	SetVariable DCSCBank,limits={-inf,inf,0},value= vSettings[%whichBank]
	SetVariable FastCapture,pos={18,56},size={144,16},title="Fast Capture"
	SetVariable FastCapture,help={"Fast or normal capture"}
	SetVariable FastCapture,limits={0,1,1},value= vSettings[%DCFastCapture]
	SetVariable DCSCaptureRate1,pos={36,81},size={198,16},title="Standard Capture Rate"
	SetVariable DCSCaptureRate1,help={"If normal capture, data acquisition rate"}
	SetVariable DCSCaptureRate1,format="%.1W1PHz"
	SetVariable DCSCaptureRate1,limits={-inf,inf,0},value= vSettings[%CaptureRate]
	SetVariable DCSCaptureRate2,pos={36,101},size={180,16},title="Fast Capture Rate"
	SetVariable DCSCaptureRate2,help={"If fast capture, data acquisition rate. Note that above 2 MHz, only one channel (deflection by default) can be recorded"}
	SetVariable DCSCaptureRate2,limits={-inf,inf,0},value= tSettings[%DCFCaptureRate]
	SetVariable startNow,pos={162,513},size={81,16},title="Start Now"
	SetVariable startNow,help={"If set, instead of using an event, will simply start data capture when the step is executed. If set, will only start when \"Event Enable\" is triggered (in a subsequent step)"}
	SetVariable startNow,limits={0,1,1},value= vSettings[%DCStartNow]

End

Window DataCapturePanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1163,785,1441,1496) as "DataCaptureWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable DCSCaptureRate,pos={27,263},size={144,16},disable=1,title="Capture Rate"
	SetVariable DCSCaptureRate,format="%.1W1PHz"
	SetVariable DCSCaptureRate,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%CaptureRate]
	TitleBox DataCaptureTitle,pos={85,11},size={120,24},title="Data Capture"
	TitleBox DataCaptureTitle,fSize=18,frame=0,fStyle=1
	PopupMenu DCFCaptureRate,pos={214,99},size={20,22},bodyWidth=20,proc=PopMenuProc,title=" "
	PopupMenu DCFCaptureRate,mode=0,value= #"\"500 KHz;2 MHz;5 MHz;20 MHz;80 MHz;\""
	SetVariable DCMaxTime,pos={18,126},size={144,16},title="Max Time"
	SetVariable DCMaxTime,help={"Max time recording will last. Needed to prevent waves from being too large"}
	SetVariable DCMaxTime,format="%.1W1Ps"
	SetVariable DCMaxTime,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%MaxTime]
	SetVariable DCEndStep,pos={18,150},size={144,16},title="End Step"
	SetVariable DCEndStep,help={"Where to put the \"end step\". This step, in the experiment stack, will end the data capture"}
	SetVariable DCEndStep,format="%.0W1P"
	SetVariable DCEndStep,value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%DCEndStep]
	Button DCSetEndStep,pos={166,149},size={50,20},proc=DataCaptureButtonProc,title="Set"
	SetVariable DCDeflectionChannel,pos={18,200},size={198,16},title="Deflection Channel"
	SetVariable DCDeflectionChannel,format="%.1W1Ps"
	SetVariable DCDeflectionChannel,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:tSettings[%DeflectionChannel]
	SetVariable DCZSensorChannel1,pos={18,225},size={198,16},title="ZSensor Channel"
	SetVariable DCZSensorChannel1,format="%.1W1Ps"
	SetVariable DCZSensorChannel1,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:tSettings[%ZSensorChannel]
	SetVariable DCSaveName2,pos={18,178},size={198,16},title="Save Name"
	SetVariable DCSaveName2,format="%.1W1Ps"
	SetVariable DCSaveName2,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:tSettings[%SaveName]
	SetVariable DCEventEnable,pos={9,513},size={144,16},title="Event Enable"
	SetVariable DCEventEnable,format="%.1W1Ps"
	SetVariable DCEventEnable,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:tSettings[%EventEnable]
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable DCSCBank,pos={9,534},size={144,16},title="SC Bank"
	SetVariable DCSCBank,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%whichBank]
	SetVariable FastCapture,pos={18,56},size={144,16},title="Fast Capture"
	SetVariable FastCapture,help={"Fast or normal capture"}
	SetVariable FastCapture,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%DCFastCapture]
	SetVariable DCSCaptureRate1,pos={36,81},size={198,16},title="Standard Capture Rate"
	SetVariable DCSCaptureRate1,help={"If normal capture, data acquisition rate"}
	SetVariable DCSCaptureRate1,format="%.1W1PHz"
	SetVariable DCSCaptureRate1,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%CaptureRate]
	SetVariable DCSCaptureRate2,pos={36,101},size={180,16},title="Fast Capture Rate"
	SetVariable DCSCaptureRate2,help={"If fast capture, data acquisition rate. Note that above 2 MHz, only one channel (deflection by default) can be recorded"}
	SetVariable DCSCaptureRate2,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:tSettings[%DCFCaptureRate]
	SetVariable startNow,pos={162,513},size={81,16},title="Start Now"
	SetVariable startNow,help={"If set, instead of using an event, will simply start data capture when the step is executed. If set, will only start when \"Event Enable\" is triggered (in a subsequent step)"}
	SetVariable startNow,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:DataCapture_4:vSettings[%DCStartNow]
	ToolsGrid snap=1,visible=1
EndMacro
