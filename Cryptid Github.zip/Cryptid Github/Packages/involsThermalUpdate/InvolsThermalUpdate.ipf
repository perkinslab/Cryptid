#pragma TextEncoding = "UTF-8"
#pragma rtGlobals=3				// Use modern global access method and strict wave access
#pragma DefaultTab={3,20,4}		// Set default tab width in Igor Pro 9 and later

//Brandon Dzuba 11/30/2023


Function executeInvolsThermalUpdate([callback])

	string callback
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	if(paramIsDefault(callback))
		callback="cryptidMain(1)"
	endif
	
	vSettings[%startValue] = GV("Invols")
	
	//All thermal parameters need to be non-relative to prevent issues if the DF is changed
	safeDuplicate(vSettings, "root:Settings:thermalvSettings")
	safeDuplicate(tSettings, "root:Settings:thermalTSettings")
	
	doUpdateThermalInvols(callback=callback)
	
End

Function makeThermalInvolsSettings()

	cryptidDebug()
	
	loadCryptidSettings("involsThermalUpdate","tSettings;vSettings", useCurrentDF=1)
	
End

Function/Wave getThermalSettings(type)

	variable type
	string returnWaveName
	if (type)
		returnWaveName = "root:Settings:thermalTSettings"
	else
		returnWaveName = "root:Settings:thermalVSettings"
	endif
	
	return $returnWaveName

End


Function doUpdateThermalInvols([callback])
	
	string callback
	
	wave vSettings = getThermalSettings(0)
	wave/t tSettings = getThermalSettings(1)

	if(paramIsDefault(callback))
		callback = "cryptidMain(1)"
	endif
	
	//Show the thermal window
	doWindow/F thermalGraph
	
	tSettings[%callback] = callback
	
	Wave thermalVariables = root:packages:MFP3D:Main:Variables:ThermalVariablesWave
	
	vSettings[%startTime] = ticks
	
	//Show the thermal (removed for v16)
//	DoThermalFunc("ShowThermalButton_1")
		
	//Get the thermal
	DoThermalFunc("DoThermalButton_1")
	
	//start background monitor at 1Hz
	ARBackground("monitorThermal",1,"")

End

//Background function to monitor if the thermal is done
Function monitorThermal()

	Wave thermalVariables = root:packages:MFP3D:Main:Variables:ThermalVariablesWave
	wave vSettings = getThermalSettings(0)

	
	Variable currentTime = ticks
	Variable elapsedTime = abs(currentTime - vSettings[%startTime])/60
	
	if ((thermalVariables[%ThermalCounter][0] > vSettings[%maxSamples]) || elapsedTime > vSettings[%maxThermalTime])
		vSettings[%startTime] = ticks
		stopThermal()
		return 1
	endif
	
	return 0	
End

Function stopThermal()

	DoThermalFunc("StopThermalButton_1")
	
	//save the thermal wave to check for any differences
	duplicate/o root:packages:MFP3D:Main:Variables:ThermalVariablesWave tempWave
	
	ARBackground("waitThermal",1,"")
	
End

//Background function to wait while fit is being conducted
Function waitThermal()

	wave vSettings = getThermalSettings(0)

	Variable currentTime = ticks
	Variable elapsedTime = abs(currentTime - vSettings[%startTime])/60
	if (elapsedTime > 3)	//wait 3 seconds to let light turn back on
		fitThermal()
		return 1
	endif
	
	return 0	
End


Function fitThermal()
	
	DoThermalFunc("TryFit_1")

	//start background monitor at 1Hz
	ARBackground("monitorFit",1,"")

End


//Background function to monitor if the thermal is done
Function monitorFit()

	Wave thermalVariables = root:packages:MFP3D:Main:Variables:ThermalVariablesWave
	wave vSettings = getThermalSettings(0)

	Variable currentTime = ticks	
	Wave tempWave
	Variable elapsedTime = (currentTime - vSettings[%startTime])/60
	
	//Here we monitor for the thermal DC to change or > 10 seconds elapsed
	if ((tempWave[%ThermalDC] != ThermalVariables[%thermalDC]) || elapsedTime > 10)
		finishAutoThemalInvols()
		return 1
	endif
	
	return 0	
End

Function finishAutoThemalInvols()

	Wave thermalVariables = root:packages:MFP3D:Main:Variables:ThermalVariablesWave
	wave vSettings = getThermalSettings(0)
	wave/t tSettings = getThermalSettings(1)
	
	string callback
	
	if (vSettings[%saveThermal])
		SVAR gBaseName = root:Packages:MFP3D:Main:Variables:BaseName
		gBaseName="AAThermal"
		wave MVW = root:Packages:MFP3D:Main:Variables:MasterVariablesWave
		
		MVW[%baseSuffix][%Value] = getCVar("FullIterations")
		
		//Save the thermal (copy of asylum's code)
		String DataFolder = GetDF("Tune")
		Wave/Z Defl = $DataFolder+"TotalPSD"
		Duplicate/FREE Defl,Freq,TimeWave
		Ax2Wave(Defl,0,Freq)
		TimeWave[] = 1/Freq[P]
		Wave Raw = Freq

		//Save the fit params in the note
		ARSaveAsForce(1 | (GV("SaveForce") & 2),"SaveForce","Defl;Freq;Time;",Raw,Defl,Freq,TimeWave,$"",$"",$"",CustomNote="IsThermalPlot:1\r")
		MakePanel("MasterForce")
		
	endif
	
	if (thermalVariables[%badThermal])
		
		//put code in here to reset invols?
		cryptidDebug(diagString="BAD THERMAL!!!",alwaysPrint=1,alert=1,updateDisplay=1,message=1)
		wave vSettings = getCryptidSettings(0)
		vSettings[%stop] = 1
		doScanFunc("StopScan_0")
		listbox StackDisplay disable=0, win=$getCStr("PanelName")
		return -1
		
	endif
	
	variable newInvols = GV("Invols")
	variable change = abs(newInvols - vSettings[%startValue]) / vSettings[%startValue]
	//If we changed by over 25%, probably bad
	if (vSettings[%startValue] != 0 && change > 0.25)
		cryptidDebug(diagString="Thermal fit changed by "+num2str(change),alwaysprint=1,updateDisplay=1,message=1)
	
		wave vSettings = getCryptidSettings(0)
		vSettings[%stop] = 1
		doScanFunc("StopScan_0")
		listbox StackDisplay disable=0, win=$getCStr("PanelName")
		return -1
	endif
	ModifyGraph/W=thermalGraph log(bottom)=1
	
	//Lets record the change invols with time
	Wave involsOverTime = root:InvolsOverTime
	if (!WaveExists(involsOverTIme))
		make/O/N=(0,3) root:InvolsOverTime
		Wave involsOverTime = root:InvolsOverTime
		setDimLabel 1, 0, invols,involsOverTime
		setDimLabel 1, 1, seconds,involsOverTime
		setDimLabel 1, 2, spotnumber,involsOverTime
	endif
	
	variable currentSize = dimsize(involsOverTime,0)
	insertPoints/M=0 currentSize, 1, involsOverTime
	involsOverTime[currentSize][%seconds] = dateTime
	involsOverTime[currentSize][%invols] = newInvols
	involsOverTime[currentSize][%spotNumber] = getCoarseSpotNumber()

	cryptidDebug(diagString = "New Invols: " + num2str(newInvols))

	//Also need to update the force offset in case we zeroed
	getNewDeflVOffset(tSettings[%callback])
	//execute tSettings[%callback]

End



Function involsCheckBoxProc(ca) : checkboxControl
	
	STRUCT WMCheckboxAction &ca
	
	switch( ca.eventCode )
		case 2: // mouse up
			// click code here
			string ctrlName = ca.ctrlName
			
			wave vSettings
			wave/t tSettings
			vSettings[%$ctrlName] = ca.checked
			
			
			break
		case -1: // control being killed
			break
	endswitch

End

Function involsThermalUpdateButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			string ctrlName = ba.ctrlName
			strSwitch(ctrlName)
			
				case "updateThermalNow":
					executeInvolsThermalUpdate(callback="")
					break
				case "updateThermalViewSettings":
					wave vSettings
					wave/t tSettings
					edit vSettings.ld
					edit tSettings.ld
					break
			
			EndSwitch
			
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End
Function involsThermalUpdatePanel([PanelName,WindowName,hostName]) : Panel
	
	String PanelName,WindowName, hostName
		
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(panelName))
		panelName="involsThermalUpdatePanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="involsThermalUpdateWindow"
	EndIf
	
	if (paramIsDefault(hostName))
		NewPanel/W=(0,0,280,700)/N=$PanelName as WindowName
	else
		Variable panelWidth = 280
		Variable panelHeight = 700
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif




	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable involsMaxSamples,pos={9,54},size={154,16},title="Max Samples"
	SetVariable involsMaxSamples,limits={-inf,inf,0},value= vSettings[%maxSamples]
	SetVariable involsMaxTime,pos={9,81},size={154,16},title="Max Thermal Time"
	SetVariable involsMaxTime,limits={-inf,inf,0},value= vSettings[%maxThermalTime]
	TitleBox UITitle,pos={81,11},size={126,24},title="Update Invols",fSize=18
	TitleBox UITitle,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable SaveThermal,pos={9,108},size={99,16},title="Save Thermal"
	SetVariable SaveThermal,limits={0,1,1},value= vSettings[%saveThermal]
	TitleBox Note,pos={8,141},size={243,34},title="Note: For proper use, a thermal must have already\rbeen fit and the \"Amp InvOLS\" must be unlocked"
	SetWindow kwTopWin,hook(thisPanelHook)=cryptidPanelHook
End



Window involsThermalUpdatePanel1() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1493,452,1773,1152) as "involsThermalUpdateWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable involsMaxSamples,pos={9,54},size={154,16},title="Max Samples"
	SetVariable involsMaxSamples,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:involsThermalUpdate_2:vSettings[%maxSamples]
	SetVariable involsMaxTime,pos={9,81},size={154,16},title="Max Thermal Time"
	SetVariable involsMaxTime,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:involsThermalUpdate_2:vSettings[%maxThermalTime]
	TitleBox UITitle,pos={81,11},size={126,24},title="Update Invols",fSize=18
	TitleBox UITitle,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	CheckBox XY_High_Voltage_RelayCheckBox,pos={9,139},size={126,14},proc=involsCheckBoxProc,title="XY High Voltage Relay"
	CheckBox XY_High_Voltage_RelayCheckBox,value= 0
	SetVariable SaveThermal,pos={9,108},size={99,16},title="Save Thermal"
	SetVariable SaveThermal,limits={1,0,1},value= root:Settings:Cryptid:WorkingFolders:involsThermalUpdate_2:vSettings[%saveThermal]
	CheckBox Z_High_Voltage_RelayCheckBox,pos={9,157},size={119,14},proc=involsCheckBoxProc,title="Z High Voltage Relay"
	CheckBox Z_High_Voltage_RelayCheckBox,value= 0
	ToolsGrid snap=1,visible=1
EndMacro
