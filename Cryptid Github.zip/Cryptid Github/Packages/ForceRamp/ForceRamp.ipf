#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1
#include ":Dependencies:SaveAsAsylumForceRamp"

// Version 2.0 notes
// Created new functions for user interfaces with force ramps.  
//
// MakeForceRampPanel(Ramp_Settings,Ramp_WaveNames,[PanelName,WindowName]) 
// Makes a panel with most important settings accessible with a user interface.  
// Just input the settings and wavenames waves into the arguments.  
// You can create as many windows as you like for different force ramp wave settings.  
// You can name the panel with panel name.  
// You can change the window title with windowname
// Going to adapt this for the centering program, the force clamp and make a simple force ramp program that uses the search grid.
// 
// Also created the associated button and checkbox functions with this user interface. 

//BD for integration into Cryptid

//NOTE:
//Just modified everything under //NEW. If this doesn't crash, try eliminating the general stopIn/out banks, and then not clearing the triggers.

Function cryptidExecuteForceRamp()
	
	cryptidDebug()
	cryptidTimer(12)
	wave vSettings
	wave/t tSettings
	
	//Modifying to use an alternate retract velocity for finding a molecule
	wave searchSettings = root:Settings:SearchGrid:SearchSettings
	wave foundCoarseNumber = root:Settings:SearchGrid:foundCoarseNumber
	variable searchingForMolecule = !(foundCoarseNumber[dimsize(foundCoarseNumber,0)-1] == searchSettings[%CoarseSpotNumber])
	
	//Very hacky way to do this but i'm in a rush
	if (searchingForMolecule && (vSettings[%SeachingRetractVelocity] != 0))
		duplicate/O vSettings tempVSettings
		tempVSettings[%'Retract Velocity'] = tempVSettings[%SeachingRetractVelocity]
		wave vSettings = tempVSettings
	endif
	
	if(vSettings[%useTriggerFilter])
		DoForceRampFiltered(vSettings,tSettings,vSettings[%TriggerFilterFreq])
	else
		DoForceRamp(vSettings,tSettings)
	endif

End

// Here's my hack to do the CTFC force ramp, but have the CTFC trigger off a filtered deflection channel.
Function DoForceRampFiltered(RampSettings,WaveNameCallbackSettings,FilterFrequency)
	
	Wave RampSettings
	Wave/T WaveNameCallbackSettings
	Variable FilterFrequency
	cryptidDebug()
	Variable Error=0
	//td_stop()
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])

	Error += td_WS(EventString,"Clear")
	
	SetupForceRamp(RampSettings,WaveNameCallbackSettings,CallBack=WaveNameCallbackSettings[%Callback],TriggerWaveName=WaveNameCallbackSettings[%$"CTFC Settings"])
	SetupForceRampData(RampSettings,DeflectionWaveName=WaveNameCallbackSettings[%Deflection],ZSensorWaveName=WaveNameCallbackSettings[%ZSensor],Filtered=1,tSettings=WaveNameCallbackSettings)
	
	//Dow we need this? It may conflict with OIA code
	// Setup up normal deflection channel on InA with appropriate filter settings
//	Error += td_WS("ARC.Crosspoint.InA", "Defl")	
//	Variable SamplingFilter=Round(RampSettings[%$"Sampling Rate"]/2)
//	Error += td_WV("ARC.Input.A.Filter.Freq", SamplingFilter)

	// Setup up "cloned" deflection channel on InB with the user provided filter frequency
	Error += td_WS("ARC.Crosspoint.InB", "Defl")	
	Error += td_WV("ARC.Input.B.Filter.Freq", FilterFrequency)
	
	// Do the ramp
	ExecuteForceRamp(RampSettings)
End

// This is the normal force ramp function.  No special filtering on cloned channels.
Function DoForceRamp(RampSettings,WaveNameCallbackSettings)
	

	Wave RampSettings
	Wave/T WaveNameCallbackSettings
	cryptidDebug()
	Variable Error=0
	//td_stop()
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])

	Error += td_WS(EventString,"Clear")
	
	SetupForceRamp(RampSettings,WaveNameCallbackSettings,CallBack=WaveNameCallbackSettings[%Callback],TriggerWaveName=WaveNameCallbackSettings[%$"CTFC Settings"])
	SetupForceRampData(RampSettings,DeflectionWaveName=WaveNameCallbackSettings[%Deflection],ZSensorWaveName=WaveNameCallbackSettings[%ZSensor],tSettings=WaveNameCallbackSettings)
	
	ExecuteForceRamp(RampSettings)
End



Function ExecuteForceRamp(RampSettings)
	Wave RampSettings
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])
	
	updateStatus("CTFC: "+num2str(rampSettings[%$"Retract Velocity"]))
	
	//Should make this an option, but force it for now
	//Disable PID loops for clean signal
	if (!RampSettings[%XYPIDLoops])
		ir_StopPISLoop(0)
		ir_StopPISLoop(1)
	endif
	cryptidTimer(13)
	td_WS(EventString,"Once")	

End

Function SetupForceRampData(RampSettings,[tSettings,DeflectionWaveName,ZSensorWaveName,Filtered])

	Wave RampSettings
	Wave/t tSettings
	String DeflectionWaveName,ZSensorWaveName
	Variable Filtered
	cryptidDebug()
	If(ParamIsDefault(ZSensorWaveName))
		ZSensorWaveName="ZSensorVolts"
	EndIf
	If(ParamIsDefault(DeflectionWaveName))
		DeflectionWaveName="DefVolts"
	EndIf
	
	If(ParamIsDefault(Filtered))
		Filtered=0
	EndIf

	// Import Existing CTFC Parms
	Variable SurfaceLocation=td_rv("CTFC.RampTrigger")
	//NEW
	//If one hasn't been run yet, then just guess a reasonable (but too far) value
	if (surfaceLocation == 0)
		surfaceLocation = 100
	endif
	
	Variable CurrentLocation=td_rv("Output.Z")
	Variable DistanceToSurface=Abs((CurrentLocation-SurfaceLocation)*GV("ZPiezoSens"))

	// Figure out the estimated time for the force ramp to complete
	Variable RampTime=DistanceToSurface/RampSettings[%'Approach Velocity']+RampSettings[%'Extension Distance']/RampSettings[%'Retract Velocity']
	RampTime+=RampSettings[%$"Surface Dwell Time"]+RampSettings[%$"Retract Dwell Time"]
	
	//BDedit - Overtime factor added as not enough data was being recorded
	Variable overtimeFactor = 2 //because who cares if the waves are too big?
	RampTime*=overtimeFactor
	
	// Now figure out the decimation factor to give the closest sampling rate possible
	Variable DecimationFactor=Round(50000/RampSettings[%$"Sampling Rate"])
	Variable EffectiveSamplingRate=50000/DecimationFactor
	

	
	// How many points should we make these waves
	Variable NumPoints=Floor(RampTime*EffectiveSamplingRate)
	
	Make/O/N=(NumPoints) $ZSensorWaveName,$DeflectionWaveName
	
	//NEW
	//This accounts for factors of 32, ect...
	Decimationfactor = prepWavesForSC( $ZSensorWaveName,$DeflectionWaveName, effectiveSamplingRate,RampTime)
	
	Wave ZSensor=$ZSensorWaveName
	Wave DefV=$DeflectionWaveName
	
	//ADDED NAN MOST RECENTLY
	FastOp ZSensor=(NAN)
	FastOp DefV=(NAN)
	
	//NEW
	String EventString=num2str(RampSettings[%$"Event Enable"])
	Variable SCaptureBank = RampSettings[%SCaptureBank]
	Variable SCaptureFilterBank = RampSettings[%SCaptureFilterBank]
	
	String deflectionChannel, ZSensorChannel
	if (!ParamIsDefault(tSettings))
		deflectionChannel = tSettings[%DeflectionChannel]
		zSensorChannel = tSettings[%zSensorChannel]
	else
		deflectionChannel = "Deflection"
		zSensorChannel="ZSensor"
	endif
	
	//ASSUMING SCAPTUREBANK IS JUST DEFLECTION HERE
	//Set the filter frequency to 1/2 the capture rate
	variable filterfreq = floor(effectiveSamplingRate/2)
	td_WV("Cypher.Input.FastA.filter.freq",filterfreq)
	
	// If we are using a filtered, cloned deflection channel, setup to sample on the raw channel (A) and Zsensor.  Also save a copy of the filtered channel, just for debugging purposes.
	If(Filtered)
		CryptidDebug(diagString="Setting up filtered channel")
		Duplicate/O DefV, DefVFiltered
		//Changed ARC.Input.A in the SC to "Deflection" so ARC.Input.A is free for other uses
		td_XSetInWavePair(SCaptureBank,EventString,deflectionChannel,DefV,"Cypher.LVDT.Z",ZSensor,"",DecimationFactor)
		td_xSetInWave(SCaptureFilterBank,EventString,"ARC.Input.B",DefVFiltered,"",DecimationFactor)
	Else
		// Otherwise, just use the usual channels
		CryptidDebug(diagString="Setting up normal channel")
		//IR_XSetInWavePair(0,EventString,"Deflection",DefV,"Cypher.LVDT.Z",ZSensor,"",DecimationFactor) //Rob had this (IR_) instead, unsure what this does...
		


		td_XSetInWavePair(SCaptureBank,EventString,deflectionChannel,DefV,zSensorChannel,ZSensor,"",DecimationFactor)
		if (RampSettings[%AlternateTriggerChannel])
			Duplicate/O DefV, altDeflV
			String newChannel = tSettings[%alternateTriggerChannel]
			td_xSetInWave(SCaptureFilterBank,EventString, newChannel,altDeflV,"",DecimationFactor)
		endif
	EndIf

End

Function SetupForceRamp(RampSettings,tSettings[,CallBack,TriggerWaveName])

	wave RampSettings
	String CallBack,TriggerWaveName
	Wave/t tSettings
	
	If(ParamIsDefault(CallBack))
		CallBack="cryptidMain(0)"
	EndIf
	If(ParamIsDefault(TriggerWaveName))
		TriggerWaveName="TriggerInfo"
	EndIf
	
	// Import Existing CTFC Parms
	Make/O/T $TriggerWaveName
	Wave/T TriggerInfo=$TriggerWaveName
	Variable error=0
	error+=td_ReadGroup("ARC.CTFC",TriggerInfo)

	String ErrorStr = ""
	Variable Scale = 1
	String RampChannel = ""
	
	Variable closedLoop = rampSettings[%closedLoop]
	Variable ZSens
	string eventRamp =num2str( RampSettings[%$"Event Ramp"])
	string eventDwell = num2str( RampSettings[%$"Event Dwell"])
	string RampOffset
	

	if (closedLoop)
		Struct ARFeedbackStruct FB
		ARGetFeedbackParms(FB,"outputZ")
		
		FB.StartEvent = eventRamp
		FB.StopEvent = eventDwell
		
		//Lets use ramp 4 to not conflict with anything...
		FB.Bank = 4
		FB.LoopName = "ClosedCTFC"
		
		FB.DontSwapToBackpack = 1	//we need this so the feedback loop won't be on the backpack where we can't do jack
		ErrorStr += ir_WritePIDSloop(FB)
		RampChannel = "ARC.PIDSLoop.4.Setpoint"
		
		ErrorStr += num2str(td_WriteString("Event."+EventDwell,"Clear"))+","
		ErrorStr += num2str(td_WriteString("Event."+EventRamp,"Set"))+","
		
		zSens = GV("ZLVDTSens")
		RampOffset = "160"

	else
		RampChannel = "Output.Z"
		zSens = GV("ZPiezoSens")
		RampOffset = "160"
	endif

	
	
	//  Setting up all the CTFC ramp info here. 
	
	// Calculate Ramp Settings into Voltages for Piezo and Deflection
	Variable SurfaceTrigger = RampSettings[%'Surface Trigger']/GV("InvOLS")/GV("SpringConstant")
	cryptidDebug(diagString="Setting up CTFC, Surface Trigger V = "+num2str(surfaceTrigger))
	Variable MoleculeTrigger = -1*RampSettings[%'Molecule Trigger']/GV("InvOLS")/GV("SpringConstant")
	
	Variable NoTriggerTime = (RampSettings[%'No Trigger Distance'])/((RampSettings[%'Retract Velocity']))
	Variable ExtensionDistance=-RampSettings[%'Extension Distance']/zSens
	Variable ApproachSpeed = (RampSettings[%'Approach Velocity'])/zSens
	Variable RetractSpeed = -1*(RampSettings[%'Retract Velocity'])/zSens


	
	String triggerChannelName = "Deflection"
	
	if (RampSettings[%useTriggerFilter])
		triggerChannelname="Input.B"
	endif
	
	if (RampSettings[%alternateTriggerChannel])
		triggerChannelname=tSettings[%alternateTriggerChannel]
	endif
	
	// He we set up the retracting ramp.  If we are trying to detect a molecule, set ramp to $Deflection
	// If we are just trying to get a full force pull, then use output.Dummy.  This disables the second trigger.
	String RetractTriggerChannel
	If (RampSettings[%'Engage Second Trigger']==1)
		RetractTriggerChannel=triggerChannelName
	Else
		RetractTriggerChannel="output.Dummy"
	EndIf

	TriggerInfo[%RampChannel] = RampChannel
	TriggerInfo[%RampOffset1] = RampOffset
	TriggerInfo[%RampSlope1] = num2str(ApproachSpeed)  //Z Piezo Volts/s

	TriggerInfo[%RampOffset2] = num2str(ExtensionDistance)
	TriggerInfo[%RampSlope2] = num2str(RetractSpeed) 
	
	TriggerInfo[%TriggerChannel1] = triggerChannelName
	TriggerInfo[%TriggerValue1] = num2str(SurfaceTrigger) //Deflection Volts
	TriggerInfo[%TriggerCompare1] = ">="
	
	TriggerInfo[%TriggerChannel2] = RetractTriggerChannel
	TriggerInfo[%TriggerValue2] = num2str(MoleculeTrigger) 
	TriggerInfo[%TriggerCompare2] = "<="
	
	TriggerInfo[%TriggerHoldoff2] = num2str(NoTriggerTime)
	
	TriggerInfo[%DwellTime1] = num2str(RampSettings[%$"Surface Dwell Time"])
	TriggerInfo[%DwellTime2] = num2str(RampSettings[%$"Retract Dwell Time"])
	TriggerInfo[%EventDwell] = num2str(RampSettings[%$"Event Dwell"])

	TriggerInfo[%EventRamp] = num2str(RampSettings[%$"Event Ramp"])

	TriggerInfo[%EventEnable] =num2str(RampSettings[%$"Event Enable"])

	TriggerInfo[%CallBack] = Callback
	
	if (FindDimLabel(TriggerInfo,0,"TriggerType1") >= 0)
		TriggerInfo[%TriggerType1] = "Relative Start"
		TriggerInfo[%TriggerType2] = "Relative Start"
	endif
	String EventDwellString="Event."+num2str(RampSettings[%$"Event Dwell"])
	String EventRampString="Event."+num2str(RampSettings[%$"Event Ramp"])
	ErrorStr += num2str(td_WriteString(EventDwellString,"Clear"))+","
	ErrorStr += num2str(td_WriteString(EventRampString,"Clear"))+","
	
	//EDIT to not clear all banks
	//Changed again, can't clear all
//	ErrorStr += num2str(td_StopInWaveBank(-1))
	ErrorStr += num2str(td_StopInWaveBank(RampSettings[%sCaptureBank]))
	ErrorStr += num2str(td_StopOutWaveBank(-1))
	if (RampSettings[%useTriggerFilter])
		ErrorStr += num2str(td_StopInWaveBank(RampSettings[%sCaptureFilterBank]))
	endif

	ErrorStr += num2str(td_writeGroup("ARC.CTFC",TriggerInfo))+","

	// Setup constant force loop during dwell at surface.  Note: Need a Deflection Offset for the most accurate dwell.
	//I've altered this to do dynamicSetpoint and the option for zSensor dwell
//	SetupDwellFB(RampSettings=RampSettings,inputChannel="ZSensor")
	SetupDwellFB(SetPoint=surfaceTrigger,Offset=getCVar("DeflVOffset"),rampSettings=RampSettings )
	
	//Revized to use dynamic setpoint
	//SetupDwellFB(rampSettings=RampSettings)
	//SetupClampFB(SurfaceTrigger,DeflectionOffset=RampSettings[%DefVOffset],RampSettings=RampSettings)
	
//	ARReportError(ErrorStr)	

End //SetupForceRamp

Function MakeForceRampWave([OutputWaveName])

	String OutputWaveName
	
//	If(ParamIsDefault(OutputWaveName))
//		OutputWaveName="ForceRampSettings"
//	EndIf
	cryptidDebug()
	
	loadCryptidSettings("ForceRamp","vSettings;", useCurrentDF=1)
//	Make/O/N=16 $OutputWaveName
//	Wave ForceRampSettings=$OutputWaveName
	
//	SetDimLabel 0,0, $"Surface Trigger", ForceRampSettings
 //	SetDimLabel 0,1, $"Molecule Trigger", ForceRampSettings
 //	SetDimLabel 0,2, $"Approach Velocity", ForceRampSettings
 //	SetDimLabel 0,3, $"Retract Velocity", ForceRampSettings
 //	SetDimLabel 0,4, $"Surface Dwell Time", ForceRampSettings
  //	SetDimLabel 0,5, $"Retract Dwell Time", ForceRampSettings
   //	SetDimLabel 0,6, $"No Trigger Distance", ForceRampSettings
   // 	SetDimLabel 0,7, $"Engage Second Trigger", ForceRampSettings
 //	SetDimLabel 0,8, $"Extension Distance", ForceRampSettings
 //	SetDimLabel 0,9, $"Event Dwell", ForceRampSettings
 //	SetDimLabel 0,10, $"Event Ramp", ForceRampSettings
 //	SetDimLabel 0,11, $"Event Enable", ForceRampSettings
 //	SetDimLabel 0,12, $"Sampling Rate", ForceRampSettings
 //	SetDimLabel 0,13, $"DefVOffset", ForceRampSettings 
 //	SetDimLabel 0,14, $"UseTriggerFilter", ForceRampSettings 
 //	SetDimLabel 0,15, $"TriggerFilterFreq", ForceRampSettings 

//	ForceRampSettings={100e-12,30e-12,1e-6,1e-6,0,0,50e-9,0,1e-6,5,3,2,1000,0,0,100}
End

Function MakeFRWaveNamesCallback([OutputWaveName])
	String OutputWaveName
	cryptidDebug()
//	If(ParamIsDefault(OutputWaveName))
//		OutputWaveName="FRWaveNamesCallback"
//	EndIf
	loadCryptidSettings("ForceRamp","tSettings;", useCurrentDF=1)	
//	Make/O/T/N=4 $OutputWaveName
//	Wave/T ForceRampSettings=$OutputWaveName
	
//	SetDimLabel 0,0, $"Deflection", ForceRampSettings
 //	SetDimLabel 0,1, $"ZSensor", ForceRampSettings
 //	SetDimLabel 0,2, $"CTFC Settings", ForceRampSettings
 //	SetDimLabel 0,3, $"Callback", ForceRampSettings

//	ForceRampSettings={"DefV","ZSensor","TriggerInfo","FRCallback()"}
End

//BD Cryptid edit
Function FRCallback()

	td_stopinwavebank(-1)

	//All of these should be in the current data folder
	Wave/T TriggerInfo
	Wave/T tSettings
	Wave vSettings
	Wave deflVolts
	Wave zSensorVolts
	variable Error = 0
	
	//If we used closed loop, stop the loop
	//NEED TO ADD CHECK
	ir_StopPIDSLoop(4)
	cryptidTimer(13)
	//NEW
	cleanWavesAfterSC(deflVolts, zSensorVolts)
	cryptidTimer(14)
	//Update graph
	if (vSettings[%useTriggerFilter])
		//Show the filtered one if we're using it for trigger
		Wave DefVFiltered
		updateCryptidGraph(deflVolts=DefVFiltered,zSensorVolts=zSensorVolts)
	elseif(vSettings[%alternateTriggerChannel])
		Wave altDeflV
		updateCryptidGraph(deflVolts=altDeflV,zSensorVolts=zSensorVolts)
	else
		updateCryptidGraph(deflVolts=deflVolts,zSensorVolts=zSensorVolts)
	endif
	cryptidTimer(15)
	//////////////////////////////////////////////Check all desired parameters to see if we save the curve /////////////////////////////////////////////////////////////
	
	variable MoleculeAttached =1 // Default assumption is molecule will attach
	// Check to see if molecule is attached.  If Triggertime2 is greater than 400,000, then molecule did NOT attach
	Error+=td_ReadGroup("ARC.CTFC",TriggerInfo)
	//If we are using a trigger and didn't get one, set moleule attached to 0
	if (vSettings[%'Engage Second Trigger'] )
		if (str2num(TriggerInfo[%TriggerTime2])> 400000)
			MoleculeAttached=0
		endif
		
		//also check Lcs if threshold is selected
		if (vSettings[%useThreshold] && MoleculeAttached == 1)
			
			//If using an alternate trigger channel, switch to that wave instead (using checkDeflVolts from here on out)
			if (!vSettings[%alternateTriggerChannel])
				if(vSettings[%useTriggerFilter])
					Wave checkDeflVolts = defVFiltered
				else
					Wave checkDeflVolts = deflVolts
				endif
				//Variable maxForce = abs(waveMin(DeflVolts)-zeroVolts) * GV("invols") *GV("SpringConstant")
			else
				Wave checkDeflVolts = altdeflV
			endif
			
			//Adding the ability to check the contour length
			Variable minLc = vSettings[%minLc]
			Variable maxLc = vSettings[%maxLc]
			
			variable Lc = approximateLc(zSensorVolts, checkDeflVolts, atTime = str2num(TriggerInfo[%TriggerTime2]))

			if (! ( (Lc > minLc) && (Lc < maxLc) ))
				moleculeAttached = 0
				cryptidDebug(diagString= "Failed LC")
				
				//Need to break tether somehow
				string callback ="cryptidMain(0)"
				td_setRamp(1, "output.z", 0, 0, "", 0, 0, "", 0, 0, callback)
				
				
				return 1
			endif
			
		endif
	//If we are not using a trigger and ARE using a threshold, check it and the Lcs
	elseif(vSettings[%useThreshold])
		
		moleculeAttached=0
		variable zeroVolts = getCVar("deflVOffset")
		
		//If using an alternate trigger channel, switch to that wave instead (using checkDeflVolts from here on out)
		if (!vSettings[%alternateTriggerChannel])
			if(vSettings[%useTriggerFilter])
				Wave checkDeflVolts = defVFiltered
				//New: if filtered, change zero volts to the begining of curve so it uses the filtered signal
				zeroVolts = defVFiltered[0]
			else
				Wave checkDeflVolts = deflVolts
			endif
			//Variable maxForce = abs(waveMin(DeflVolts)-zeroVolts) * GV("invols") *GV("SpringConstant")
		else
			Wave checkDeflVolts = altdeflV
		endif
		
		variable invols = GV("invols")
		variable SC = GV("SpringConstant")

		Variable maxForce = abs(waveMin(checkDeflVolts)-zeroVolts) * invols * SC
		
		if (maxForce > vSettings[%Threshold]) //If the force change is greater than the Molecule Trigger, check the Lcs
			
			//Adding the ability to check the contour length
			minLc = vSettings[%minLc]
			maxLc = vSettings[%maxLc]
			
			Lc = approximateLc(zSensorVolts, checkDeflVolts)
			variable LcThresh = vSettings[%'No Trigger Distance']

			if ( (Lc > minLc) && (Lc < maxLc))
				moleculeAttached = 1
			endif
			
		endif
	
	endif
 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	cryptidTimer(16)
	if (moleculeAttached)
		updateStatus("Molecule found!")
		string params = "ZeroVoltage;RetractVelocity"
		string values = num2str(vSettings[%DefVOffset])+";"+num2str(vSettings[%'Retract Velocity'])+";"
		writeToStdOut(params,values)
		
		//Temp save the alternate as well
		if (vSettings[%alternateTriggerChannel])
			string saveName = getCurrentStepName()+"ALT"+"_"
			cryptidSaveWaves(altdeflV,ZSensorVolts,FC=0,saveName=saveName)

		endif
		
		//ADD OPTION TO NOT SAVE WAVES!!!!!
		cryptidMain(1, deflVolts=DeflVolts,zSensorVolts=zSensorVolts)
	else
		updateStatus("No Molecule")
		cryptidMain(0)
	endif

End


//Calculate approximate contour length at the given time (default to max rupture force
Function approximateLc(zSensorVolts, deflVolts, [atTime])

	Wave zSensorVolts, deflVolts
	variable atTime

	if (paramIsDefault(atTime))
		//Get min deflVolts time
		waveStats/Q deflVolts
		atTime = v_minLoc
	endif
	
	//Get the maximum zSensor time, assume this to be zero Lc
	waveStats/Q zSensorVolts
	variable maxZTime = v_maxLoc
	
	//Get the zSensor difference in nm
	variable ZLVDTSens = GV("ZLVDTSens")
	variable zSensorDelta = abs(zSensorVolts(atTime) - zSensorVolts(maxZTime)) * ZLVDTSens

	//Get the difference in tip deflection distance in nm (should be negative if molecule rupture force > indent force
	variable deflDelta = ( deflVolts(atTime) - deflVolts(maxZTime) ) * GV("Invols")
	
	Variable Lc = zSensorDelta + DeflDelta
	
	return Lc

End


// GrabExistingCTFCparms imports the existing CTFC parameter group.  Makes it easier to write CTFC parameters without errors
Function ImportExistingCTFCparms([OutputWaveName])
	String OutputWaveName
	cryptidDebug()
	If(ParamIsDefault(OutputWaveName))
		OutputWaveName="TriggerInfo"
	EndIf

	Make/O/T $OutputWaveName
	Wave TriggerInfo=$OutputWaveName
	Variable error=0
	
	error+=td_ReadGroup("ARC.CTFC",TriggerInfo)
	
	return error

End //ImportExistingCTFCparms()

Function SetupDwellFB([SetPoint,Offset,RampSettings,inputChannel])
	
	Variable SetPoint,Offset
	Wave RampSettings
	String inputChannel
	Variable Error=0
	Variable StartEvent,StopEvent
	
	string fullVersion = versionString()
	string mainVersionNumber = fullVersion[0,1]
	


//	print "Setpoint: "+num2str(setPoint)
//	print "Offset: "+num2str(offset)
	
	if(paramIsDefault(inputChannel))
		inputChannel="Deflection"
	endif
	
	cryptidDebug()
	
	If(ParamIsDefault(Offset))
		Offset=0
	EndIf
	If(ParamIsDefault(RampSettings))
		StartEvent=5
		StopEvent=3
	Else
		StartEvent=RampSettings[%'Event Dwell']
		StopEvent=RampSettings[%'Event Ramp']
	EndIf
	
	//Honestly, I gave up trying to figure out what was going wrong here and just copied the old code from v14...
	if (stringMatch(mainVersionNumber, "14"))
		Make/O/T PIDSLoopGroup
		Error+=td_RG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		//Added to enable dynamic setpoint for CTFC
		if (paramIsDefault(setPoint))
			PIDSLoopGroup[%DynamicSetpoint] = "Yes"
		else
			PIDSLoopGroup[%DynamicSetpoint] ="No"
			PIDSLoopGroup[%Setpoint]=num2str(SetPoint)
			PIDSLoopGroup[%SetpointOffset]=num2str(Offset)
		Endif
		
		//THIS WILL NEED TO BE CHANGED TO WORK IN 16. USE SETPISLOOP
		
		PIDSLoopGroup[%InputChannel]=inputChannel
		PIDSLoopGroup[%OutputChannel]="Output.Z"
		PIDSLoopGroup[%IGain]="3000"
		PIDSLoopGroup[%StartEvent]=num2str(StartEvent)
		PIDSLoopGroup[%StopEvent]=num2str(StopEvent)
		PIDSLoopGroup[%OutputMin]="-10"
		PIDSLoopGroup[%OutputMax]="150"
		PIDSLoopGroup[%Status]="0"
		
		Error=0
		Error+=td_WG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		If(Error>0)
			cryptidDebug(diagString="Error code in SetupDwellFB: "+ num2str(Error), alwaysPrint=1)
		EndIf
	else
	
		Make/O/T PIDSLoopGroup
		Error+=td_RG("ARC.PIDSLoop.2",PIDSLoopGroup)
		
		Variable dynamicSetpoint
		//Added to enable dynamic setpoint for CTFC
		if (paramIsDefault(setPoint))
			dynamicSetpoint=1
		else
			dynamicSetpoint=0
		Endif
		
		//THIS WILL NEED TO BE CHANGED TO WORK IN 16. USE SETPISLOOP
	//	print setpoint
		Variable pGain = str2num(PIDSLoopGroup[%pGain])
		Variable sGain = str2num(PIDSLoopGroup[%sGain])
		//START HERE
		
		cryptidDebug(DiagString="Settings PISLoop for CTFC...")
		vs_SetPISLoop(2,num2str(StartEvent)+","+num2str(StopEvent),InputChannel,setPoint,pGain, 3000, sGain,"Output.Z",-10,150,dynamicSetpoint=dynamicSetpoint,setPointOffset=offset)		
		
		
	//	PIDSLoopGroup[%InputChannel]=inputChannel
	//	PIDSLoopGroup[%OutputChannel]="Output.Z"
	//	PIDSLoopGroup[%IGain]="3000"
	//	PIDSLoopGroup[%StartEvent]=num2str(StartEvent)
	//	PIDSLoopGroup[%StopEvent]=num2str(StopEvent)
	//	PIDSLoopGroup[%OutputMin]="-10"
	//	PIDSLoopGroup[%OutputMax]="150"
	//	PIDSLoopGroup[%Status]="0"
		
		Error=0
	//	Error+=td_WG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		If(Error>0)
			cryptidDebug(diagString="Error code in SetupDwellFB: "+ num2str(Error), alwaysPrint=1)
		EndIf
	endif
End





Function FRButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			String ButtonName=ba.ctrlName
			String SettingsWaveName=StringByKey("RampSettings", ba.userdata, "=")
			Wave SettingsWave=$SettingsWaveName
			String SettingsStrWaveName=StringByKey("RampSettingsStr", ba.userdata, "=")
			Wave/T SettingsStrWave=$SettingsStrWaveName

			Strswitch(ButtonName)
				case "SingleForceButton":
				
					//Set cryptid stop
					//wave vSettings = getCryptidSettings(0)
					//vSettings[%stop] = 1
					
					cryptidMain(3)

				break
				case "ViewWavesButton":
					Edit/K=1/W=(5.25,42.5,253.5,360.5) SettingsWave.ld
					Edit/K=1/W=(5.25,389,253.5,510.5) SettingsStrWave.ld
				break
				case "ViewLiveCurves":
					
					Display/N=Monitor root:MonitorV vs root:MonitorZ
				break
			EndSwitch
		
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function MakeForceRampPanel([PanelName,WindowName,hostName]) : Panel

	String PanelName,WindowName, hostName
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(WindowName))
		WindowName="ForceRamp"
	EndIf
	If(ParamIsDefault(PanelName))
		PanelName="ForceRamp"
	EndIf
	
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	//String WaveNameList="RampSettings="+GetWavesDataFolder(vSettings,2)+";RampSettingsStr="+GetWavesDataFolder(tSettings,2)+";"
	//String WaveNameList="RampSettings="+"vSettings"+";RampSettingsStr="+"tSettings"+";"
	
	PauseUpdate; Silent 1		// building window...
	
	//If no hostname, make as independent window
	if (paramIsDefault(hostName))
		NewPanel/K=1/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	

	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={9,54},size={207,16},title="Surface Trigger"
	SetVariable SurfaceTrigger1,format="%.1W1PN"
	SetVariable SurfaceTrigger1,limits={-inf,inf,1e-11},value= vSettings[%'Surface Trigger']
	SetVariable ForceDistanceIFR,pos={9,76},size={207,16},title="Force Distance"
	SetVariable ForceDistanceIFR,format="%.1W1Pm"
	SetVariable ForceDistanceIFR,limits={-inf,inf,1e-07},value= vSettings[%'Extension Distance']
	SetVariable ApproachVelocity1,pos={9,99},size={207,16},title="Approach Velocity"
	SetVariable ApproachVelocity1,format="%.1W1Pm/s"
	SetVariable ApproachVelocity1,limits={-inf,inf,1e-07},value= vSettings[%'Approach Velocity']
	SetVariable RetractVelocity1,pos={9,122},size={144,16},title="Ret. Velocity"
	SetVariable RetractVelocity1,format="%.1W1Pm/s"
	SetVariable RetractVelocity1,limits={-inf,inf,1e-07},value= vSettings[%'Retract Velocity']
	SetVariable DwellTime1,pos={9,144},size={207,16},title="Surface Dwell Time"
	SetVariable DwellTime1,format="%.1W1Ps"
	SetVariable DwellTime1,limits={-inf,inf,0.5},value= vSettings[%'Surface Dwell Time']
	SetVariable SamplingRateIFR,pos={9,167},size={207,16},title="Sample Rate"
	SetVariable SamplingRateIFR,format="%.1W1PHz"
	SetVariable SamplingRateIFR,value= vSettings[%'Sampling Rate']
	SetVariable FRDeflectionChannel,pos={9,191},size={207,16},title="Deflection Recording"
	SetVariable FRDeflectionChannel,value= tSettings[%deflectionChannel]
	SetVariable MoleculeTrigger1,pos={45,288},size={225,16},title="Molecule Trigger"
	SetVariable MoleculeTrigger1,format="%.1W1PN"
	SetVariable MoleculeTrigger1,limits={-inf,inf,5e-12},value= vSettings[%'Molecule Trigger']
	SetVariable NoTriggerDistance1,pos={45,306},size={225,16},title="No Trigger Distance"
	SetVariable NoTriggerDistance1,help={"Distance to move from the surface before checking for a trigger"}
	SetVariable NoTriggerDistance1,format="%.1W1Pm"
	SetVariable NoTriggerDistance1,limits={-inf,inf,1e-08},value= vSettings[%'No Trigger Distance']
	SetVariable FilterFreqSV,pos={45,380},size={224,16},title="Filter Frequency"
	SetVariable FilterFreqSV,help={"Trigger off a filtered channel. Uses inFast.B, so shouldn't be used if that causes conflicts"}
	SetVariable FilterFreqSV,format="%.1W1PHz"
	SetVariable FilterFreqSV,value= vSettings[%TriggerFilterFreq]
	Button SingleForceButton,pos={7,432},size={74,22},proc=FRButtonProc,title="Single Force"
	Button SingleForceButton,userdata=  "RampSettings=vSettings;RampSettingsStr=tSettings;"
	Button SingleForceButton,fColor=(61440,61440,61440)
	TitleBox MoleculeTrigger_TB,pos={9,256},size={128,21},title="Molecule Trigger Settings"
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	TitleBox ForceRampTitle,pos={89,11},size={115,24},title="Force Ramp",fSize=18
	TitleBox ForceRampTitle,frame=0,fStyle=1
	SetVariable FREventEnable,pos={10,514},size={207,16},title="Event Enable"
	SetVariable FREventEnable,value= vSettings[%'Event Enable']
	SetVariable FREventDwell,pos={10,536},size={206,16},title="Event Dwell"
	SetVariable FREventDwell,value= vSettings[%'Event Dwell']
	SetVariable FREventRamp,pos={10,558},size={206,16},title="Event Ramp"
	SetVariable FREventRamp,value= vSettings[%'Event Ramp']
	SetVariable FRSCBank,pos={10,594},size={206,16},title="Standard Capture Bank"
	SetVariable FRSCBank,value= vSettings[%SCaptureBank]
	SetVariable FRFilteredCBank,pos={10,617},size={206,16},title="Filtered Capture Bank"
	SetVariable FRFilteredCBank,value= vSettings[%SCaptureFilterBank]
	SetVariable FRZSensorChannel,pos={9,211},size={207,16},title="ZSensor Recording"
	SetVariable FRZSensorChannel,value= tSettings[%zSensorChannel]
	SetVariable FilterFreqSV1,pos={45,398},size={225,16},title="Alt. Trigger Channel"
	SetVariable FilterFreqSV1,help={"Trigger off of a channel other than deflection"}
	SetVariable FilterFreqSV1,limits={-inf,inf,0},value= tSettings[%AlternateTriggerChannel]
	SetVariable MinimumLc,pos={45,353},size={108,16},title="Min Lc"
	SetVariable MinimumLc,help={"Minimum approximate contour length to accept"}
	SetVariable MinimumLc,format="%.1W1Pm"
	SetVariable MinimumLc,limits={-inf,inf,1e-08},value= vSettings[%minLc]
	SetVariable MaximumLc,pos={162,353},size={108,16},title="Max Lc"
	SetVariable MaximumLc,help={"Maximum approximate contour length to accept"}
	SetVariable MaximumLc,format="%.1W1Pm"
	SetVariable MaximumLc,limits={-inf,inf,1e-08},value= vSettings[%maxLc]
	SetVariable MoleculeTrigger,pos={9,288},size={28,16},title=" "
	SetVariable MoleculeTrigger,limits={0,1,1},value= vSettings[%'Engage Second Trigger']
	SetVariable FilterFrequency,pos={9,380},size={28,16},title=" "
	SetVariable FilterFrequency,limits={0,1,1},value= vSettings[%UseTriggerFilter]
	SetVariable AlternateTriggerChannel,pos={9,398},size={28,16},title=" "
	SetVariable AlternateTriggerChannel,limits={0,1,1},value= vSettings[%AlternateTriggerChannel]
	SetVariable Threshold,pos={45,333},size={225,16},title="Threshold"
	SetVariable Threshold,help={"Checked after the curve is taken to ensure a designated force was reached"}
	SetVariable Threshold,format="%.1W1PN"
	SetVariable Threshold,limits={-inf,inf,5e-12},value= vSettings[%Threshold]
	SetVariable MoleculeTrigger3,pos={9,333},size={28,16},title=" "
	SetVariable MoleculeTrigger3,limits={0,1,1},value= vSettings[%useThreshold]
	SetVariable ClosedLoop,pos={9,234},size={117,16},title="Closed Loop"
	SetVariable ClosedLoop,help={"Run the ramp in closed loop. Technically higher noise but maintains a consistant pulling velocity"}
	SetVariable ClosedLoop,limits={0,1,1},value= vSettings[%closedLoop]
	SetVariable XYPIDLoops1,pos={153,234},size={117,16},title="XY PID Loops"
	SetVariable XYPIDLoops1,help={"Turns on the XY PID loops to ensure reduce lateral drift during the measurement"}
	SetVariable XYPIDLoops1,limits={0,1,1},value= vSettings[%XYPIDLoops]
	SetVariable searchVelocity,pos={153,122},size={117,16},title="Search"
	SetVariable searchVelocity,help={"Special retract velocity to use when a molecule isn't found. Helps when running a DFS including slow RVs, so you don't get \"stuck\" in those slower velocities when looking for a new molecule. Leave at 0 to never change "}
	SetVariable searchVelocity,format="%.1W1Pm/s"
	SetVariable searchVelocity,limits={-inf,inf,1e-07},value= vSettings[%SeachingRetractVelocity]
	ToolsGrid snap=1,visible=1
	SetWindow kwTopWin,hook(thisPanelHook)=cryptidPanelHook
End


Function FRCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			String CheckBoxName=cba.ctrlName
			String SettingsWaveName=StringByKey("RampSettings", cba.userdata, "=")
			Strswitch(CheckBoxName)
				case "MoleculeTrigger_CB":
					If(WaveExists($SettingsWaveName))
						Wave SettingsWave=$SettingsWaveName
						SettingsWave[%$"Engage Second Trigger"]=Checked
					Endif
				break
				case "FilteredTrigger_CB":
					If(WaveExists($SettingsWaveName))
						Wave SettingsWave=$SettingsWaveName
						SettingsWave[%$"UseTriggerFilter"]=Checked
					EndIF
				break
				Default:
					Wave SettingsWave=vSettings
					SettingsWave[%$CheckBoxName] = checked
				Break
			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function testCTFCInput()

	Make/O/T TestCTFCinputWave
	td_ReadGroup("ARC.CTFC",TestCTFCinputWave)
	
	edit TestCTFCInputWave.ld

End

