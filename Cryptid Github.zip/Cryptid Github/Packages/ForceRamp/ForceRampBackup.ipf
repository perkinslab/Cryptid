#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1
#include ":Dependencies:SaveAsAsylumForceRamp"

// Version 2.0 notes
// Created new functions for user interfaces with force ramps.  
//
// MakeForceRampPanel(Ramp_Settings,Ramp_WaveNames,[PanelName,WindowName]) 
// Makes a panel with most important settings accessible with a user interface.  
// Just input the settings and wavenames waves into the arguments.  
// You can create as many windows as you like for different force ramp wave settings.  
// You can name the panel with panel name.  
// You can change the window title with windowname
// Going to adapt this for the centering program, the force clamp and make a simple force ramp program that uses the search grid.
// 
// Also created the associated button and checkbox functions with this user interface. 

//BD for integration into Cryptid

//NOTE:
//Just modified everything under //NEW. If this doesn't crash, try eliminating the general stopIn/out banks, and then not clearing the triggers.

Function cryptidExecuteForceRamp()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	if(vSettings[%useTriggerFilter])
		DoForceRampFiltered(vSettings,tSettings,vSettings[%TriggerFilterFreq])
	else
		DoForceRamp(vSettings,tSettings)
	endif

End

// Here's my hack to do the CTFC force ramp, but have the CTFC trigger off a filtered deflection channel.
Function DoForceRampFiltered(RampSettings,WaveNameCallbackSettings,FilterFrequency)
	
	Wave RampSettings
	Wave/T WaveNameCallbackSettings
	Variable FilterFrequency
	cryptidDebug()
	Variable Error=0
	//td_stop()
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])

	Error += td_WS(EventString,"Clear")
	
	SetupForceRamp(RampSettings,CallBack=WaveNameCallbackSettings[%Callback],TriggerWaveName=WaveNameCallbackSettings[%$"CTFC Settings"])
	SetupForceRampData(RampSettings,DeflectionWaveName=WaveNameCallbackSettings[%Deflection],ZSensorWaveName=WaveNameCallbackSettings[%ZSensor],Filtered=1,tSettings=WaveNameCallbackSettings)
	
	// Setup up normal deflection channel on InA with appropriate filter settings
	Error += td_WS("ARC.Crosspoint.InA", "Defl")	
	Variable SamplingFilter=Round(RampSettings[%$"Sampling Rate"]/2)
	Error += td_WV("ARC.Input.A.Filter.Freq", SamplingFilter)
	
	// Setup up "cloned" deflection channel on InB with the user provided filter frequency
	Error += td_WS("ARC.Crosspoint.InB", "Defl")	
	Error += td_WV("ARC.Input.B.Filter.Freq", FilterFrequency)
	
	Wave/T CTFCWave= $WaveNameCallbackSettings[%$"CTFC Settings"]
	CTFCWave[%TriggerChannel1] = "Input.B"
	
	// Here we just set the "molecule trigger" to Input.B if we are using it.
	If (RampSettings[%'Engage Second Trigger']==1)
		CTFCWave[%TriggerChannel2]="Input.B"
	Else
		CTFCWave[%TriggerChannel2]="output.Dummy"
	EndIf

	// Copy the new settings to the CTFC
	Error += td_writeGroup("ARC.CTFC",CTFCWave)
	
	// Do the ramp
	ExecuteForceRamp(RampSettings)
End

// This is the normal force ramp function.  No special filtering on cloned channels.
Function DoForceRamp(RampSettings,WaveNameCallbackSettings)
	

	Wave RampSettings
	Wave/T WaveNameCallbackSettings
	cryptidDebug()
	Variable Error=0
	//td_stop()
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])

	Error += td_WS(EventString,"Clear")
	
	SetupForceRamp(RampSettings,CallBack=WaveNameCallbackSettings[%Callback],TriggerWaveName=WaveNameCallbackSettings[%$"CTFC Settings"])
	SetupForceRampData(RampSettings,DeflectionWaveName=WaveNameCallbackSettings[%Deflection],ZSensorWaveName=WaveNameCallbackSettings[%ZSensor],tSettings=WaveNameCallbackSettings)
	
	ExecuteForceRamp(RampSettings)
End



Function ExecuteForceRamp(RampSettings)
	Wave RampSettings
	String EventString="Event."+num2str(RampSettings[%$"Event Enable"])
	
	updateStatus("Triggering CTFC...")
	
	td_WS(EventString,"Once")	

End

Function SetupForceRampData(RampSettings,[tSettings,DeflectionWaveName,ZSensorWaveName,Filtered])

	Wave RampSettings
	Wave/t tSettings
	String DeflectionWaveName,ZSensorWaveName
	Variable Filtered
	cryptidDebug()
	If(ParamIsDefault(ZSensorWaveName))
		ZSensorWaveName="ZSensorVolts"
	EndIf
	If(ParamIsDefault(DeflectionWaveName))
		DeflectionWaveName="DefVolts"
	EndIf
	
	If(ParamIsDefault(Filtered))
		Filtered=0
	EndIf



	// Import Existing CTFC Parms
	Variable SurfaceLocation=td_rv("CTFC.RampTrigger")
	//NEW
	//If one hasn't been run yet, then just guess a reasonable (but too far) value
	if (surfaceLocation == 0)
		surfaceLocation = 100
	endif
	
	Variable CurrentLocation=td_rv("Output.Z")
	Variable DistanceToSurface=Abs((CurrentLocation-SurfaceLocation)*GV("ZPiezoSens"))

	// Figure out the estimated time for the force ramp to complete
	Variable RampTime=DistanceToSurface/RampSettings[%'Approach Velocity']+RampSettings[%'Extension Distance']/RampSettings[%'Retract Velocity']
	RampTime+=RampSettings[%$"Surface Dwell Time"]+RampSettings[%$"Retract Dwell Time"]
	
	//BDedit - Overtime factor added as not enough data was being recorded
	Variable overtimeFactor = 2 //because who cares if the waves are too big?
	RampTime*=overtimeFactor
	
	// Now figure out the decimation factor to give the closest sampling rate possible
	Variable DecimationFactor=Round(50000/RampSettings[%$"Sampling Rate"])
	Variable EffectiveSamplingRate=50000/DecimationFactor
	
	// How many points should we make these waves
	Variable NumPoints=Floor(RampTime*EffectiveSamplingRate)
	
	Make/O/N=(NumPoints) $ZSensorWaveName,$DeflectionWaveName
	
	//NEW
	//This accounts for factors of 32, ect...
	Decimationfactor = prepWavesForSC( $ZSensorWaveName,$DeflectionWaveName, effectiveSamplingRate,RampTime)
	
	Wave ZSensor=$ZSensorWaveName
	Wave DefV=$DeflectionWaveName
	
	//ADDED NAN MOST RECENTLY
	FastOp ZSensor=(NAN)
	FastOp DefV=(NAN)
	
	//NEW
	String EventString=num2str(RampSettings[%$"Event Enable"])
	Variable SCaptureBank = RampSettings[%SCaptureBank]
	Variable SCaptureFilterBank = RampSettings[%SCaptureFilterBank]
	
	String deflectionChannel, ZSensorChannel
	if (!ParamIsDefault(tSettings))
		deflectionChannel = tSettings[%DeflectionChannel]
		zSensorChannel = tSettings[%zSensorChannel]
	else
		deflectionChannel = "Deflection"
		zSensorChannel="ZSensor"
	endif
	
	// If we are using a filtered, cloned deflection channel, setup to sample on the raw channel (A) and Zsensor.  Also save a copy of the filtered channel, just for debugging purposes.
	If(Filtered)
		Duplicate/O DefV, DefVFiltered
		td_XSetInWavePair(SCaptureBank,EventString,"ARC.Input.A",DefV,"Cypher.LVDT.Z",ZSensor,"",DecimationFactor)
		td_xSetInWave(SCaptureFilterBank,EventString,"ARC.Input.B",DefVFiltered,"",DecimationFactor)
	Else
		// Otherwise, just use the usual channels
		//IR_XSetInWavePair(0,EventString,"Deflection",DefV,"Cypher.LVDT.Z",ZSensor,"",DecimationFactor) //Rob had this (IR_) instead, unsure what this does...
		td_XSetInWavePair(SCaptureBank,EventString,deflectionChannel,DefV,zSensorChannel,ZSensor,"",DecimationFactor)
	EndIf

End

Function SetupForceRamp(RampSettings[,CallBack,TriggerWaveName])

	wave RampSettings
	String CallBack,TriggerWaveName
	
	If(ParamIsDefault(CallBack))
		CallBack="cryptidMain(0)"
	EndIf
	If(ParamIsDefault(TriggerWaveName))
		TriggerWaveName="TriggerInfo"
	EndIf
	
	// Import Existing CTFC Parms
	Make/O/T $TriggerWaveName
	Wave/T TriggerInfo=$TriggerWaveName
	Variable error=0
	error+=td_ReadGroup("ARC.CTFC",TriggerInfo)

	String ErrorStr = ""
	Variable Scale = 1
	String RampChannel = ""

	// Calculate Ramp Settings into Voltages for Piezo and Deflection
	Variable SurfaceTrigger = RampSettings[%'Surface Trigger']/GV("InvOLS")/GV("SpringConstant")
	cryptidDebug(diagString="Setting up CTFC, Surface Trigger V = "+num2str(surfaceTrigger))
	Variable MoleculeTrigger = -1*RampSettings[%'Molecule Trigger']/GV("InvOLS")/GV("SpringConstant")
	Variable ApproachSpeed = (RampSettings[%'Approach Velocity'])/GV("ZPiezoSens")
	Variable RetractSpeed = -1*(RampSettings[%'Retract Velocity'])/GV("ZPiezoSens")
	Variable NoTriggerTime = (RampSettings[%'No Trigger Distance'])/((RampSettings[%'Retract Velocity']))
	Variable ExtensionDistance=-RampSettings[%'Extension Distance']/GV("ZPiezoSens")
	
	// He we set up the retracting ramp.  If we are trying to detect a molecule, set ramp to $Deflection
	// If we are just trying to get a full force pull, then use output.Dummy.  This disables the second trigger.
	String RetractTriggerChannel
	If (RampSettings[%'Engage Second Trigger']==1)
		RetractTriggerChannel="Deflection"
	Else
		RetractTriggerChannel="output.Dummy"
	EndIf
	
	//  Setting up all the CTFC ramp info here. 
	RampChannel = "Output.Z"

	TriggerInfo[%RampChannel] = RampChannel
	TriggerInfo[%RampOffset1] = "160"  //Z Piezo volts
	TriggerInfo[%RampSlope1] = num2str(ApproachSpeed)  //Z Piezo Volts/s

	TriggerInfo[%RampOffset2] = num2str(ExtensionDistance)
	TriggerInfo[%RampSlope2] = num2str(RetractSpeed) 
	
	TriggerInfo[%TriggerChannel1] = "Deflection"
	TriggerInfo[%TriggerValue1] = num2str(SurfaceTrigger) //Deflection Volts
	TriggerInfo[%TriggerCompare1] = ">="
	
	TriggerInfo[%TriggerChannel2] = RetractTriggerChannel
	TriggerInfo[%TriggerValue2] = num2str(MoleculeTrigger) 
	TriggerInfo[%TriggerCompare2] = "<="
	
	TriggerInfo[%TriggerHoldoff2] = num2str(NoTriggerTime)
	
	TriggerInfo[%DwellTime1] = num2str(RampSettings[%$"Surface Dwell Time"])
	TriggerInfo[%DwellTime2] = num2str(RampSettings[%$"Retract Dwell Time"])
	TriggerInfo[%EventDwell] = num2str(RampSettings[%$"Event Dwell"])

	TriggerInfo[%EventRamp] = num2str(RampSettings[%$"Event Ramp"])

	TriggerInfo[%EventEnable] =num2str(RampSettings[%$"Event Enable"])

	TriggerInfo[%CallBack] = Callback
	
	if (FindDimLabel(TriggerInfo,0,"TriggerType1") >= 0)
		TriggerInfo[%TriggerType1] = "Relative Start"
		TriggerInfo[%TriggerType2] = "Relative Start"
	endif
	String EventDwellString="Event."+num2str(RampSettings[%$"Event Dwell"])
	String EventRampString="Event."+num2str(RampSettings[%$"Event Ramp"])
	ErrorStr += num2str(td_WriteString(EventDwellString,"Clear"))+","
	ErrorStr += num2str(td_WriteString(EventRampString,"Clear"))+","
	
	//EDIT to not clear all banks
	//Changed again, can't clear all
//	ErrorStr += num2str(td_StopInWaveBank(-1))
	ErrorStr += num2str(td_StopInWaveBank(RampSettings[%sCaptureBank]))
	ErrorStr += num2str(td_StopOutWaveBank(-1))
	if (RampSettings[%useTriggerFilter])
		ErrorStr += num2str(td_StopInWaveBank(RampSettings[%sCaptureFilterBank]))
	endif


	ErrorStr += num2str(td_writeGroup("ARC.CTFC",TriggerInfo))+","

	// Setup constant force loop during dwell at surface.  Note: Need a Deflection Offset for the most accurate dwell.
	//I've altered this to do dynamicSetpoint and the option for zSensor dwell
//	SetupDwellFB(RampSettings=RampSettings,inputChannel="ZSensor")
	SetupDwellFB(SetPoint=surfaceTrigger,Offset=getCVar("DeflVOffset"),rampSettings=RampSettings)
	//SetupClampFB(SurfaceTrigger,DeflectionOffset=RampSettings[%DefVOffset],RampSettings=RampSettings)
	
//	ARReportError(ErrorStr)	

End //SetupForceRamp

Function MakeForceRampWave([OutputWaveName])

	String OutputWaveName
	
//	If(ParamIsDefault(OutputWaveName))
//		OutputWaveName="ForceRampSettings"
//	EndIf
	cryptidDebug()
	
	loadCryptidSettings("ForceRamp","vSettings;", useCurrentDF=1)
//	Make/O/N=16 $OutputWaveName
//	Wave ForceRampSettings=$OutputWaveName
	
//	SetDimLabel 0,0, $"Surface Trigger", ForceRampSettings
 //	SetDimLabel 0,1, $"Molecule Trigger", ForceRampSettings
 //	SetDimLabel 0,2, $"Approach Velocity", ForceRampSettings
 //	SetDimLabel 0,3, $"Retract Velocity", ForceRampSettings
 //	SetDimLabel 0,4, $"Surface Dwell Time", ForceRampSettings
  //	SetDimLabel 0,5, $"Retract Dwell Time", ForceRampSettings
   //	SetDimLabel 0,6, $"No Trigger Distance", ForceRampSettings
   // 	SetDimLabel 0,7, $"Engage Second Trigger", ForceRampSettings
 //	SetDimLabel 0,8, $"Extension Distance", ForceRampSettings
 //	SetDimLabel 0,9, $"Event Dwell", ForceRampSettings
 //	SetDimLabel 0,10, $"Event Ramp", ForceRampSettings
 //	SetDimLabel 0,11, $"Event Enable", ForceRampSettings
 //	SetDimLabel 0,12, $"Sampling Rate", ForceRampSettings
 //	SetDimLabel 0,13, $"DefVOffset", ForceRampSettings 
 //	SetDimLabel 0,14, $"UseTriggerFilter", ForceRampSettings 
 //	SetDimLabel 0,15, $"TriggerFilterFreq", ForceRampSettings 

//	ForceRampSettings={100e-12,30e-12,1e-6,1e-6,0,0,50e-9,0,1e-6,5,3,2,1000,0,0,100}
End

Function MakeFRWaveNamesCallback([OutputWaveName])
	String OutputWaveName
	cryptidDebug()
//	If(ParamIsDefault(OutputWaveName))
//		OutputWaveName="FRWaveNamesCallback"
//	EndIf
	loadCryptidSettings("ForceRamp","tSettings;", useCurrentDF=1)	
//	Make/O/T/N=4 $OutputWaveName
//	Wave/T ForceRampSettings=$OutputWaveName
	
//	SetDimLabel 0,0, $"Deflection", ForceRampSettings
 //	SetDimLabel 0,1, $"ZSensor", ForceRampSettings
 //	SetDimLabel 0,2, $"CTFC Settings", ForceRampSettings
 //	SetDimLabel 0,3, $"Callback", ForceRampSettings

//	ForceRampSettings={"DefV","ZSensor","TriggerInfo","FRCallback()"}
End

//BD Cryptid edit
Function FRCallback()

	td_stopinwavebank(-1)
	
	//All of these should be in the current data folder
	Wave/T TriggerInfo
	Wave/T tSettings
	Wave vSettings
	Wave deflVolts
	Wave zSensorVolts
	variable Error = 0
	variable MoleculeAttached =1 // Default assumption is molecule will attach
	
	//NEW
	cleanWavesAfterSC(deflVolts, zSensorVolts)
	
	//Update graph
	updateCryptidGraph(deflVolts=deflVolts,zSensorVolts=zSensorVolts)
	
	// Check to see if molecule is attached.  If Triggertime2 is greater than 400,000, then molecule did NOT attach
	Error+=td_ReadGroup("ARC.CTFC",TriggerInfo)
	if (str2num(TriggerInfo[%TriggerTime2])> 400000)
		MoleculeAttached=0
	endif
	
	//BD EDIT If "Molecule Trigger? is no, use the trigger force as a minumum force for saving and found molecule purposes
	//THIS IS COMING OUT NEGATIVE? REWRITE!!!!!
	if (!vSettings[%'Engage Second Trigger'] )
		
		variable zeroVolts = getCVar("deflVOffset")
		
		Variable maxForce = abs(waveMin(DeflVolts)-zeroVolts) * GV("invols") *GV("SpringConstant")
		
		if (maxForce > vSettings[%'Molecule Trigger']) //If the force change is greater than the Molecule Trigger, change to molecule attached
			MoleculeAttached = 1
		endif
	
	endif
	
	//BEGIN ALTERATIONS FOR CRYPTID
	if (moleculeAttached)
		updateStatus("Molecule found!")
		string params = "ZeroVoltage;RetractVelocity"
		string values = num2str(vSettings[%DefVOffset])+";"+num2str(vSettings[%'Retract Velocity'])+";"
		writeToStdOut(params,values)
		cryptidMain(1, deflVolts=DeflVolts,zSensorVolts=zSensorVolts)
	else
		updateStatus("No Molecule")
		cryptidMain(0)
	endif

End


// GrabExistingCTFCparms imports the existing CTFC parameter group.  Makes it easier to write CTFC parameters without errors
Function ImportExistingCTFCparms([OutputWaveName])
	String OutputWaveName
	cryptidDebug()
	If(ParamIsDefault(OutputWaveName))
		OutputWaveName="TriggerInfo"
	EndIf

	Make/O/T $OutputWaveName
	Wave TriggerInfo=$OutputWaveName
	Variable error=0
	
	error+=td_ReadGroup("ARC.CTFC",TriggerInfo)
	
	return error

End //ImportExistingCTFCparms()

Function SetupDwellFB([SetPoint,Offset,RampSettings,inputChannel])
	
	Variable SetPoint,Offset
	Wave RampSettings
	String inputChannel
	Variable Error=0
	Variable StartEvent,StopEvent
	
	string fullVersion = versionString()
	string mainVersionNumber = fullVersion[0,1]
	


//	print "Setpoint: "+num2str(setPoint)
//	print "Offset: "+num2str(offset)
	
	if(paramIsDefault(inputChannel))
		inputChannel="Deflection"
	endif
	
	cryptidDebug()
	
	If(ParamIsDefault(Offset))
		Offset=0
	EndIf
	If(ParamIsDefault(RampSettings))
		StartEvent=5
		StopEvent=3
	Else
		StartEvent=RampSettings[%'Event Dwell']
		StopEvent=RampSettings[%'Event Ramp']
	EndIf
	
	//Honestly, I gave up trying to figure out what was going wrong here and just copied the old code from v14...
	if (stringMatch(mainVersionNumber, "14"))
		Make/O/T PIDSLoopGroup
		Error+=td_RG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		//Added to enable dynamic setpoint for CTFC
		if (paramIsDefault(setPoint))
			PIDSLoopGroup[%DynamicSetpoint] = "Yes"
		else
			PIDSLoopGroup[%DynamicSetpoint] ="No"
			PIDSLoopGroup[%Setpoint]=num2str(SetPoint)
			PIDSLoopGroup[%SetpointOffset]=num2str(Offset)
		Endif
		
		//THIS WILL NEED TO BE CHANGED TO WORK IN 16. USE SETPISLOOP
		
		PIDSLoopGroup[%InputChannel]=inputChannel
		PIDSLoopGroup[%OutputChannel]="Output.Z"
		PIDSLoopGroup[%IGain]="3000"
		PIDSLoopGroup[%StartEvent]=num2str(StartEvent)
		PIDSLoopGroup[%StopEvent]=num2str(StopEvent)
		PIDSLoopGroup[%OutputMin]="-10"
		PIDSLoopGroup[%OutputMax]="150"
		PIDSLoopGroup[%Status]="0"
		
		Error=0
		Error+=td_WG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		If(Error>0)
			cryptidDebug(diagString="Error code in SetupDwellFB: "+ num2str(Error), alwaysPrint=1)
		EndIf
	else
	
		Make/O/T PIDSLoopGroup
		Error+=td_RG("ARC.PIDSLoop.2",PIDSLoopGroup)
		
		Variable dynamicSetpoint
		//Added to enable dynamic setpoint for CTFC
		if (paramIsDefault(setPoint))
			dynamicSetpoint=1
		else
			dynamicSetpoint=0
		Endif
		
		//THIS WILL NEED TO BE CHANGED TO WORK IN 16. USE SETPISLOOP
	//	print setpoint
		Variable pGain = str2num(PIDSLoopGroup[%pGain])
		Variable sGain = str2num(PIDSLoopGroup[%sGain])
		//START HERE
		
		cryptidDebug(DiagString="Settings PISLoop for CTFC...")
		vs_SetPISLoop(2,num2str(StartEvent)+","+num2str(StopEvent),InputChannel,setPoint,pGain, 3000, sGain,"Output.Z",-10,150,dynamicSetpoint=dynamicSetpoint,setPointOffset=offset)		
		
		
	//	PIDSLoopGroup[%InputChannel]=inputChannel
	//	PIDSLoopGroup[%OutputChannel]="Output.Z"
	//	PIDSLoopGroup[%IGain]="3000"
	//	PIDSLoopGroup[%StartEvent]=num2str(StartEvent)
	//	PIDSLoopGroup[%StopEvent]=num2str(StopEvent)
	//	PIDSLoopGroup[%OutputMin]="-10"
	//	PIDSLoopGroup[%OutputMax]="150"
	//	PIDSLoopGroup[%Status]="0"
		
		Error=0
	//	Error+=td_WG("ARC.PIDSLoop.2",PIDSLoopGroup)
	
		If(Error>0)
			cryptidDebug(diagString="Error code in SetupDwellFB: "+ num2str(Error), alwaysPrint=1)
		EndIf
	endif
End




Function FRCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			String CheckBoxName=cba.ctrlName
			String SettingsWaveName=StringByKey("RampSettings", cba.userdata, "=")
			Strswitch(CheckBoxName)
				case "MoleculeTrigger_CB":
					If(WaveExists($SettingsWaveName))
						Wave SettingsWave=$SettingsWaveName
						SettingsWave[%$"Engage Second Trigger"]=Checked
					Endif
				break
				case "FilteredTrigger_CB":
					If(WaveExists($SettingsWaveName))
						Wave SettingsWave=$SettingsWaveName
						SettingsWave[%$"UseTriggerFilter"]=Checked
					EndIF
				break
			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function FRButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			String ButtonName=ba.ctrlName
			String SettingsWaveName=StringByKey("RampSettings", ba.userdata, "=")
			Wave SettingsWave=$SettingsWaveName
			String SettingsStrWaveName=StringByKey("RampSettingsStr", ba.userdata, "=")
			Wave/T SettingsStrWave=$SettingsStrWaveName

			Strswitch(ButtonName)
				case "SingleForceButton":
				
					//Set cryptid stop
					//wave vSettings = getCryptidSettings(0)
					//vSettings[%stop] = 1
					
					cryptidMain(3)

				break
				case "ViewWavesButton":
					Edit/K=1/W=(5.25,42.5,253.5,360.5) SettingsWave.ld
					Edit/K=1/W=(5.25,389,253.5,510.5) SettingsStrWave.ld
				break
				case "ViewLiveCurves":
					
					Display/N=Monitor root:MonitorV vs root:MonitorZ
				break
			EndSwitch
		
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End



Function MakeForceRampPanel([PanelName,WindowName,hostName]) : Panel

	String PanelName,WindowName, hostName
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(WindowName))
		WindowName="Force Pull"
	EndIf
	If(ParamIsDefault(PanelName))
		PanelName="ForceRampPanel"
	EndIf
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	//String WaveNameList="RampSettings="+GetWavesDataFolder(vSettings,2)+";RampSettingsStr="+GetWavesDataFolder(tSettings,2)+";"
	String WaveNameList="RampSettings="+"vSettings"+";RampSettingsStr="+"tSettings"+";"
	
	PauseUpdate; Silent 1		// building window...
	
	//If no hostname, make as independent window
	if (paramIsDefault(hostName))
		NewPanel/K=1/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	
	Variable xShift = 40 
	Variable yShift = 10
	
	ModifyPanel cbRGB=(47872,47872,47872)
	

	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={13.00,54.00},size={203.00,18.00}
	SetVariable SurfaceTrigger1,title="Surface Trigger",format="%.1W1PN"
	SetVariable SurfaceTrigger1,limits={-inf,inf,1e-11},value=vSettings[%'Surface Trigger']
	SetVariable ForceDistanceIFR,pos={13.00,76.00},size={203.00,18.00}
	SetVariable ForceDistanceIFR,title="Force Distance",format="%.1W1Pm"
	SetVariable ForceDistanceIFR,limits={-inf,inf,1e-07},value=vSettings[%'Extension Distance']
	SetVariable ApproachVelocity1,pos={13.00,99.00},size={203.00,18.00}
	SetVariable ApproachVelocity1,title="Approach Velocity",format="%.1W1Pm/s"
	SetVariable ApproachVelocity1,limits={-inf,inf,1e-07},value=vSettings[%'Approach Velocity']
	SetVariable RetractVelocity1,pos={13.00,122.00},size={203.00,18.00}
	SetVariable RetractVelocity1,title="Retract Velocity",format="%.1W1Pm/s"
	SetVariable RetractVelocity1,limits={-inf,inf,1e-07},value=vSettings[%'Retract Velocity']
	SetVariable DwellTime1,pos={13.00,144.00},size={203.00,18.00}
	SetVariable DwellTime1,title="Surface Dwell Time",format="%.1W1Ps"
	SetVariable DwellTime1,limits={-inf,inf,0.5},value=vSettings[%'Surface Dwell Time']
	SetVariable SamplingRateIFR,pos={13.00,167.00},size={203.00,18.00}
	SetVariable SamplingRateIFR,title="Sample Rate",format="%.1W1PHz"
	SetVariable SamplingRateIFR,value=vSettings[%'Sampling Rate']
	SetVariable FRDeflectionChannel,pos={13.00,199.00},size={203.00,18.00}
	SetVariable FRDeflectionChannel,title="Deflection Channel"
	SetVariable FRDeflectionChannel,value=tSettings[%deflectionChannel]
	CheckBox MoleculeTrigger_CB,pos={13.00,297.00},size={109.00,15.00},proc=FRCheckProc
	CheckBox MoleculeTrigger_CB,title="Molecule Trigger?"
	CheckBox MoleculeTrigger_CB,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	CheckBox MoleculeTrigger_CB,value=0
	SetVariable MoleculeTrigger1,pos={13.00,320.00},size={203.00,18.00}
	SetVariable MoleculeTrigger1,title="Molecule Trigger",format="%.1W1PN"
	SetVariable MoleculeTrigger1,limits={-inf,inf,5e-12},value=vSettings[%'Molecule Trigger']
	SetVariable NoTriggerDistance1,pos={13.00,343.00},size={203.00,18.00}
	SetVariable NoTriggerDistance1,title="No Trigger Distance",format="%.1W1Pm"
	SetVariable NoTriggerDistance1,limits={-inf,inf,1e-08},value=vSettings[%'No Trigger Distance']
	CheckBox FilteredTrigger_CB,pos={13.00,366.00},size={141.00,15.00},proc=FRCheckProc
	CheckBox FilteredTrigger_CB,title="Filtered Trigger Channel"
	CheckBox FilteredTrigger_CB,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	CheckBox FilteredTrigger_CB,value=0
	SetVariable FilterFreqSV,pos={13.00,389.00},size={203.00,18.00}
	SetVariable FilterFreqSV,title="Filter Frequency",format="%.1W1PHz"
	SetVariable FilterFreqSV,value=vSettings[%TriggerFilterFreq]
	Button SingleForceButton,pos={106.00,432.00},size={74.00,22.00},proc=FRButtonProc
	Button SingleForceButton,title="Single Force"
	Button SingleForceButton,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	Button SingleForceButton,fColor=(61440,61440,61440)
	TitleBox MoleculeTrigger_TB,pos={9.00,265.00},size={141.00,23.00}
	TitleBox MoleculeTrigger_TB,title="Molecule Trigger Settings"
	TitleBox DCEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox DCEventTitle,fSize=18,frame=0,fStyle=1
	TitleBox ForceRampTitle,pos={89.00,11.00},size={100.00,25.00},title="Force Ramp"
	TitleBox ForceRampTitle,fSize=18,frame=0,fStyle=1
	SetVariable FREventEnable,pos={10.00,514.00},size={207.00,18.00}
	SetVariable FREventEnable,title="Event Enable"
	SetVariable FREventEnable,value=vSettings[%'Event Enable']
	SetVariable FREventDwell,pos={10.00,536.00},size={206.00,18.00}
	SetVariable FREventDwell,title="Event Dwell"
	SetVariable FREventDwell,value=vSettings[%'Event Dwell']
	SetVariable FREventRamp,pos={10.00,558.00},size={206.00,18.00}
	SetVariable FREventRamp,title="Event Ramp"
	SetVariable FREventRamp,value=vSettings[%'Event Ramp']
	SetVariable FRSCBank,pos={10.00,594.00},size={206.00,18.00}
	SetVariable FRSCBank,title="Standard Capture Bank"
	SetVariable FRSCBank,value=vSettings[%SCaptureBank]
	SetVariable FRFilteredCBank,pos={10.00,617.00},size={206.00,18.00}
	SetVariable FRFilteredCBank,title="Filtered Capture Bank"
	SetVariable FRFilteredCBank,value=vSettings[%SCaptureFilterBank]
	SetVariable FRZSensorChannel,pos={13.00,224.00},size={203.00,18.00}
	SetVariable FRZSensorChannel,title="ZSensor Channel"
	SetVariable FRZSensorChannel,value=tSettings[%zSensorChannel]

End


Window ForceRampPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /K=1 /W=(1319,394,1597,1101) as "Force Pull"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetVariable SurfaceTrigger1,pos={13.00,54.00},size={203.00,18.00}
	SetVariable SurfaceTrigger1,title="Surface Trigger",format="%.1W1PN"
	SetVariable SurfaceTrigger1,limits={-inf,inf,1e-11},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Surface Trigger']
	SetVariable ForceDistanceIFR,pos={13.00,76.00},size={203.00,18.00}
	SetVariable ForceDistanceIFR,title="Force Distance",format="%.1W1Pm"
	SetVariable ForceDistanceIFR,limits={-inf,inf,1e-07},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Extension Distance']
	SetVariable ApproachVelocity1,pos={13.00,99.00},size={203.00,18.00}
	SetVariable ApproachVelocity1,title="Approach Velocity",format="%.1W1Pm/s"
	SetVariable ApproachVelocity1,limits={-inf,inf,1e-07},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Approach Velocity']
	SetVariable RetractVelocity1,pos={13.00,122.00},size={203.00,18.00}
	SetVariable RetractVelocity1,title="Retract Velocity",format="%.1W1Pm/s"
	SetVariable RetractVelocity1,limits={-inf,inf,1e-07},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Retract Velocity']
	SetVariable DwellTime1,pos={13.00,144.00},size={203.00,18.00}
	SetVariable DwellTime1,title="Surface Dwell Time",format="%.1W1Ps"
	SetVariable DwellTime1,limits={-inf,inf,0.5},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Surface Dwell Time']
	SetVariable SamplingRateIFR,pos={13.00,167.00},size={203.00,18.00}
	SetVariable SamplingRateIFR,title="Sample Rate",format="%.1W1PHz"
	SetVariable SamplingRateIFR,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Sampling Rate']
	SetVariable FRDeflectionChannel,pos={13.00,199.00},size={203.00,18.00}
	SetVariable FRDeflectionChannel,title="Deflection Channel"
	SetVariable FRDeflectionChannel,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:tSettings[%deflectionChannel]
	CheckBox MoleculeTrigger_CB,pos={13.00,297.00},size={109.00,15.00},proc=FRCheckProc
	CheckBox MoleculeTrigger_CB,title="Molecule Trigger?"
	CheckBox MoleculeTrigger_CB,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	CheckBox MoleculeTrigger_CB,value=0
	SetVariable MoleculeTrigger1,pos={13.00,320.00},size={203.00,18.00}
	SetVariable MoleculeTrigger1,title="Molecule Trigger",format="%.1W1PN"
	SetVariable MoleculeTrigger1,limits={-inf,inf,5e-12},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Molecule Trigger']
	SetVariable NoTriggerDistance1,pos={13.00,343.00},size={203.00,18.00}
	SetVariable NoTriggerDistance1,title="No Trigger Distance",format="%.1W1Pm"
	SetVariable NoTriggerDistance1,limits={-inf,inf,1e-08},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'No Trigger Distance']
	CheckBox FilteredTrigger_CB,pos={13.00,366.00},size={141.00,15.00},proc=FRCheckProc
	CheckBox FilteredTrigger_CB,title="Filtered Trigger Channel"
	CheckBox FilteredTrigger_CB,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	CheckBox FilteredTrigger_CB,value=0
	SetVariable FilterFreqSV,pos={13.00,389.00},size={203.00,18.00}
	SetVariable FilterFreqSV,title="Filter Frequency",format="%.1W1PHz"
	SetVariable FilterFreqSV,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%TriggerFilterFreq]
	Button SingleForceButton,pos={106.00,432.00},size={74.00,22.00},proc=FRButtonProc
	Button SingleForceButton,title="Single Force"
	Button SingleForceButton,userdata="RampSettings=vSettings;RampSettingsStr=tSettings;"
	Button SingleForceButton,fColor=(61440,61440,61440)
	TitleBox MoleculeTrigger_TB,pos={9.00,265.00},size={141.00,23.00}
	TitleBox MoleculeTrigger_TB,title="Molecule Trigger Settings"
	TitleBox DCEventTitle,pos={115.00,470.00},size={56.00,25.00},title="Events"
	TitleBox DCEventTitle,fSize=18,frame=0,fStyle=1
	TitleBox ForceRampTitle,pos={89.00,11.00},size={100.00,25.00},title="Force Ramp"
	TitleBox ForceRampTitle,fSize=18,frame=0,fStyle=1
	SetVariable FREventEnable,pos={10.00,514.00},size={207.00,18.00}
	SetVariable FREventEnable,title="Event Enable"
	SetVariable FREventEnable,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Event Enable']
	SetVariable FREventDwell,pos={10.00,536.00},size={206.00,18.00}
	SetVariable FREventDwell,title="Event Dwell"
	SetVariable FREventDwell,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Event Dwell']
	SetVariable FREventRamp,pos={10.00,558.00},size={206.00,18.00}
	SetVariable FREventRamp,title="Event Ramp"
	SetVariable FREventRamp,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%'Event Ramp']
	SetVariable FRSCBank,pos={10.00,594.00},size={206.00,18.00}
	SetVariable FRSCBank,title="Standard Capture Bank"
	SetVariable FRSCBank,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%SCaptureBank]
	SetVariable FRFilteredCBank,pos={10.00,617.00},size={206.00,18.00}
	SetVariable FRFilteredCBank,title="Filtered Capture Bank"
	SetVariable FRFilteredCBank,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:vSettings[%SCaptureFilterBank]
	SetVariable FRZSensorChannel,pos={13.00,224.00},size={203.00,18.00}
	SetVariable FRZSensorChannel,title="ZSensor Channel"
	SetVariable FRZSensorChannel,limits={500,50000,1000},value=root:Settings:Cryptid:WorkingFolders:ForceRamp_0:tSettings[%zSensorChannel]
	ToolsGrid snap=1,visible=1
EndMacro
