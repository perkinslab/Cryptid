#pragma TextEncoding = "UTF-8"
#pragma rtGlobals=3				// Use modern global access method and strict wave access
#pragma DefaultTab={3,20,4}		// Set default tab width in Igor Pro 9 and later

//This file contains useful functions for writing modules for cryptid


//Most likely use: Use type 0 or 1 for variable or settings waves, use stepNum=-1
//					this returns a wave reference to the settings for the current step
//Type = 0 or 1 for variable or text wave
//Package is the name of the package (default cryptid or none)
//Settings is the name of the setting if not vSettings or tSettings
//Stepnum is the number of cryptid step where you want to get the settings waves
// default is dont use, -1 returns the settings from the current steps.
Function/Wave getCryptidSettings(type, [package, setting, stepNum])

	string package, setting
	variable type, stepNum
	wave/t cryptidStack = getCryptidStack()
	
	if(paramIsDefault(package))
		package="Cryptid"
	endif
	
	
	string DFLoc
	if(stringMatch("current",package))
		DFLoc=getDataFolder(1)
	endif

	if(paramIsDefault(stepNum))
		DFLoc="root:Settings:"+package+":"
	else
		if (stepNum == -1)
			DFLoc = getWorkingFolder(cryptidStack[getCurrentStepNumber()])
		else
			DFLoc = getWorkingFolder(cryptidStack[stepNum])
		endif
	endif
	
	string wType = "vSettings"
	if (type == 1)
		wType = "tSettings"
	endif
	
	if (!paramIsDefault(setting))
		wType = setting
	endif
	
	return $DFLoc+wType
End

//Updates the cryptid status display
Function updateStatus(updateMessage, [error, BGcolour, TextColour, alsoPrint])
	
	string updateMessage
	string BGColour, textColour
	Variable error, alsoPrint

	if(paramIsDefault(alsoPrint))
		alsoPrint = 0
	endif
	
	if(paramIsDefault(error))
		error = 0
	endif
	
	wave/t tSettings = getCryptidSettings(1)
	tSettings[%cryptidStatusDisplay] = updateMessage
	
	if(!ParamISDefault(BGColour))
		//SetVariable/N=$tSettings[%panelName] CryptidStatus valueBackColor=(0,43520,65280) 
	endif
	if(!ParamIsDefault(textColour))
		//SetVariable CryptidStatus valueColor=(13056,13056,13056)
	endif
	
	wave vSettings = getCryptidSettings(0)

	//If error status changed, update
	if (error != vSettings[%error])
		vSettings[%error] = error
		
		if (error)
			SetVariable CryptidStatusDisplay win=$tSettings[%panelName] ,valueBackColor=(65280,16384,16384)
		else
			SetVariable CryptidStatusDisplay win=$tSettings[%panelName] ,valueBackColor=(48896,59904,65280)
		endif
		
	endif	
	
	
	//Maybe start to keep track?
	wave/T experimentLog = getCryptidSettings(1, setting="experimentLog")
	variable currentSize = dimsize(experimentLog,0)
	
	if (currentSize > 1000)
		redimension/N=0 experimentLog
		currentSize=0
	endif
	
	insertPoints currentSize, 1, experimentLog
	experimentLog[currentSize] = updateMessage
	
	if (alsoPrint)
		print updateMessage
	endif
End



//Updates the graph with the given waves. If default, just updates the graph
Function updateCryptidGraph([deflVolts, zSensorVolts, asIs, Zero])


	Wave deflVolts, zSensorVolts
	Variable asIs, Zero
	
	//TIME TEST
	cryptidTimer(10)
	if(paramIsDefault(Zero))
		Zero=1
	endif
	
	if(paramIsDefault(asIs))
		asIs=0
	endif
	
	string cryptidGraphName = getCStr("cryptidGraphname")
	
	if(paramIsDefault(deflVolts))
		wave deflVolts = $getCStr("previousDeflVDisplay")
		wave zSensorVolts = $getCStr("previouszSensorVDisplay")
	else
		wave/t tSettings = getCryptidSettings(1)
		tSettings[%previousDeflVDisplay] = getWavesDataFolder(deflVolts,2)
		tSettings[%previousZSensorVDisplay] = getWavesDataFolder(zSensorVolts,2)
	endif
	
	//Get the display waves
	wave workingForce = root:Settings:Cryptid:workingForce
	wave workingZSensor = root:Settings:Cryptid:workingZSensor
	
	//Remake first, as duplicating doesn't for some stupid reason
	redimension/N=0 workingForce
	redimension/N=0 workingZSensor
	
	if(!waveExists(deflVolts))
		return 1
	endif
	
	duplicate/O deflVolts workingForce
	duplicate/O zSensorVolts workingZSensor
	
	//NEW
	waveTransform/O zapNans workingForce
	waveTransform/O zapNans workingZSensor
	
	if (asIs)
		setAxis/A/W=$cryptidGraphName bottom
		setAxis/A/W=$cryptidGraphName left
		Label/W=$cryptidGraphName bottom nameOfWave(deflVolts)+" (\\U)"
		Label/W=$cryptidGraphName left nameOfWave(zSensorVolts)+" (\\U)"
		return 1
	endif

	//get the parameters
	variable springConstant = GV("SpringConstant")
	variable invols = GV("Invols")
	variable ZLVDTSens = GV("ZLVDTSens")

	//Calculate offsets and sensitivities, adjust display waves accordingly
	Variable deflVOffset = getCVar("deflVOffset")
	
	String yAxis = getCStr("yAxisOption")
	String xAxis = getCStr("xAxisOption")

	string displayWaveName = "root:Settings:Cryptid:workingForce"
	string axisName = "yAxisOption"
	Variable maxIter = 2
	Variable i
	for(i=0;i<maxIter;i+=1)
		if (i==1)
			displayWaveName = "root:Settings:Cryptid:workingZSensor"
			axisName = "xAxisOption"
		endif

		string displayOption = getCStr(axisName)
		wave displayWave = $displayWaveName
		
		strSwitch(displayOption)

			case "Force":
				variable combo = springConstant*invols
				variable offset = -combo*deflVOffset
				fastop displayWave = (-combo)*workingForce - (offset)
				setScale/p y, -1, -1, "N", displayWave
				break
			case "Defl":
				offset =- deflVOffset*invols
				fastop displayWave = (-invols)*workingForce - (offset)
				setScale/p y, -1, -1, "m", displayWave
				break
			case "DeflV":
				displayWave = deflVolts
				break
			case "ZSensor":
				offset = waveMin(ZSensorVolts)*ZLVDTSEns
				fastop displayWave = (-ZLVDTSens)*ZSensorVolts - (Offset)
				setScale/p y, -1, -1, "m", displayWave
				break
			case "zSensorV":
				displayWave = zSensorVolts
				break
			case "Time":
				displayWave = x
				setScale/p y, -1, -1, "s", displayWave
				break
		EndSwitch
		
	endFor
	
	setAxis/A/W=$cryptidGraphName bottom
	setAxis/A/W=$cryptidGraphName left
	Label/W=$cryptidGraphName bottom xAxis+" (\\U)"
	Label/W=$cryptidGraphName left yAxis+" (\\U)"
	
	//TIME TEST
	cryptidTimer(11)

End

//Returns 0 or 1 depending on if the named window exists
Function windowExists(name)

	string name
	
	if (wintype(name) == 0)
		return 0
	else
		return 1
	endif

End

Function/Wave getWaveFromRun(saveName, type)

	string saveName
	variable type
	
	if (type == 1)
		saveName = "d_"+saveName
	else
		saveName = "z_"+saveName
	endif
			
	string waveLoc = "root:Settings:Cryptid:currentRunWaves:"+saveName
	wave/z returnWave = $waveLoc
	
	if (waveExists(returnWave))
		return returnWave
	else
		CryptidDebug(diagString = "Wave not found in getWaveFromRun", alwaysPrint = 1, alert = 1, updateDisplay = 1)
	endif
	
End

//The name is silly, too late to change it
//Use this to write parameter names and values to the note of your saved waves
//Typically call this right before cryptidMain(1, deflV=deflV, zSensor=sSensor) to
//append the appropriate things to the note
//EG:
//parameterNames = "someInfo;SomeOtherInfo;lastBitOInfo;"
//parameterValues = "1;anotherThing;theCakeIsALIE;"
Function writeToStdOut(parameterNames,parameterValues,[overWrite])

	string parameterNames, parameterValues
	Variable overWrite
	
	Wave/t stdOut = getCryptidSettings(1,setting="StdOut")
	
	if (paramIsDefault(overWrite))
		overWrite = 1
	endif
	
	Variable start = dimSize(stdOut,0)
	
	if(overWrite)
		redimension/N=0 stdOut
		redimension/N=(1,2) stdOut
		stdOut[0] = ""
		start = 0
	endif
	
	variable numItems = itemsInList(parameterNames)
	variable i

	Variable finish = start+numItems
	
	redimension/N=(finish,2) stdOut
	
	//Write to the wave stdOut
	Variable j = 0
	for (i=start; i<finish; i+=1)
	
		string paramName = stringFromList(j, parameterNames)
		string paramValue = stringFromList(j,parameterValues)
		stdOut[i][0] = paramName
		stdOut[i][1] = paramValue	
		setDimLabel 0, i, $paramName, stdOut
		j+=1
	
	endFor

End


//Returns a list from a wave containing either all of the data in that row/column
//Use input to pass your wave, type as 0 or 1 for row or column, labelName if you
//want to use a specific row/column with a given label, or index of the row/column.
//USE index = -1 to get the labels for the given dimension
Function/S Wave2List(input, type, [labelName, index])

	wave/Z/t input
	variable type, index
	string labelName
	
	if (!WaveExists(input))
		return ""
	endif
	
	//type is row 0 or column 1
	string list=""
	variable i
		
	if(paramIsDefault(index))
		index = 0
	endif
	
	if(!paramIsDefault(labelName))
		index = findDimLabel(input,!type,labelName)
	endif
	
	//special case for returning labels
	if(index == -1)
		for (i=0;i<dimsize(input,type);i+=1)
			list += getDimLabel(input,type,i)+";"
		endfor
		return list
	endif
	
	//Change row,rowInc,col,colInc depending on type
	variable colinc = 0
	variable rowinc = 0
	Variable row = 0
	Variable col = 0
	
	if (type)
		row = index
		colInc = 1
	else
		col = index 
		rowInc = 1
	endif
	
	for (i=0;i<dimsize(input,type);i+=1)
		list += input[row+i*rowInc][col+i*colInc]+";"
	endfor
	
	return list

End


//Returns the index of the first ramp run in the experiment 
Function firstRamp()

	//Find the first ForceRamp and returns the location to it
	wave/t cryptidStack = getCryptidStack()
	variable indentNum
	variable found = 0
	
	Variable maxIter = dimsize(cryptidStack,0)
	Variable i
	for(i=0;i<maxIter;i+=1)
		if (stringMatch( getStepType(stepNum=i),"ForceRamp"))
			indentNum = i
			found = 1
			break
		endif
	endFor
	
	if(found)
		return indentNum
	else
		return -1
	endif
	
End


//Returns the voltage at which the given curve crosses a specific force
Function getSurfaceVoltageForceOffset(forceOffset,[DeflVolts, zSensorVolts, rampSettings, altStartPoint])

	Variable forceOffset, altStartPoint
	Wave DeflVolts, zSensorVolts, rampSettings
	
	if(paramIsDefault(DeflVolts))
		Wave DeflVolts = getFirstRampWave("DeflVolts")
	endif
	if(paramIsDefault(zSensorVolts))
		Wave zSensorVolts = getFirstRampWave("zSensorVolts")
	endif
	if(paramIsDefault(rampSettings))
		Wave rampSettings = getFirstRampWave("vSettings")
	endif

	WaveStats/Q zSensorVolts
	Variable startP = v_maxRowLoc
	Variable lowForce = DeflVolts[startP]
	Variable triggerForce = rampSettings[%'Surface Trigger']

	if(!ParamIsDefault(altStartPoint))
		startP = altStartPoint
	endif
	
	findLevel/Q/R=[startP] DeflVolts, (lowForce - (triggerForce + forceOffset)/GV("SpringConstant")/GV("Invols"))
	if (v_flag)
		doAlert 0, "Desired force offeset couldn't be found :("
		return -1
	endif
	 killWaveStats()
	return zSensorVolts(V_levelX)

End

//Returns the zLVDT position of the surface in volts
//Returns -1 if fail
Function getSurfaceVoltage([indentForce,zSensorVolts])

	Wave zSensorVolts
	Variable indentForce
	
	wave FRSettings = getFirstRampWave("vSettings")
	wave FRZSensor = getFirstRampWave("ZSensorVolts")
	
	//MAKE SURE TO CHECK IF THIS FAILS
	if (!waveExists(FRSettings) || !waveExists(FRZSensor))
		return -1
	endif
	
	//Lets also fail if it's been more than 5 minutes since the measurement was taken to avoid drift issues
	variable secondsSinceWave = dateTime - str2num(StringByKey("MODTIME", WaveInfo(zSensorVolts,0) ) )
	if (secondsSinceWave > 300)
		return -1
	endif
	
	if(paramIsDefault(indentForce))
		indentForce=FRSettings[%'Surface Trigger']
	endif
	
	if(paramIsDefault(zSensorVolts))
		Wave zSensorVolts=FRZSensor
	endif
	
	Variable indentDist = indentForce/GV("SpringConstant")
			
	return waveMax(FRZSensor) - indentDist/GV("ZLVDTSens")

End

//Kill variables generated by WaveStats
Function killWaveStats()

	KillVariables/Z V_adev, v_avg, v_endChunk, v_endCol, v_endLayer, v_endRow, v_kurt, v_max, v_maxChunkLoc, v_maxColLoc, v_maxLayerLoc, v_maxLoc, v_maxRowLoc, v_min, v_minChunkLoc, v_minColloc, v_minLayerLoc, v_minloc, v_minRowloc, v_npnts, v_numINFs, v_numNANs, v_rms, v_sdev, v_sem, v_skew, v_startChunk, v_startCol, v_startLayer, v_startRow, v_Sum

End

//Moves a window to 0,0 (in case it gets lost, usually when remoting in
Function findWindow([windowName])

	string windowName
	
	if(paramIsDefault(windowName))
		windowName=""
	endif
	
	getWindow $windowName wsizeOuter
	
	moveWindow/W=$windowName 0, 0, v_right-v_left, v_bottom-v_top

End

//Copy of the Asylum function to initializeMotors, but only does the LDs
Function InitializeLDMotors()


	DisableFocusAutoCorrect()


	variable status = FindLdMotorsHome()
	
	PV("TempIgnoreDoor",0)			//reset temp ignore door
	return status
End //InitializeEngageMotors

//Set up a zFeedback and return the event enable
//Uses the current ZLVDT value as default
Function setupZFeedback([eventEnable,eventStop,setpoint])

	string eventEnable, eventStop
	variable setpoint
	
	if(paramIsDefault(eventEnable))
		eventEnable="6"
	endif
	if(paramIsDefault(eventStop))
		eventStop="7"
	endif
	if(paramIsDefault(setpoint))
		setpoint = td_rv("Cypher.LVDT.Z")
	endif
	
	//  Setup z feedback loop, put in correct I value for PID loop.  
	Variable Error = vs_setPISLoop(2,eventEnable+","+eventStop,"ZSensor",setPoint,0,10^GV("ZIGain"),0,"Output.Z",-10,150)
	
	return str2num(eventEnable)

End

//Starts z feedback at the current spot
Function startZFeedback([eventEnable,eventStop,setpoint])

	string eventEnable, eventStop
	variable setpoint
	
	if(paramIsDefault(eventEnable))
		eventEnable="6"
	endif
	if(paramIsDefault(eventStop))
		eventStop="7"
	endif
	if(paramIsDefault(setpoint))
		setpoint = td_rv("Cypher.LVDT.Z")
	endif
	
	//  Setup z feedback loop, put in correct I value for PID loop.  
	Variable Error = vs_setPISLoop(2,eventEnable+","+eventStop,"ZSensor",setPoint,0,10^GV("ZIGain"),0,"Output.Z",-10,150)
	
	td_WS("Event."+eventEnable,"Once")
	
	return str2num(eventStop)
End

//Starts z feedback at the current spot
Function stopZFeedback([eventStop])

	string eventStop
	
	if(paramIsDefault(eventStop))
		eventStop="7"
	endif

	td_WS("Event."+eventStop,"Once")
	
End

//Uses the stream function Devin found to do 500KHz and 2MHz data recording
Function SetupStream(speed,timespan,wave0,wave1,[Wave0String,Wave1String,event])
	variable speed, timespan
	string Wave0String,Wave1String,event
	wave wave0,wave1
	td_ws("Cypher.crosspoint.infastb","Defl") //We will make the deflection measurement on inFastB
	//This sets default behavior which is read Input.FastA and the Zsensor
	if( ParamIsDefault(Wave0String))
		Wave0String="Input.FastB"
	endif
	
	if( ParamIsDefault(Wave1String))
		Wave1String="LVDT.Z" //

	endif
	
	if (paramIsDefault(event))
		event = "1"
	endif

	variable totpoints
	Variable error = 0
	if(speed==0) //Running at 500 kHz
		totpoints=timespan*5e5
		td_wv("cypher.input.fastb.filter.freq",2.5e5)
		td_wv("cypher.lvdt.z.filter.freq",5e3)
	elseif(speed==1) //Running at 2 MHz
		totpoints=timespan*2e6
		//CHANGED FROM 4e5
		td_wv("cypher.input.fastb.filter.freq",1e6)
		//CHANGED FROM 5e3
		td_wv("cypher.lvdt.z.filter.freq",25e3)
	else
		print "invalid capture rate"
		error+=-1
		return error
	endif
		
	if(totpoints>=4e7)//Limits us to 20 seconds of 2 MHz data at the moment until we can play with the values
		print "Total points capped"
		error+=-2
		totpoints=4e7
	endif
	
	if(speed==0) //Running at 500 kHz
		Make/O/N=(totpoints) H0, H1	// N can be arbitrary long but beware Igor memory limitations
		duplicate/o H0, wave0
		duplicate/o H1,wave1

		killwaves H0,H1
	else
		Make/O/N=(totpoints) H0, H1	// N can be arbitrary long but beware Igor memory limitations
		duplicate/o H0, wave0
		duplicate/o H1,wave1
		
		killwaves H0,H1

	endif

	string errorStr = "Error: "
	errorStr += num2str(td_StopStream("Cypher.Stream.0"))		// stop the stream	


	errorStr += num2str( td_ws("Cypher.Stream.0.Channel.0", Wave0String))		// only Cypher signals
	errorStr +=  num2str(td_ws("Cypher.Stream.0.Channel.1", Wave1String))		// do not use "Cypher" in front of the channel names
	
	if(speed==0) //Running at 500 kHz
		errorStr += num2str( td_ws("Cypher.Stream.0.Rate", "500 kHz"))
	
	elseif(speed == 1)
		
		errorStr += num2str( td_ws("Cypher.Stream.0.Rate", "2 MHz"))
	endif
	
	errorStr += num2str( td_ws("Cypher.Stream.0.Events", event))

	fastop wave0 = 0
	fastop wave1 = 0

	errorStr += num2str( td_DebugStream("Cypher.Stream.0.Channel.0", Wave0, ""))
	errorStr += num2str( td_DebugStream("Cypher.Stream.0.Channel.1", Wave1, "") )
	
	errorStr +=  num2str(td_SetupStream("Cypher.Stream.0"))
	
//	print errorstr

	return error
End


//Stole this one from david. Going to set default to simply moving the zSensor  
Function programCTFC([RampChannel, RampOffset1, RampSlope1, TriggerChannel1, TriggerType1, TriggerValue1, TriggerCompare1, DwellTime1, RampOffset2, RampSlope2, TriggerChannel2, TriggerType2, TriggerValue2, Triggercompare2, DwellTime2, EventDwell, EventRamp, EventEnable, Callback])
//Sets up a CTFC with null parameters (i.e., doesn't do anything).  All actual parameters are set as optional
	String RampChannel 
	Variable RampOffset1, RampSlope1
	String TriggerChannel1, TriggerType1
	Variable TriggerValue1
	String TriggerCompare1
	Variable DwellTime1, RampOffset2, RampSlope2
	String TriggerChannel2, TriggerType2
	Variable TriggerValue2
	String Triggercompare2
	Variable DwellTime2
	String EventDwell, EventRamp, EventEnable, Callback
	

	//If we are triggering on zSensor, determine direction for rampChannel
	if (paramisdefault(TriggerChannel1))
		TriggerChannel1 = "ZSensor"
	endif

	Variable direction
	
	//Determine direction
	if (cmpstr(triggerChannel1, "ZSensor") == 0)	
		Variable currentZ = td_rv("Cypher.LVDT.Z")
		if (currentZ > triggerValue1)		//If we are currently at a higher voltage than the setpoint (tip is closer to sample)
			direction = -1
		else
			direction = 1
		endif
	endif
		
	//Velocity should be set by the direction
	if (paramisdefault(RampSlope1))
		RampSlope1 = direction*300e-9/GV("ZPiezoSens")
	endif
	
	//If user input, slope might be wrong. Correct if needed
	if (sign(rampSlope1) != direction)
		rampSlope1 *= direction
	endif

	if (paramIsDefault(triggerCompare1))
		if (direction == -1)
			triggerCompare1 = "<="
		else
			triggerCompare1 = ">="
		endif
	endif

	//Default parameter handling:
	if (paramisdefault(RampChannel))
		RampChannel = "Output.Z"
	endif
	
	//Dynamically set rampOffset
	if (paramisdefault(RampOffset1))
		if (direction == -1)
			RampOffset1 = -( td_RV("Output.Z") + 5 )
		else
			RampOffset1 = 160 - td_RV("Output.Z") 
		endif
	endif

	if (paramisdefault(TriggerType1))
		TriggerType1 = "Absolute"
	endif
	if (paramisdefault(TriggerValue1))
		TriggerValue1 = -99
	endif
	if (paramisdefault(DwellTime1))
		DwellTime1 = 0
	endif
	if (paramisdefault(RampOffset2))
		RampOffset2 = 0
	endif
	if (paramisdefault(RampSlope2))
		RampSlope2 = 0
	endif
	if (paramisdefault(TriggerChannel2))
		TriggerChannel2 = "ZSensor"
	endif
	if (paramisdefault(TriggerType2))
		TriggerType2 = "Absolute"
	endif
	if (paramisdefault(TriggerValue2))
		TriggerValue2 = -99
	endif
	
	//The idea here is to not do anything i believe. Could use dummy instead
	if (paramisdefault(TriggerCompare2))
		TriggerCompare2 = ">="
	endif
	if (paramisdefault(DwellTime2))
		DwellTime2 = 0
	endif
	if (paramisdefault(EventDwell))
		EventDwell = "15"
	endif
	if (paramisdefault(EventRamp))
		EventRamp = "17"
	endif
	if (paramisdefault(EventEnable))
		EventEnable = "14"
	endif
	if (paramisdefault(Callback))
		Callback = ""
	endif
	
	td_writestring("ARC.CTFC.RampChannel", RampChannel)
	td_writevalue("ARC.CTFC.RampOffset1", RampOffset1)
	td_writevalue("ARC.CTFC.RampSlope1",RampSlope1)		
	td_writevalue("ARC.CTFC.RampOffset2", RampOffset2)
	td_writevalue("ARC.CTFC.RampSlope2", RampSlope2)
	td_writestring("ARC.CTFC.TriggerChannel1", TriggerChannel1)
	td_writestring("ARC.CTFC.TriggerType1", TriggerType1)
	td_writevalue("ARC.CTFC.TriggerValue1", TriggerValue1)
	td_writestring("ARC.CTFC.TriggerCompare1", TriggerCompare1)
	td_writevalue("ARC.CTFC.DwellTime1", DwellTime1) //in seconds
	td_writestring("ARC.CTFC.TriggerChannel2", TriggerChannel2)
	td_writestring("ARC.CTFC.TriggerType2", TriggerType2)
	td_writevalue("ARC.CTFC.TriggerValue2", TriggerValue2)
	td_writestring("ARC.CTFC.TriggerCompare2", TriggerCompare2)
	td_writevalue("ARC.CTFC.DwellTime2", DwellTime2)
	td_writestring("ARC.CTFC.EventDwell", EventDwell)
	td_writestring("ARC.CTFC.EventRamp", EventRamp)
	td_writestring("ARC.CTFC.EventEnable", EventEnable)
	td_writestring("ARC.CTFC.Callback", Callback)
End

//Wrapper function for vs_setPISLoop which gives some default parameters.
//Defaults to a z-feedback loop, start 15, stop 17
Function setFeedback([EventString, inChannel, setpoint, pGain, IGain, sGain, outChannel, outputMin, outputMax])

	String eventString, inChannel, outChannel
	Variable setpoint, pGain, iGain, sGain, outputMin, outputMax

	//Start with the default z-params
	Struct ARFeedbackStruct FB
	ARGetFeedbackParms(FB,"Z")
	Variable dynamicSetpoint = 0
	
	
	wave vSettings
	//Replace the ones the user wants to change
	if (paramIsDefault(EventString))
		eventString = num2str(vSettings[%feedbackStartEvent])+","+num2str(vSettings[%feedbackStopEvent])
	endif
	
	if (paramIsDefault(inChannel))
		inChannel = "ZSensor"
	endif
	
	if (paramIsDefault(setpoint))
		dynamicSetpoint = 1
	endif
	
	if (paramIsDefault(pGain))
		pGain = FB.pGain
	endif
	
	if (paramIsDefault(iGain))
		iGain = FB.iGain
	endif
	
	if (paramIsDefault(sGain))
		sGain = FB.sGain
	endif
	
	if (paramIsDefault(outChannel))
		outChannel = "Output.Z"
	endif
	
	//Z piezo goes from -10V (farthest from tip) to 150V (closest to tip)
	if (paramIsDefault(outputMin))
		outputMin = -10
	endif
	
	if (paramIsDefault(outputMax))
		outputMax = 150
	endif
	
	//Now the actual input
	FB.StartEvent = StringFromList(0,EventString,",")
	FB.StopEvent = StringFromList(1,EventString,",")
	FB.Input = inChannel
	
	FB.DynamicSetpoint = DynamicSetpoint
	if (!paramIsDefault(setpoint))
		FB.Setpoint = setpoint
	endif
	FB.pGain = pGain
	FB.iGain = iGain
	FB.sGain = sGain
	FB.Output = outChannel
	FB.outputMin = outputMin
	FB.outputMax = outputMax
	FB.setPointOffset = 0
	
	string ErrorStr = vs_writePIDSLoop(FB)
	ARReportError(ErrorStr)
	
	return 0
	
	
End

Function killTrailingZeroes(someWave)

	Wave someWave
	
	variable numRows = dimsize(someWave,0)
	
	Variable lastRealPos
	Variable i
	for (i = numRows-1; i > 0; i-=1)
		if (someWave[i][0] != 0)
			lastRealPos = i
			break
		endif
	endfor
	
	deletePoints lastRealPos+1, numRows-1, someWave
	

End

Function DelfVOffset()

	return getCVar("deflVOffset")

End

//Prepares waves for SC. Returns the appropriate decimation
Function prepWavesforSC(wave1, wave2, sampleRate, maxTime)
	
	wave wave1, wave2
	Variable sampleRate, maxTime
	
	Variable nop = MaxTime*sampleRate
	nop += (32-mod(nop,32))*(!!mod(nop,32))
	Variable waveDeci = ARGetDeci(nop/MaxTime)
	nop = round(cMasterSampleRate*MaxTime/waveDeci)
	nop += (32-mod(nop,32))*(!!mod(nop,32))

	redimension/N=(nop) wave1, wave2
	
//	fastOp wave1 = 0
//	fastOp wave2 = 0
	
	return waveDeci

End

//Prepares waves for SC. Returns the appropriate decimation
Function prepWaveforSC(wave1, sampleRate, maxTime)
	
	wave wave1
	Variable sampleRate, maxTime
	
	Variable nop = MaxTime*sampleRate
	nop += (32-mod(nop,32))*(!!mod(nop,32))
	Variable waveDeci = ARGetDeci(nop/MaxTime)
	nop = round(cMasterSampleRate*MaxTime/waveDeci)
	nop += (32-mod(nop,32))*(!!mod(nop,32))

	redimension/N=(nop) wave1
	
//	fastOp wave1 = 0
//	fastOp wave2 = 0
	
	return waveDeci

End

//Setup a standard capture channel
Function setupStandardCapture(deflWaveName, zSensorWaveName, frequency, length, bank, event, callback, [deflectionChannel, zSensorChannel])

	string deflWaveName, zSensorWaveName, callback, deflectionChannel, zSensorChannel
	variable frequency, length, bank, event
	
	if( paramIsDefault(deflectionChannel) )
		deflectionChannel="Deflection"
	endif
	if( paramIsDefault(zSensorChannel) )
		zSensorChannel="ZSensor"
	endif	

	//reset filter frequencies
	if ( stringMatch("Deflection",deflectionChannel) || stringMatch("Cypher.Input.FastA",deflectionChannel) )
		td_WV("Cypher.Input.FastA.filter.freq",floor(frequency/2) )
	elseif ( stringMatch("Cypher.Input.FastB", deflectionChannel) )
		td_WV("Cypher.Input.FastB.filter.freq",floor(frequency/2) )
	endif
	
	//Cont here!!
	Variable pnts = length*frequency 
	
	Make/O/N=(pnts) $deflWaveName
	Wave deflWave = $deflWaveName
	Make/O/N=(pnts) $zSensorWaveName
	Wave zSensorWave = $zSensorWaveName
	
	deflWave = NAN
	zSensorWave = NAN
	
	variable error=0
	
	string eventString = num2str(event)
	
	Variable deci = prepWavesForSC(deflWave,zSensorWave, frequency, length)
	error +=td_xSetInWavePair(Bank, eventString, deflectionChannel, deflWave, zSensorChannel, zSensorWave, callback, deci)

	if (error)
		print "Error during setup: "+num2str(error)
	endif


End

Function cleanWavesAfterSC(wave1, wave2)

	wave wave1, wave2
	
	//Unfilled values should be nans at this point, lets get rid of them first.
	waveTransform/O zapNans wave1
	waveTransform/O zapNans wave2
	
	Variable size1 = dimsize(wave1, 0)
	Variable size2 = dimsize(wave2, 0)
	
	string minWave = "wave1"
	Variable newSize = min(size1,size2)
	if (newSize != size1)
		minWave = "wave2"
	endif
	
	
	newSize -= 32 - ((32-mod(newSize,32))*(!!mod(newSize,32)))
	
	strSwitch(minWave)
		case "wave1":
		
			copyScales/P wave1, wave2
		
			break
			
		case "wave2":
		
			copyScales/P wave2, wave1
			
			break
	
	EndSwitch

End

//Rewrites the wave with an identical one which has the appropriate numPnts and scaling
//Returns the needed interpolation value for output at 50kHz
Function prepWaveForOutput(outWave)
	
	Wave outWave
	
	//Get the total time of the output wave
	variable totalTime = pnt2x( outWave, dimsize(outWave,0) -1 ) - pnt2x( outWave, 0 )
	
	//Determine what interpolation will be neccessary for 87380 pnts at 50000
	variable maxPnts = 87380
	variable interpValue = ceil( totalTime / (maxPnts / 50000) )
	
	//Make the new wave
	variable outRate = floor( 50000 / interpvalue )
	variable nonRoundedOutRate = 50000 / interpvalue
	variable newSize = ceil(totalTime*nonRoundedOutRate)+1
	Make/O/N=(newSize) tempOutwave
	
	//Copy the y scaling and re-do the x scaling
	copyScales/P outWave, tempOutWave
	setScale/P x, 0, 1/outRate, "s", tempOutWave
	
	//Check that size is ok
	variable newLastX = pnt2x( tempoutWave, dimsize(tempOutWave,0)-1 )
	variable oldLastX = pnt2x( outWave, dimsize(outWave,0)-1 )
	
	if (newLastX > oldLastX)
		redimension/N=(dimsize(tempoutWave,0)-2) tempOutWave
	endif
	
	
	//Put y values in the new wave
	tempOutWave = outWave(x)
	
	//Overwrite the original
	duplicate/O tempOutWave outWave
	killWaves tempOutWave
	
	return interpValue

End

//This code is to fix feedback loops on AR16. I needed to alter V14 to get this to compile.
//If this doesn't compile, open ARStructures.ipf, go to Structure ARFeedbackStruct, and add
//Variable dontSwapToBackpack
Function fixFeedback(FB)

	struct ARFeedbackStruct &FB
	
	string fullVersion = versionString()
	string mainVersionNumber = fullVersion[0,2]
	
	if (stringMatch(mainVersionNumber, "16"))
		FB.DontSwapToBackPack = true
	endif
	
End

//Version safe version of writePIDSloop
function vs_SetPISLoop(whichLoop,eventString,inChannelString,setpoint,pgain,igain,sgain,outChannelString,OutputMin,OutputMax,[LoopName,setpointOffset,dynamicSetpoint])
	variable whichLoop, setpoint, pgain, igain, sgain, setPointOffset,dynamicSetpoint
	string eventString, inChannelString, outChannelString
	Variable outputMin, OutputMax
	String LoopName
	
//	print "Settings PISLoop"
	
	if (ParamIsDefault(LoopName))
		LoopName = ReplaceString(".",outChannelString,"")+"Loop"
	endif
	
	Struct ARFeedbackstruct FB
		
	string fullVersion = versionString()
	string mainVersionNumber = fullVersion[0,1]
	
	if (stringMatch(mainVersionNumber, "16"))
		FB.DontSwapToBackPack = 1
	endif
	
	if (paramIsDefault(DynamicSetpoint))
		dynamicSetpoint=0
	endif
	
	FB.DynamicSetpoint = dynamicSetpoint
	
	FB.Input = InChannelString
	FB.Output = OutChannelString
	FB.Setpoint = Setpoint
	FB.pGain = PGain
	FB.IGain = IGain
	FB.sGain = sGain
	FB.DGain = 0
	FB.SetpointOffset = setpointOffset
	FB.StartEvent = StringFromList(0,EventString,",")
	FB.StopEvent = StringFromList(1,EventString,",")
	if (!Strlen(FB.StopEvent))
		FB.StopEvent = "Never"
	endif
	FB.outputMax = OutputMax
	FB.OutputMin = OutputMin
	FB.LoopName = LoopName
	FB.Bank = WhichLoop
	
	String ErrorStr = vs_WritePIDSloop(FB)
//	print "Error in writePIDSLoop: "+errorstr
	ARReportError(ErrorStr)
	return(str2num(ErrorStr))
end //vs_setPISLoop


Function/S vs_WritePIDSloop(FB)
	Struct ARFeedbackStruct &FB
	
	string fullVersion = versionString()
	string mainVersionNumber = fullVersion[0,1]
	
	if (stringMatch(mainVersionNumber, "16"))
		FB.DontSwapToBackPack = 1
	endif
	
	return IR_writePIDSLoop(FB)

End //vs_writePIDSLoop



Function viewEL()

	wave/T el = getCryptidSettings(1,setting="ExperimentLog")

	edit el

End

//Duplicates and returns the new wave while redimensioning the OG if it exists
Function/Wave safeDuplicate(this, intoThis,[startX,EndX,startPnt,endPnt])

	Wave this
	string intoThis
	Variable startX,endX,startPnt,EndPnt
	
	if (paramIsDefault(startPnt))
		startPnt=0
	endif
	if (paramIsDefault(endPnt))
		endPnt=dimsize(this,0)-1
	endif
	
	if (!paramIsDefault(startX))
		startPnt = x2pnt(this,startX)
	endif
	if (!paramIsDefault(endX))
		endPnt = x2pnt(this,endX)
	endif
	
	//	Wave newWave = $intoThis
	if (waveExists( $intoThis))
		redimension/N=0 $intoThis
	endif
	
	duplicate/O/R=[startPnt,EndPnt] this $intoThis
	
	return $intoThis
	
End

//Returns the time at which the zSensor contacted the surface
Function contactTime(zSensor)

	Wave zSensor
	WaveStats/Q zSensor

	Variable returnValue = v_maxLoc
	killWaveStats()
	return v_maxLoc
End

Function/Wave getApproachForce(force,zSensor)

	Wave force, zSensor
	
	Variable ct = contactTime(zSensor)
	String forceWaveName = nameOfWave(force)
	duplicate/O/R=(0,ct) force $forceWaveName+"_app"
	
	wave approach = $forceWaveName+"_app"
	
	return approach

End

Function/Wave getApproachZSensor(zSensor)

	Wave zSensor
	
	Variable ct = contactTime(zSensor)
	String zSensorWaveName = nameOfWave(zSensor)
	duplicate/O/R=(0,ct) zSensor $zSensorWaveName+"_app"
	
	wave approach = $zSensorWaveName+"_app"
	
	return approach

End

Function quickCapture(channelStringA, waveNameA, channelStringB, waveNameB, length, frequency, [callback, whichBank, event, eventString, dontExecute])

	string channelStringA, waveNameA, channelStringB, waveNameB, callback, event, eventString
	variable length, frequency, whichBank, dontExecute
	
	if (paramIsDefault(callback))
		callback = "print \"Quick Capture Done\" "
	endif
	if (paramIsDefault(whichBank))
		whichBank = 0
	endif
	if (paramIsDefault(event) && paramIsDefault(eventString))
		eventString="0"
		event = "0"
	elseif (paramIsDefault(eventString))
		eventString=event
	endif
	
	
	if (paramIsDefault(dontExecute))
		dontExecute = 0
	endif
	
	//reset filter frequencies
	td_WV("Cypher.Input.FastA.filter.freq",25000)
	td_WV("Cypher.Input.FastB.filter.freq",25000)
	
	Variable decimation = ARGetDeci(frequency)
	Variable pnts = length*frequency
	
	Make/O/N=(pnts) $waveNameA
	Wave waveA = $waveNameA
	
	WaveA = NAN
	variable error=0
	
	if (!stringMatch(waveNameB,""))
		Make/O/N=(pnts) $waveNameB
		Wave waveB = $waveNameB
		WaveB = NAN
		
		Variable deci = prepWavesForSC(waveA,WaveB, frequency, length)
		 error += td_xSetInWavePair(whichBank, eventString, channelStringA, waveA, channelStringB, waveB, callback, deci)
	else
		deci = prepWaveForSC(waveA, frequency, length)
		error +=td_xSetInWave(whichBank, eventString, channelStringA, waveA, callback, deci)
	endif
	if (!DontExecute)
		error +=td_WS("Event."+eventString,"Once")
	endif

	if (error)
		print "Error during setup: "+num2str(error)
	endif

End

Function/Wave defl2Force(deflection)

	wave deflection
	
	variable offset = deflection[0]
	variable invols = GV("invols")
	variable sc = GV("springConstant")
	variable combo = invols*SC
	
	duplicate/o deflection force
	force = (deflection - offset) * combo

	return force
End

//To get the invols from previous force ramps. Used in the "Function Call" step. To ues, load the Calibration saved package
//DOESNT WORK RN
Function cryptidInvols()

	//How many FR did we run?
	//Repeat should be the step before
	variable repeatStep = getCurrentStepNumber()-1
	wave repeatSettings = getCryptidSettings(0,stepNum=repeatStep)
	variable repeats = repeatSettings[%numberOfRepeats]
	
	make/O/N=(repeats) involsWave
	
	Variable maxIter = repeats
	Variable i
	for(i=0;i<maxIter;i+=1)
		//Get the waves
		string saveName = "involsRamp"
		if (i>0)
			saveName = saveName+"_R_"+num2str(i)
		endif
		
		Wave deflVolts = getWaveFromRun(saveName, 1)
		Wave zSensorVolts = getWaveFromRun(saveName, 1)
	endFor
	
	

End

//NEED TO TEST THESE INDEPENDENTLY
//Sets up a fast capture of the given length and captureRate
//CaptureRate MUST BE 5e6 || 20e6 ||80e6
//Wave name will always be fastCaptureData
Function setupFastCapture(recordTime, captureRate)

	Variable recordTime, captureRate

	//Setup FC acquisition:
	Variable FC_numpnts = (floor(recordTime*captureRate))
	FC_numpnts += (32-mod(FC_numpnts,32))*(!!mod(FC_numpnts,32))
	
	Variable captureNumber
	switch (captureRate)
		case 80e6:
			captureNumber = 0
			break
		case 20e6:
			captureNumber = 1
			break
		case 5e6:
			captureNumber = 2
			break
		default:
			CryptidDebug(diagString="Invalid capture rate", alwaysPrint=1, alert=0, updateDisplay=0)
	endSwitch
	
	td_WV("Cypher.Capture.0.Rate", captureNumber)
	
	
	td_WV("Cypher.Capture.0.Length", FC_numpnts)

End

Function executeFastCapture()

	//Actually start the acquisition
	td_WV("Cypher.Capture.0.Trigger", 1)
	
End

Function pullFastCapture(callback, waveloc)

	string callback, waveLoc
	
	Wave FCD = $waveLoc
	if (waveExists(FCD))
		killWaves FCD
	endif
	
	Make/O/N=0 $waveLoc //Can be 0 I guess?
	Wave FCD = $waveLoc
	td_ReadCapture("Cypher.Capture.0", FCD, callback) 

End

Function saveFastCapture(FCWave, saveName, iteration)

	Wave FCWave
	string saveName
	variable iteration
	
	variable combo = GV("Invols")*(GV("SpringConstant")
	FastOp FCWave = (combo)*FCWave
	string addNote = cryptidGenerateNote()
	note FCWave, addNote
	saveName = saveName + "_FC_"+num2str(iteration)


	save/C/O/P=$"SaveForce" FCWave as saveName+".ibw"

End

Function driftRateMonitor([update, channel, length])

	Variable update, length
	
	string channel
	if (paramIsDefault(channel))
		channel = "deflection"
	endif
	if (paramIsDefault(length))
		length = 20
	endif
	
	Make/O/N=1 driftRateWave = 0
	
	if (!update)
		liveDeflection(length = length,callback="driftRateMonitor(update=1)", channel ="Deflection")
		appendToGraph/C=(0,0,0)/R driftRateWave
		Label right "Drift (pN/sec)"
	else
		Wave defl = root:LiveDeflectionWave
		Wave force = defl2force(defl)
		
		SetScale /P x, 0, 1/50000, force
		CurveFit/Q/M=2/W=0 line, force
		Wave W_coef
		
		Variable driftRate = W_coef[1]
		Variable pNperSecond = driftRate * 10^12
		Variable secondsPerPN = pNPerSecond^-1
		
		driftRateWave[0] = pNPerSecond
		//print "Drift Rate   : "+num2str(pNPerSecond) + " pN/sec"
		//print "Sec per pN: "+num2str(secondsPerpN) + "sec/pN"
	endif
End

Function liveDeflection([windowToDisplay, callback,length, channel])

	string windowToDisplay
	string callback, channel
	Variable length
	
	SVAR liveWindowName
	if(!SVAR_Exists(liveWindowName))
		string/G liveWindowName
	endif
	
	if (paramIsDefault(windowToDisplay))
		windowToDisplay = "driftWindow"
	endif
	
	liveWindowName = windowToDisplay
	
	if (paramIsDefault(callback))
		callback = ""
	endif
	if (paramIsDefault(length))
		length = 10
	endif
	
	if (paramIsDefault(channel))
		channel = "deflection"
	endif
	
	wave LiveDeflectionWave = root:LiveDeflectionWave
	if(waveExists(liveDeflectionWave))
		killWaves/Z liveDeflectionWave
	endif
	
	Make/O root:LiveDeflectionwave
	
	quickCapture(channel, "root:LiveDeflectionWave", "", "", length, 50000, callback = callback, whichBank = 2, eventString="12,12",dontExecute=1)
	td_WS("Event.12","Set")
	

	
	if(windowExists(windowToDisplay))
		appendToGraph/W=$windowToDisplay root:LiveDeflectionWave
	else	
		display/K=1/N=$windowToDisplay root:LiveDeflectionWave
		Label left "Deflection"
	endif
		
	
	ARBackground("backgroundUpdateGraph",100,"")
End

Function backgroundUpdateGraph()

	Variable stop
	
	SVAR liveWindowName
	
	if(windowExists(liveWindowName))
		wave liveDeflection = root:LiveDeflectionWave
		liveDeflection[0] += 0
		stop = 0
	else
		stop = 1
		print "Live Deflection done..."
		endLiveDeflection()
	endif
	
	return stop
End

Function endLiveDeflection()

	td_WS("Event.12","Clear")
	ir_stopLinearCombo("LiveDeflection")
	ARBackground("backgroundUpdateGraph",0,"")

End

Function setSpringConstant(SC)

	variable SC
	
	PVU("DisplaySpringConstant",1)
	CallSetVarFunc(ForceSetvarFunc,"DisplaySpringConstantSetVar_1",SC/1e9,"",":MasterVariablesWave[%DisplaySpringConstant]")	//enter the new calculated value of k, converting to nN/nM

End



//This makes a stacked plot (wl is wave list)
Function stackedPlot(wl)

	string wl
	make/O/N=1 tempWave
	variable numPlots = itemsInList(wl)
	
	Wave tempWave = $"tempWave"
	if (!stringMatch("", stringFromList(0,wl)))
		Wave tempWave = $stringFromList(0,wl)
	endif
	
	display tempWave
	Label Left nameOfWave(tempWave)
	
	Variable gap = 0.02 
	Variable size = 1 / numPlots - gap/2
	string axisName
	
	//Resize the first one
	ModifyGraph axisEnab(Left)={0,size}
	
	Variable i
	for(i=1;i<numPlots;i+=1)
		axisName = "L"+num2str(i)
		
		Wave tempWave = $"tempWave"
		if (!stringMatch("", stringFromList(i,wl)))
			Wave tempWave = $stringFromList(i,wl)
		endif
		appendToGraph/L=$axisname tempWave
	
		ModifyGraph axisEnab($axisName)={(size+gap/2)*i,(size+gap/2)*i+size},freePos($axisName)=0		
		Label $axisName nameOfWave(tempWave)
		
	endFor 
	

End

//Checks the multiplier for the outzmod, outxmod, outymod (some are 15, some are 1) and returns it
//Should be used to multipliy the ZPiezoSens for the channel ( outZModSens = ZPiezoSens*outModMultiplier())
Function OutModMultiplier()

	string multString = td_RS("XYZModulationGains")
	variable multValue = str2num( multString[0,strlen( multString ) - 2] )
	
	return multValue
End

Function getCoarseSpotNumber()

	wave settings = root:Settings:SearchGrid:searchSettings
	return settings[%coarseSpotNumber]

End

//The next couple functions are to automate updating a panel macro
//Since the default way is complicated

//Function to input a window macro and remove all absolute references from it
Function/S purgeAbsoluteRef(Functext)

	string Functext
	//string funcText = procedureText(macroName)
	
	//Determine target string
	variable beginTarget = strSearch(funcText,"root:",0)
	variable endTarget = strSearch(funcText,"\r",beginTarget)
	endTarget = strSearch(funcText,":",endTarget,1)
	
	string purgeString = funcText[beginTarget,endTarget]
	//Remove purgeString from the text
	string newText = replaceString(purgeString, funcText,"")
	
	return newText
End

//Must be run AFTER poping out panel
Function/S savePanelUpdates()

	string expType = getStepType(Stepnum=getSelectedStep())
	wave/t experimentExecutables = getCryptidSettings(1,setting="experimentExecutables")
	
	string panelFuncName = experimentExecutables[%$expType][%PanelFunction]
	string currentText = procedureText(panelFuncName)

	//Get everything up until ModifyPanel
	variable modPanelLoc = strSearch(currentText,"ModifyPanel",0)
	variable endLoc = strSearch(currentText,"\r",modPanelLoc,1)
	
	string newFuncString = currentText[0,endLoc]
	
	//Now grab the text from the recreation window
	
	//The window name should be the same as in the text above	
	string fullWindowRecreate = winRecreation("",0)
	
	//Get everything after and including ModifyPanel
	modPanelLoc = strSearch(fullWindowRecreate,"ModifyPanel",0)
	variable startLoc = strSearch(fullWindowRecreate,"\r",modPanelLoc,1)

	newFuncString += "\r"+fullWindowRecreate[startLoc,inf]
	
	//Last, change ending from endMacro to end
	newFuncString = replaceString("endMacro",newFuncString, "End")
	
	newFuncString = purgeAbsoluteRef(newFuncString)
	
	putScrapText(newFuncString)
	
	doAlert 0, "Function definition copied to clipboard. Replace function in procedure window"
	
	displayProcedure panelFuncName
End
