#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=3.1
//#include "::Force-Ramp:ForceRamp",version>=2
//#include  "::Cypher-Utilities:ClosedLoopMotion"
//#include "::Cypher-Utilities:SearchForMolecules"
//#include "::General-Igor-Utilities:WaveDimNote"
//BDEdit
//#include "::Cypher-Utilities:BDExperimentInfo"

// BD Panel to enter experiment info. This info will be added to the note.
//TO USE: Fill out form in panel and insert "addedNote += ExperimentInfoNote()" into your code where "addedNote" is your current note to be added.
//Then use SaveAsAsylumForceRamp with the optional parameter additinalNotes = addedNote
 
 
//Menu "Experiment Info"
//	"Experiment Info", InitializeExperimentInfo()
//End 

Function InitializeExperimentInfo()

	NewDataFolder/O root:Settings:ExperimentInfo
	SetDataFolder root:Settings:ExperimentInfo
	
	loadCryptidSettings("ExperimentInfo","ExperimentTemplate;ExperimentTemplateQuickSelect")
	
//	NewPath/Q/O ExperimentInfoParms ParseFilePath(1, FunctionPath(""), ":", 1, 0) +"Parms"
//	LoadWave/H/Q/O/P=ExperimentInfoParms "ExperimentTemplate.ibw"	
//	LoadWave/H/Q/O/P=ExperimentInfoParms "ExperimentTemplateQuickSelect.ibw"	
	
	//I REALLY don't understand why this is needed
	Variable/G QSCount = -1
	
//	Execute/Q "experimentInfoPanel()"

End

Function/S ExperimentInfoNote()

	String addedNote = ""
	Wave/T ExpInfo = root:Settings:ExperimentInfo:ExperimentTemplate
	
	//Notes from settings
	Variable i
	for(i=0;i<dimsize(ExpInfo,0);i+=1)
		addedNote = ReplaceStringbyKey(GetDimLabel(expInfo, 0, i),AddedNote, expInfo[i],":","\r")
	endfor
	
	//Other Notes
	addedNote =  ReplaceStringbyKey("Temperature",AddedNote, num2str(GV("EnvironSampleTemp")),":","\r")

	return AddedNote

End

Window experimentInfoPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /K=1 /W=(1680,58,1974,339) as "Experiment Info"
	ModifyPanel cbRGB=(52224,52224,52224)
	ShowTools/A
	TitleBox experimentInfoTB,pos={6,10},size={115,21},title="Experiment Information"
	PopupMenu molecule,pos={6,40},size={74,22},proc=experimentInfoPopup,title="Molecule: "
	PopupMenu molecule,mode=1,popvalue="",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%Molecule][%Options]"
	PopupMenu ExperimentType,pos={6,70},size={107,22},proc=experimentInfoPopup,title="ExperimentType: "
	PopupMenu ExperimentType,mode=1,popvalue="",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%ExperimentType][%Options]"
	PopupMenu TipChemistry,pos={6,100},size={88,22},proc=experimentInfoPopup,title="TipChemistry "
	PopupMenu TipChemistry,mode=1,popvalue="",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%TipChemistry][%Options]"
	PopupMenu SurfaceChemistry,pos={6,130},size={113,22},proc=experimentInfoPopup,title="SurfaceChemistry: "
	PopupMenu SurfaceChemistry,mode=1,popvalue="",value= #"root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect[%SurfaceChemistry][%Options]"
	SetVariable TotalPEGLength,pos={6,160},size={140,16},title="TotalPEGLength: "
	SetVariable TotalPEGLength,value= root:Settings:ExperimentInfo:experimentTemplate[%totalPEGLength]
	SetVariable TotalContourLength,pos={6,190},size={140,16},title="TotalContourLength: "
	SetVariable TotalContourLength,value= root:Settings:ExperimentInfo:experimentTemplate[%TotalContourLength]
	SetVariable Cantilever,pos={6,220},size={140,16},title="Cantilever: "
	SetVariable Cantilever,value= root:Settings:ExperimentInfo:experimentTemplate[%Cantilever]
	SetVariable surfaceDensity,pos={6,250},size={140,16},title="Surface Density: "
	SetVariable surfaceDensity,limits={-inf,inf,0},value= root:Settings:ExperimentInfo:experimentTemplate[%surfaceDensity]
EndMacro

//Function  ExpInfoMakeQuickSelect(start)

//	Variable start
	
//	Wave/T ExpTempQuickSel = root:ExperimentInfo:ExperimentTemplateQuickSelect
//	Wave/T ExpTemp = root:ExperimentInfo:ExperimentTemplate
//	String name = ""
//	Variable iter
//	for(iter=0;iter<dimsize(ExpTempQuickSel,0);iter+=1)
//		name = getDimLabel(ExpTempQuickSel, 0, iter)
		//If it needs quick select make it, else link directly to the experimentTemplate wave
//		if ((cmpstr(ExpTempQuickSel[iter][%options],"") ==0) || strlen(ExpTempQuickSel[iter][%options]) == NAN )
//			setVariable $name, pos={6,start+30*iter},size={140,20}, title=name, Value=root:ExperimentInfo:ExperimentTemplate[iter]
//		else	
//			popupMenu $name, pos={6,start+30*iter},size={140,20}, title=name, Value=root:ExperimentInfo:ExperimentTemplateQuickSelect[%$name][%Options],proc=experimentInfoPopup
//		endif
//	endfor
	
//	popupMenu molecule,pos={6,40},size={140,20},			title="Molecule:               ",  Value=root:ExperimentInfo:ExperimentTemplateQuickSelect[%Molecule][%Options],proc=experimentInfoPopup
//	popupMenu ExperimentType,pos={6,70},size={140,20},	title="ExperimentType:     ",  Value=root:ExperimentInfo:ExperimentTemplateQuickSelect[%ExperimentType][%Options],proc=experimentInfoPopup
//	popupMenu TipChemistry,pos={6,100},size={140,20},		title="TipChemistry:         ",  Value=root:ExperimentInfo:ExperimentTemplateQuickSelect[%TipChemistry][%Options],proc=experimentInfoPopup
//	popupMenu SurfaceChemistry,pos={6,130},size={140,20},	title="SurfaceChemistry:  ",  Value=root:ExperimentInfo:ExperimentTemplateQuickSelect[%SurfaceChemistry][%Options],proc=experimentInfoPopup
//	SetVariable Cantilever, pos={6,160},size={140,20},		title="TotalPEGLength     ",  Value=root:ExperimentInfo:ExperimentTemplate[%Cantilever]
//	SetVariable Cantilever, pos={6,190},size={140,20},		title="Cantilever:              ",  Value=root:ExperimentInfo:ExperimentTemplate[%totalPEGLength]
	
	
//	return start+30*iter
	

//End

//Function/S quickSelectValue()
	
//	Wave/T ExpTempQuickSel = root:ExperimentInfo:ExperimentTemplateQuickSelect
//	NVAR QSCount = root:ExperimentInfo:QSCount
//	print qsCount
//	return ExpTempQuickSel[QSCount][%options]

//End


Function experimentInfoButton(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	String ButtonName=ba.CtrlName
	

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			strswitch(ButtonName)

			EndSwitch

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function experimentInfoPopup(ba) : PopupMenuControl
	STRUCT WMPopupAction &ba
	String popupName=ba.CtrlName
	String popupValue=ba.Popstr
	
	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			Wave/T ExperimentTemplate = root:Settings:ExperimentInfo:ExperimentTemplate

			if (stringMatch(popupValue,"New"))
				expInfoNewValue(popupName)
			elseif(stringMatch(popupValue,"Remove"))
				expInfoRemoveValue(popupName)
			else
				ExperimentTemplate[%$popupName] = popupValue
			endif
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function expInfoNewValue(valueName)

	string valueName
	Wave/T ETQS = root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect
	
	string newValue = ""
	prompt newValue,"Add new Value (no semiconlons): "
	doPrompt "Add Value", newValue
	if(v_flag)
		return 1
	endif
	string currentValue = ETQS[%$valueName][%Options]
	
	ETQS[%$valueName][%Options] = currentValue+newValue+";"//currentValue[0,strlen(currentValue)-5] + newvalue +";" + currentValue[strlen(currentValue)-5,strlen(currentValue)-1]

	//NewPath/Q/O ExperimentInfoParms ParseFilePath(1, FunctionPath(""), ":", 1, 0) +"Parms"
	NewPath/Q/O ExperimentInfoParms getCryptidPath("Packages:ExperimentInfo:Settings")
	Save/O/P=ExperimentInfoParms ETQS as "ExperimentTemplateQuickSelect.ibw"


end

Function expInfoRemovevalue(valueName)

	string valueName
	
	Wave/T ETQS = root:Settings:ExperimentInfo:ExperimentTemplateQuickSelect
	
	string removeValue
	prompt removeValue, "Remove which option?", popup, ETQS[%$valueName]
	doPrompt "Remove", removeValue			
	if(v_flag==1)
		return 1	
	endif
	
	ETQS[%$valueName] = removeFromList(removeValue,ETQS[%$valueName])
	

	//NewPath/Q/O ExperimentInfoParms ParseFilePath(1, FunctionPath(""), ":", 1, 0) +"Parms"
	NewPath/Q/O ExperimentInfoParms getCryptidPath("Packages:ExperimentInfo:Settings")
	Save/O/P=ExperimentInfoParms ETQS as "ExperimentTemplateQuickSelect.ibw"


End


Function experimentInfoCheckBox(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			String CheckBoxName=cba.ctrlName
			Strswitch(CheckBoxName)
				
				break
			EndSwitch
			

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End
