#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//TIP: Copy this file into the desired package folder, rename it to your package name,
//Then run ctrlF and use ctr+V to replace "Example" with you actual package name


//************EXECUTE COMMAND*************
//This is a wrapper function for cryptid to call
//Put the name in the executables file
Function cryptidExecutezRamp()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	DozRamp(vSettings,tSettings)
	

End


//This is the actual function that does things. This stucture is so you can pass
//Around the settings files, hopefully making the program work outside of cryptid
Function DozRamp(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings
	
	Variable Error=0
	
	//We need to set up an event. Best to put this in your settings and set a default value
	String EventString=num2str(vSettings[%eventEnable])
	
	//Clear the event we are going to use
	Error += td_WS(EventString,"Clear")
	
	//Here we set up and load/change any ARC/Cypher parameters. Feedback loops, CTFCs, ect...
	Variable noFirstRamp = SetupzRampParameters(vSettings,tSettings)
	
	if(noFirstRamp)
		cryptidDebug(diagString="First ramp not found, skipping zRamp", updateDisplay=1)
		cryptidMain(1)
		return 0
	endif
	
	if (vSettings[%recordData])
		//Here we set up our inWaves. Make the waves, set up the td_xSetInWave stuff ect....
		SetupzRampData(vSettings,tSettings)
	endif
	
	//Here we execute
	ExecutezRamp(vSettings, tSettings)
End

//Here we set up any ARC/Cypher parameters
Function setupzRampParameters(vSettings,tSettings)

	wave vSettings
	wave/t tSettings
	
	cryptidDebug()
	
	variable fail = 0
	
	// Import Existing CTFC Parms
	Make/O/T CTFCParams
	Variable error=0
	error+=td_ReadGroup("ARC.CTFC",CTFCParams)
	
	//Calculate voltages and values
	Variable rampSlope1 = vSettings[%rampSpeed]/GV("ZPiezoSens")
	
	Variable TriggerValue1
	Variable currentLocV = td_RV("Cypher.LVDT.Z")
	if (vSettings[%fromCurrentLocation])
		TriggerValue1 = currentLocV - vSettings[%distance]/GV("ZLVDTSens")
	elseif(vSettings[%useForce])
		TriggerValue1 = getSurfaceVoltageForceOffset(vSettings[%ForceOffset])
	else
		//Go above this surface that amount
		variable surfaceVoltage = getSurfaceVoltage()
		if (surfaceVoltage == -1)
			fail = 1
		endif
		TriggerValue1 = getSurfaceVoltage() - abs(vSettings[%distance]/GV("ZLVDTSens"))
	endif
	
	Variable direction = sign(TriggerValue1 -currentLocV)
	
	CTFCParams[%RampChannel] = "Output.Z"
	
	if (direction == 1)
		Variable RampOffset = 160
		String triggerCompare1 = ">="
	else
		RampOffset = -10
		triggerCompare1 = "<="
	endif
	
	CTFCParams[%RampOffset1] = num2str(rampOffset)
	
	CTFCParams[%RampSlope1] =  num2str(direction *rampSlope1)
	CTFCParams[%RampOffset2] = "0"
	CTFCParams[%RampSlope2] = "0"
	CTFCParams[%TriggerChannel1] = "Cypher.LVDT.Z"
	CTFCParams[%TriggerType1] = "Absolute"
	CTFCParams[%TriggerValue1] = num2str(TriggerValue1)
	CTFCParams[%TriggerCompare1] = triggerCompare1
	CTFCParams[%TriggerChannel2] = "output.Dummy"
	CTFCParams[%TriggerHoldoff2] = "0"
	CTFCParams[%DwellTime1] = "0"
	CTFCParams[%DwellTime2] = "0"
	CTFCParams[%Callback] = "zRampCallback1("+getWavesDataFolder(vSettings,2)+","+getWavesDataFolder(tSettings,2)+")"
	CTFCParams[%EventDwell] = "14"
	CTFCParams[%EventRamp] = "14"
	CTFCParams[%EventEnable] = num2str(vSettings[%eventEnable])
	
	
	td_StopOutWaveBank(-1)
	
	
	string ErrorStr = num2str(td_writeGroup("ARC.CTFC",CTFCParams))+","
	cryptidDebug(diagString="Error in writing ARC.CTFC: "+errorStr, alwaysPrint=str2num(errorStr))

	return fail
End //SetupForceRamp


//Here we set up our data recording
//I've left this example from the package "Dwell" as a good example.
Function SetupzRampData(vSettings,tSettings)

	Wave vSettings
	Wave/t tSettings
	
	cryptidDebug()
	
	Wave/T CTFCParams
	Variable sampleRate = vSettings[%sampleRate]
	Variable rampSpeed = str2num(CTFCParams[%rampSlope1])

	Variable triggerValue1 = str2num(CTFCParams[%triggerValue1])
	Variable rampDistance = TriggerValue1 - td_RV("Cypher.LVDT.Z")
	
	make/O/N=1 zSensorVolts
	make/O/N=1 DeflVolts
	
	Variable deci = prepWavesForSC(zSensorVolts, DeflVolts, sampleRate, abs(rampDistance / rampSpeed))
	
	//get the Event we set up earlier
	String eventString = num2str(vSettings[%eventEnable])+",Never"
	String deflectionChannel = tSettings[%deflectionChannel]
	
	
	//Callback is handled by the CTFC in this case
	String callback = ""
	
	Variable bank = vSettings[%SCbank]
	td_stopInWaveBank(bank)
	td_XSetInWavePair(bank,EventString,deflectionChannel,DeflVolts,"Cypher.LVDT.Z",zSensorVolts,callback,deci)


End

//This function actually starts the program, usually through td_WS
Function ExecutezRamp(vSettings,tSettings)

	Wave/t tSettings
	wave vSettings
	
	String EventString="Event."+num2str(vSettings[%eventEnable])
	
	//Actually execute the thing
	td_WS(EventString,"Once")	

End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makezRampSettings()
	
	String packageName = "zRamp"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End


//Called at the end of you function. Must call cryptid back from here.
Function zRampCallback1(vSettings,tSettings)

	Wave/T tSettings
	Wave vSettings
	
	td_WS("Event."+num2str(vSettings[%eventEnable]),"Clear")	
	td_stopinwavebank(vSettings[%SCBank])
	
	//TEMPORARY TO RE GET ZERO CLOSE TO SURFACE
	
	if (vSettings[%recordData])
		Wave deflVolts
		Wave zSensorVolts
		cleanWavesAfterSC(DeflVolts, zSensorVolts)
		//Update graph of Cryptid to show your data (doesn't save)
		updateCryptidGraph(deflvolts=deflVolts,zSensorVolts=zSensorVolts)

		cryptidMain(1, deflVolts=deflVolts, zSensorVolts = zSensorVolts)
	else
	
		if(vSettings[%newZero])
		
			string callback = "cryptidMain(1)"
			getNewDeflVOffset(callback)	
	
		else
			cryptidMain(1)
		endif
		
	endif

End

//Cryptid calls this function by passing its own values to panelName, widowName, and hostName
//This function is written so that if you call it with defaults, it will make its own window
//I highly recommend copying large parts of this function, and just replacing that last part
// 
//For easiest modification, make your panel using the graphical tools for panel making,
//Save it, and then copy the control's code to the bottom of this function
//You will need to replace all values to vSettings,tSettings instead of absolute paths to 
//make it work (I.E.): value=root:Settings:ExamplePackage:vSettings[%someValue] will need to be changed
//to 						value=vSettings[%someValue] to work with cryptid
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakezRampPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="zRampPanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="zRampWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif




	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	TitleBox ZRampTitle,pos={107,11},size={73,24},title="Z Ramp",fSize=18,frame=0
	TitleBox ZRampTitle,fStyle=1
	SetVariable FREventEnable,pos={10,514},size={207,16},title="Event Enable"
	SetVariable FREventEnable,value= vSettings[%eventEnable]
	SetVariable RampSpeed,pos={9,55},size={261,16},title="Ramp Speed"
	SetVariable RampSpeed,format="%.1W1Pm/s"
	SetVariable RampSpeed,value= vSettings[%RampSpeed]
	SetVariable Distance,pos={9,101},size={261,16},title="Distance"
	SetVariable Distance,help={"Distance either from the current location (0) (+ direction increases seperation) or above the surface (1)"}
	SetVariable Distance,format="%.1W1Pm"
	SetVariable Distance,value= vSettings[%distance]
	SetVariable RecordData,pos={9,182},size={90,16},title="Record Data"
	SetVariable RecordData,help={"Save the data?"}
	SetVariable RecordData,limits={0,1,1},value= vSettings[%recordData]
	SetVariable SampleRate,pos={27,209},size={243,16},title="SampleRate"
	SetVariable SampleRate,format="%.1W1PHz"
	SetVariable SampleRate,value= vSettings[%SampleRate]
	SetVariable DeflectionChannel,pos={27,227},size={243,16},title="Defl Channel"
	SetVariable DeflectionChannel,value= tSettings[%deflectionChannel]
	SetVariable SCBank,pos={10,541},size={207,16},title="SC Bank"
	SetVariable SCBank,value= vSettings[%SCBank]
	SetVariable FromCurrentLocation,pos={9,81},size={144,16},title="From Current Location"
	SetVariable FromCurrentLocation,help={"If yes, will ramp from the current location (+ increases distance from surface). If no, will ramp to this distance above the surface"}
	SetVariable FromCurrentLocation,limits={0,1,1},value= vSettings[%fromCurrentLocation]
	SetVariable Force,pos={9,146},size={261,16},title="Force"
	SetVariable Force,help={"Distance either from the current location (0) (+ direction increases seperation) or above the surface (1)"}
	SetVariable Force,format="%.1W1PN"
	SetVariable Force,value= vSettings[%ForceOffset]
	SetVariable UseForceTitle,pos={9,126},size={144,16},title="Use Force"
	SetVariable UseForceTitle,help={"This option will ramp to a specific force, relative to zero. If you want to ramp to a relative force, use a force ramp"}
	SetVariable UseForceTitle,limits={0,1,1},value= vSettings[%useForce]
	SetVariable getNewZero,pos={9,252},size={90,16},title="New Zero"
	SetVariable getNewZero,help={"This option will collect a new zero at the new location. Useful if you've ramped closer/farther and need a new zero"}
	SetVariable getNewZero,limits={0,1,1},value= vSettings[%newZero]
	SetWindow kwTopWin,hook(thisPanelHook)=cryptidPanelHook
End


//Put your controls down here (setVariableControl, buttonControl, ect...)


Function zRampCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			wave vSettings
			
			Variable checked = cba.checked
			vSettings[%$cba.ctrlName] = checked
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function zRampButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
			
				case "StartDwellNow":

			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Window zRampPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(645,419,923,1130) as "zRampWindow"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	TitleBox DCEventTitle,pos={115,470},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	TitleBox ZRampTitle,pos={107,11},size={73,24},title="Z Ramp",fSize=18,frame=0
	TitleBox ZRampTitle,fStyle=1
	SetVariable FREventEnable,pos={10,514},size={207,16},title="Event Enable"
	SetVariable FREventEnable,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%eventEnable]
	SetVariable RampSpeed,pos={9,55},size={261,16},title="Ramp Speed"
	SetVariable RampSpeed,format="%.1W1Pm/s"
	SetVariable RampSpeed,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%RampSpeed]
	SetVariable Distance,pos={9,101},size={261,16},title="Distance"
	SetVariable Distance,help={"Distance either from the current location (0) (+ direction increases seperation) or above the surface (1)"}
	SetVariable Distance,format="%.1W1Pm"
	SetVariable Distance,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%distance]
	SetVariable RecordData,pos={9,182},size={90,16},title="Record Data"
	SetVariable RecordData,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%recordData]
	SetVariable SampleRate,pos={27,209},size={243,16},title="SampleRate"
	SetVariable SampleRate,format="%.1W1PHz"
	SetVariable SampleRate,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%SampleRate]
	SetVariable DeflectionChannel,pos={27,227},size={243,16},title="Defl Channel"
	SetVariable DeflectionChannel,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:tSettings[%deflectionChannel]
	SetVariable SCBank,pos={10,541},size={207,16},title="SC Bank"
	SetVariable SCBank,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%SCBank]
	SetVariable FromCurrentLocation,pos={9,81},size={144,16},title="From Current Location"
	SetVariable FromCurrentLocation,help={"If yes, will ramp from the current location (+ increases distance from surface). If no, will ramp to this distance above the surface"}
	SetVariable FromCurrentLocation,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%fromCurrentLocation]
	SetVariable Force,pos={9,146},size={261,16},title="Force"
	SetVariable Force,help={"Distance either from the current location (0) (+ direction increases seperation) or above the surface (1)"}
	SetVariable Force,format="%.1W1PN"
	SetVariable Force,value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%ForceOffset]
	SetVariable UseForceTitle,pos={9,126},size={144,16},title="Use Force"
	SetVariable UseForceTitle,help={"If yes, will ramp from the current location (+ increases distance from surface). If no, will ramp to this distance above the surface"}
	SetVariable UseForceTitle,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%useForce]
	SetVariable getNewZero,pos={9,252},size={90,16},title="New Zero"
	SetVariable getNewZero,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:ZRamp_0:vSettings[%newZero]
EndMacro
