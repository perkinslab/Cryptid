#pragma rtGlobals=1		// Use modern global access method.
#pragma version=9.2

// For version 9.2
// Adding determination of the zsensor value for "railing", i.e. when the feedback loop pushes the stage lower than 0V for Zpiezo.
// Should prevent false detection of railing the z stage when using this program on different cyphers, or after recalibration of the z stage.

//#include ":CFPReport"

//BD 2024-08-29
//Modifying to use a custom channel for the centering so we can use detrending

//NOTE: moveToNewCenterCallback is where you will find the sucess end of the function

// Initialize the centered force pull program
Function InitializeCFP([ShowUserInterface])
	
	Variable ShowUserInterface

	If(ParamIsDefault(ShowUserInterface))
		ShowUserInterface=1
	EndIf
	


	// In case we want to do a centered force clamp
//	InitializeForceClamp()
		
	// Load External Parm waves
	loadCryptidSettings("Centering","CenteringSettings;CenteredRamp_QuickSettings;CenteredRamp_Settings;CenteredRamp_WaveNames;CenteredRamp_WaveNamesQS;CenteringQuickSettings;CFPSettings;CFPQuickSettings;FirstRamp_QuickSettings;FirstRamp_Settings;FirstRamp_WaveNames;FirstRamp_WaveNamesQS;PresetPullingVelocities;",UseCurrentDF=1)

	//It just got too confusing with all of the different settings waves and names. Sorry
	String/G CFDeflectionChannel = "Deflection"

	// Make waves for circle 
	MakeCFCSettingsWave(OutputWaveName="Circle_Settings")
	MakeCFCWaveNamesCallback(OutputWaveName="Circle_WaveNames")
	Wave/T Circle_WaveNames
	Circle_WaveNames[%XSensor]="XSensorCircle"
	Circle_WaveNames[%YSensor]="YSensorCircle"
	Circle_WaveNames[%ZSensor]="ZSensorCircle"
	Circle_WaveNames[%DefV]="DefVCircle"
	Circle_WaveNames[%Callback]="CircleCallback()"

	// Make waves for moving to a point
	MakeMoveToPointCFSettingsWave(OutputWaveName="MoveToPoint_Settings")
	
	// make waves for sampling deflection and zsensor at discrete points.
	MakeSampleZWavesCallback(OutputWaveName="SampleAtPoint_WaveNames")
	MakeSampleZSettingsWave(OutputWaveName="SampleAtPoint_Settings")
	Wave/T SampleAtPoint_WaveNames
	SampleAtPoint_WaveNames[%XSensor]="XSensorPoint"
	SampleAtPoint_WaveNames[%YSensor]="YSensorPoint"
	SampleAtPoint_WaveNames[%ZSensor]="ZSensorPoint"
	SampleAtPoint_WaveNames[%DefV]="DefVPoint"
	SampleAtPoint_WaveNames[%Callback]="SampleZCallback()"

	// Make waves for fine centering cross
	MakeCFCrossSettingsWave(OutputWaveName="FineCentering_Settings")
	MakeCFCrossWaveNamesCallback(OutputWaveName="FineCentering_WaveNames")
	Wave/T FineCentering_WaveNames
	FineCentering_WaveNames[%XSensor]="XSensorFine"
	FineCentering_WaveNames[%YSensor]="YSensorFine"
	FineCentering_WaveNames[%ZSensor]="ZSensorFine"
	FineCentering_WaveNames[%DefV]="DefVFine"
	FineCentering_WaveNames[%Callback]="FineCenteringCallback()"

	

	Make/N=256/O DeflectionOffsetData	
	
	ResetCurrentDataWaves()
//	DetermineZSensorRail()
	
End // InitializeCTFC

// Found that using Z voltage output to the piezo doesn't work for determining when the z stage has railed. 
// Instead, we will determine the zsensor reading when Z piezo is set to 0 V and then use that zsensor value
// to determine if the Z stage has railed.

// EDIT: I don't know why this didn't work for rob, but I switched to using ZPiezo voltage for rails and it works fine

//Function DetermineZSensorRail()
//	Variable Error=0
//	Variable CurrentZPzt=td_rv("Output.Z")
//	Error = td_SetRamp(1, "Output.Z", CurrentZPzt, 0, "", 0, 0, "", 0, 0, "DetermineZSensorRailCallback()")
//End

//Function DetermineZSensorRailCallback()
//	Wave CFPSettings
//	CFPSettings[%ZSensorRailed]=td_rv("Cypher.LVDT.Z")
//	If(FindDimLabel(CFPSettings,0,"ZSensorRailed")==-2)
//		Print "Error: ZSensorRailed wave setting does not exist. Centering program will not work properly"
//	EndIf
//	Wave CFPQuickSettings
//	Variable QSCounter=0
//	Variable NumQS=DimSize(CFPQuickSettings,0)
//	For(QSCounter=0;QSCounter<NumQS;QSCounter+=1)
//		CFPQuickSettings[%ZSensorRailed][QSCounter]=td_rv("Cypher.LVDT.Z")
//	EndFor
//End


//  This function controls the sequence of events for the centering protocol
//  It also checks to make sure the molecule didn't detach.  If it detached, then start a new iteration.  
Function CFP_MainLoop()
	
	Wave CFPSettings
	Wave/T Centering = $getDataFolder(1)+"CenteringSettings"
	Wave Circles_X
	Wave Circles_Y
	Wave Circles_Z
	Wave XTargets
	Wave YTargets
	Wave ZTargets
//	Wave DeflTargets
	Wave XSensorCirc = $getDataFolder(1)+"XSensorCircle"
	Wave YSensorCirc= $getDataFolder(1)+"YSensorCircle"
	Wave ZSensorCirc= $getDataFolder(1)+"ZSensorCircle"
	Wave Defl_VoltsCirc= $getDataFolder(1)+"DefVCircle"

	Variable XCurrentPosition_Volts = td_rv("Cypher.LVDT.X")
	Variable YCurrentPosition_Volts = td_rv("Cypher.LVDT.Y")
	Variable ZCurrentPosition_Volts= td_rv("Cypher.LVDT.Z")
	
	// Check to see if zsensor has railed.  Probably means the molecule has disconnected.
	
	//Why use zLVDT? Just check the piezo
	Variable zPiezo = td_RV("Output.Z")
	If ((zPiezo <0)&&!(StringMatch(Centering[%State],"FirstRamp")))
		Centering[%State] = "Railed"
	EndIf
	
	If (str2num(Centering[%$"EndProgram"])== 1)
		Centering[%State] = "EndCentering"
	EndIf
	
	updateStatus(centering[%State])

		
	Strswitch (Centering[%State])
		case "FirstRamp":
			Wave FirstRamp_Settings
			Wave/T FirstRamp_WaveNames
			FirstRamp_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]
			CFPSettings[%StartX]=XCurrentPosition_Volts
			CFPSettings[%StartY]=YCurrentPosition_Volts
			DoForceRampFiltered(FirstRamp_Settings,FirstRamp_WaveNames,CFPSettings[%TriggerFilterFreq])
			
		break
		case "Circle":
			Wave Circle_Settings
			Wave/T Circle_WaveNames
			Circle_Settings[%Force_N]=CFPSettings[%TargetForce]
			Circle_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]
			Circle_Settings[%Radius_m]=CFPSettings[%CircleRadius]
			Circle_Settings[%CenterX_V]=XCurrentPosition_Volts
			Circle_Settings[%CenterY_V]=YCurrentPosition_Volts
			
			Circles_X[0]= XCurrentPosition_Volts
			Circles_Y[0]= YCurrentPosition_Volts
			Circles_Z[0]= ZCurrentPosition_Volts

			CFCircle(Circle_Settings,Circle_WaveNames)
		break
		case "DiscreteMoves":
			Wave MoveToPoint_Settings
			
			Variable Iteration = CFPSettings[%StepIteration]
			MoveToPoint_Settings[%XPosition_V]=XTargets[Iteration]
			MoveToPoint_Settings[%YPosition_V]=YTargets[Iteration]
			MoveToPoint_Settings[%Force_N]=CFPSettings[%TargetForce]
			MoveToPoint_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]

			// If more than one discrete point recorded, then test them to see if we have passed the point of maximum extension
			// If not, then move to the next point
			If (Iteration == 1)
				MoveToPointCF(MoveToPoint_Settings,Callback="StepsCallback()")			
			ElseIf ((Iteration>=2)&&(Iteration<=13))
				Variable Increasing1=ZTargets[Iteration-1]>ZTargets[Iteration-2]
				Variable Increasing2=ZTargets[Iteration-2]>ZTargets[Iteration-3]
				
				updateCryptidGraph(deflVolts=zTargets,zSensorVolts=xTargets, asIs=1)
				
				Variable MovingAwayFromCenter = Increasing1&&Increasing2
				updateStatus("Discrete Moves "+num2str(iteration)+"/13")
				If(MovingAwayFromCenter)
					Centering[%State] = "FineTuneCenter"
	
					MoveToPoint_Settings[%XPosition_V]=XTargets[Iteration-3]
					MoveToPoint_Settings[%YPosition_V]=YTargets[Iteration-3]
					
					Wave FineCentering_Settings
					FineCentering_Settings[%CenterX_V]=XTargets[Iteration-3]
					FineCentering_Settings[%CenterY_V]=YTargets[Iteration-3]
						
					MoveToPointCF(MoveToPoint_Settings,Callback="CFP_MainLoop()")
				Else
					MoveToPointCF(MoveToPoint_Settings,Callback="StepsCallback()")
				EndIf
			
			EndIf // iteration >1
			
	//		updateCenteringDisplay(iteration=iteration)
			
			If (Iteration>13)
				print "Too many DM iterations"
				StopZFeedbackLoop()			
				FinishCFP()
			Endif						
		break
		case "FineTuneCenter":
			Wave FineCentering_Settings
			Wave/T FineCentering_WaveNames
			FineCentering_Settings[%Force_N]=CFPSettings[%TargetForce]
			FineCentering_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]
			// This is a fix in version 7.1
			// Reads the distance to move from center for the distance to move in the fine centering.  Was stuck at 100nm in versions 6 and 7.
			FineCentering_Settings[%DistanceFromCenter_m]=CFPSettings[%'Distance to move from center']

			If(CFPSettings[%FineCenteringIteration]<=CFPSettings[%$"Max Iterations"])
				CFCross(FineCentering_Settings,FineCentering_WaveNames)
			Else
			//	Print "Center not found :( "
				updateStatus("Center Not Found :(")
				StopZFeedbackLoop()	
				SaveCurrentData() 
				FinishCFP()
			EndIf
		break
		case "Railed":
			StopZFeedbackLoop()		
			//SaveCurrentData()  // This is just in here temporarily for testing purposes.  Trying to see if there is a bug to fix.	
			FinishCFP()
		break
		case "EndProgram":
			StopZFeedbackLoop()			

		break
		default:	
			print "Error, in default state.  Check your program for problems."
	EndSwitch
	
End

Function ResetCurrentDataWaves()
	
	// Make Waves for Force Triggering
	Make/N=(1024)/O ZSensor_Ramp1,DefV_Ramp1,ZSensor_Ramp2,DefV_Ramp2

	// Make waves for centering
	Make/O/N=2 Circles_X,Circles_Y,Circles_Z
	Make/O/N=13 XTargets,YTargets,ZTargets,DefTargets
	Make/O/N=10 FineCenterX,FineCenterY,FineCenterZ
	Make/N=(1024)/O XSensorCircle,YSensorCircle,ZSensorCircle
	FineCenterX=0
	FineCenterY=0
	FineCenterZ=0
	// Fine Centering motion and fit waves
	Make/O/N=(1024) XSensorFine,YSensorFine,ZSensorFine,DefVFine,XFit, YFit,XPos,YPos,ZSensor_X,ZSensor_Y
	
	// Kill Saved Fits to fine centering
	String XFitWaveNames= WaveList("XFit_*", ";" ,"" )
	String YFitWaveNames= WaveList("YFit_*", ";" ,"" )
	String XPosWaveNames= WaveList("XPos_*", ";" ,"" )
	String YPosWaveNames= WaveList("YPos_*", ";" ,"" )
	String ZSensorXWaveNames= WaveList("ZSensorX_*", ";" ,"" )
	String ZSensorYWaveNames= WaveList("ZSensorY_*", ";" ,"" )
	
	Variable NumFitWavestoKill=ItemsInList(XFitWaveNames, ";")
	Variable Counter=0
	For(Counter=0;Counter<NumFitWavesToKill;Counter+=1)
		String XFitWaveName=StringFromList(Counter, XFitWaveNames)
		String YFitWaveName=StringFromList(Counter, YFitWaveNames)
		String XPosWaveName=StringFromList(Counter, XPosWaveNames)
		String YPosWaveName=StringFromList(Counter, YPosWaveNames)
		String ZSensorXWaveName=StringFromList(Counter, ZSensorXWaveNames)
		String ZSensorYWaveName=StringFromList(Counter, ZSensorYWaveNames)
		KillWaves $XFitWaveName,$YFitWaveName,$XPosWaveName,$YPosWaveName,$ZSensorXWaveName,$ZSensorYWaveName
	EndFor
	
	// Reset selected centering settings
	Wave CFPSettings
	CFPSettings[%$"Center Found?"]=0
	CFPSettings[%$"FineCenteringIteration"]=0
	CFPSettings[%$"StepIteration"]=0
	CFPSettings[%$"Center X"]=0
	CFPSettings[%$"Center Y"]=0
	CFPSettings[%$"FoundMolecule"]=0
	
End // ResetCurrentDataWaves

//Function DisplayCFPPanel(PanelName)
//	String PanelName	

//	DoWindow/F $PanelName
//	If (V_flag==0)		
//		Wave FirstRamp_Settings
//		Wave/T FirstRamp_WaveNames
//		Wave CenteredRamp_Setting
//		Wave/T CenteredRamp_WaveNames
//
//		StrSwitch(PanelName)
//			Case "CFP_Panel":
//				Execute/Q "CFP_Panel()"
//				MoveWindow/W=CFP_Panel 722,10,895,350
//			break
//			Case "FirstRampCFP":
//				MakeForceRampPanel(FirstRamp_Settings,FirstRamp_WaveNames,PanelName="FirstRampCFP",WindowName="CFP First Ramp")
//				MoveWindow/W=FirstRampCFP 400,10,550,285
//			break
//			Case "CenteredRampCFP":
//				MakeForceRampPanel(CenteredRamp_Settings,CenteredRamp_WaveNames,PanelName="CenteredRampCFP",WindowName="CFP Centered Ramp")
//				MoveWindow/W=CenteredRampCFP 560,10,710,285
//			break
			
//		EndSwitch
		
//	EndIf

//End

Function DisplayCFPInfo(TargetDisplay,[TargetDataFolder])
	String TargetDisplay,TargetDataFolder
	String NamePrefix
	
	If(ParamIsDefault(TargetDataFolder))
		TargetDataFolder=getDataFolder(1)
	EndIf
	
	If(StringMatch(TargetDataFolder,"root:Settings:CFP"))
		NamePrefix="Current"
	Else
		NamePrefix=StringFromList(2,TargetDataFolder,":")
	EndIf
	
	SetDataFolder $TargetDataFolder
	String DisplayName=NamePrefix+TargetDisplay
	DoWindow/F $DisplayName
	
	If (V_flag==0)		
		strswitch(TargetDisplay)
			case "FirstRampTable":
				Edit/K=1/W=(7.5,92.75,508.5,288.5)/N=$DisplayName  FirstRamp_Settings.ld
			break
			case "CenteringTable": 
				Edit/K=1/W=(5.25,323,336,535.25)/N=$DisplayName CenteringSettings.ld
			break	
			case "CFPSettings": 
				Edit/K=1/W=(5.25,323,336,535.25)/N=$DisplayName CFPSettings.ld
			break	
			case "CircleSettings":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName Circle_Settings.ld
			break	
			case "FineCenteringSettings":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName FineCentering_Settings.ld
			break	
			case "SampleAtPointSettings":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName SampleAtPoint_Settings.ld
			break	
			case "MoveToPointSettings":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName MoveToPoint_Settings.ld
			break	
			case "CenteredRampSettings":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName CenteredRamp_Settings.ld
			break	
			case "CurrentCenteringGraphs":
				//DisplayReport("Current")
			break	
			case "PresetPullingVelocities":
				Edit/K=1/W=(3.75,564.5,338.25,810.5)/N=$DisplayName PresetPullingVelocities.ld
			break	
			
		endswitch  // TargetDisplay
	EndIf		

End // DisplayInfo

//CALL THIS FROM CRYPTID
Function StartCFP([successCallback, failCallback, skipRamp])
	
	string successCallback, failCallback
	Variable skipRamp
	
	if(paramIsDefault(skipRamp))
		skipRamp=1
	endif
	
	if(paramIsDefault(successCallback))
		successCallback="CryptidMain(1)"
	endif
	if(paramIsDefault(failCallback))
		failCallback="CryptidMain(0)"
	endif
	
	string/G sCallback = successCallback
	string/G fCallback = failCallback
	Wave/T CenteringSettings
	
	CenteringSettings[%State]="FirstRamp"
	CenteringSettings[%$"EndProgram"]="0"
	
//	Variable DeflectionOffset=DelfVOffset()//td_rv("Deflection")
	Wave CFPSettings
//	CFPSettings[%DeflectionOffset]=DeflectionOffset
	CFPSettings[%$"Center Found?"]=0
	
	//DetermineOffset()
	//Instead of determine offset, skip and just use cryptids
	//Edited to enable centering when a force ramp was done by cryptid, or centering in the middle
	//of a force clamp
//	Wave vSettings = getCryptidSettings(1)

	//Detrending change: Need to update DeflVOffset function for custom channel
	//Actually, instead, I am resetting the offset between the deflection and labjack every cycle
	//to ensure they are the same zero voltage. This "should" compensate.
	CFPSettings[%DeflectionOffset] = DelfVOffset()

	ResetCurrentDataWaves()
	
	//Skip ramp assumes a molecule is already attached
	if (skipRamp)
		
		CFPSettings[%FoundMolecule]=1
		StrSwitch(CenteringSettings[%CenteringMode])
			
			case "FullCentering":
				CenteringSettings[%State]="Circle"
				break
				
			case "JustFineCentering":
				CenteringSettings[%State]="FineTuneCenter"
				Wave FineCentering_Settings
				FineCentering_Settings[%CenterX_V]=td_rv("Cypher.LVDT.X")
				FineCentering_Settings[%CenterY_V]=td_rv("Cypher.LVDT.Y")
				break
				
		EndSwitch
		
	endif
	
	if (!SkipRamp)
		//lets get a better (newer) zero
		getDeflVOffset(callback="setCenteringDeflVCallback()")
	else
		CFP_MainLoop()
	endif
	
	
	
	
End //StartCFP()

Function setCenteringDeflVCallback()

	Wave CFPSettings
	Wave vSettings = getCryptidSettings(0)
	
	CFPSettings[%DeflectionOffset] = vSettings[%DeflVOffset]
	
	CFP_MainLoop()

End

Function StopCFP()
	Wave/T CenteringSettings
	CenteringSettings[%$"EndProgram"]="1"
End

Function DetermineOffset()
	Wave DeflectionOffsetData
	Variable Error=0
	SVAR CFDeflectionChannel
	Error+= td_xSetInWave(0, "0,0", CFDeflectionChannel, DeflectionOffsetData, "DetermineOffsetCallback()",100)

	// Execute motion
	Error +=td_WriteString("Event.0", "once")

	if (Error>0)
		print "Error in DetermineOffset: ", Error
	endif
End

Function DetermineOffsetCallback()
	Wave DeflectionOffsetData
	WaveStats/Q DeflectionOffsetData
	Variable DeflectionOffset=V_avg
	
	Wave CFPSettings
	CFPSettings[%DeflectionOffset]=DeflectionOffset
	

End

// This callback exectues when the CTFC is done
Function FirstRampCallback() 
	
	//print "FirstRampCallback()"
	Wave/T TriggerInfo=$getDataFolder(1)+"TriggerInfo_Ramp1"
	Wave/T CenteringSettings=$getDataFolder(1)+"CenteringSettings"
	Wave CFPSettings=$getDataFolder(1)+"CFPSettings"
	Wave DefVolts=$getDataFolder(1)+"DefV_Ramp1"
	Wave ZSensorVolts = $getDataFolder(1)+"ZSensor_Ramp1"
	variable Error = 0
	variable MoleculeAttached =1 // Default assumption is molecule will attach

	// Set current state to First Ramp callback
	CenteringSettings[%State]="FirstRampCallback"
	
	// Check to see if molecule is attached.  If Triggertime2 is greater than 400,000, then molecule did NOT attach
	Error+=td_ReadGroup("ARC.CTFC",TriggerInfo)
	if (str2num(TriggerInfo[%TriggerTime2])> 400000)
		MoleculeAttached=0
	endif
	

	If (Error>0)
		Print "Error in FirstRampCallback"
	EndIf

	updateCryptidGraph(deflVolts=defVolts, zSensorVolts=ZSensorVolts, Zero=0)

	// Execute Centering Routine if molecule is attached
	if (MoleculeAttached==1)  
		CFPSettings[%FoundMolecule]=1

		StrSwitch(CenteringSettings[%CenteringMode])
			case "FullCentering":
				CenteringSettings[%State]="Circle"
				CFP_MainLoop()
			break
			case "JustFineCentering":
				CenteringSettings[%State]="FineTuneCenter"
				Wave FineCentering_Settings
				FineCentering_Settings[%CenterX_V]=td_rv("Cypher.LVDT.X")
				FineCentering_Settings[%CenterY_V]=td_rv("Cypher.LVDT.Y")

				CFP_MainLoop()

			break
		EndSwitch
	endif
	
	// If no molecule attached, then finish this
	If (MoleculeAttached==0)
		FinishCFP()
	endif

End //FirstRampCallback


//BD - After circle, mark in the "Circles" waves the starting point (circle center)
//and the z-min point. Use these to make steps of 1 radius in the direction of the minimum
//which is populated into xTargets
Function CircleCallback() 
	
	Wave/T CenteringSettings
	Wave CFPSettings
	Wave XSensorCircle
	Wave YSensorCircle
	Wave ZSensorCircle
	Wave Circles_X
	Wave Circles_Y
	Wave Circles_Z
	Wave XTargets
	Wave YTargets
	Wave ZTargets

	
	CenteringSettings[%State] = "CircleCallback"
	
	WaveStats/Q ZSensorCircle
 	Variable MinDirectionRowLoc = V_minRowLoc

	Circles_X[1]= XSensorCircle[MinDirectionRowLoc]
	Circles_Y[1]= YSensorCircle[MinDirectionRowLoc]
	Circles_Z[1]= ZSensorCircle[MinDirectionRowLoc]
	
	Variable YIncrement = Circles_Y[1]-Circles_Y[0]
	Variable XIncrement = Circles_X[1]-Circles_X[0]
	
	XTargets = XIncrement*(p-1)+Circles_X[0]
	YTargets = YIncrement*(p-1)+Circles_Y[0]
	ZTargets=0
	
	CFPSettings[%StepIteration] = 1
	CenteringSettings[%State] = "DiscreteMoves"
	
	//Added by BD To visualize the circles
	updateCenteringDisplay(create=1)
	
	CFP_MainLoop()
	
End // CircleCallback

Function StepsCallback() 
	
	Wave/T CenteringSettings
	Wave CFPSettings
	Wave XTargets
	Wave YTargets
	Wave ZTargets
	Wave SampleAtPoint_Settings
	Wave/T SampleAtPoint_WaveNames

	Variable CurrentIteration=CFPSettings[%StepIteration]

	CenteringSettings[%State] = "SampleZSensor"
	SampleAtPoint_Settings[%Force_N]=CFPSettings[%Targetforce]
	SampleAtPoint_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]
	
	// Sample X,Y,Z, and Deflection at this point, while maintaining constant force
	SampleZSensorCF(SampleAtPoint_Settings,SampleAtPoint_WaveNames)
	
End // StepsCallback

Function SampleZCallback()
	Wave/T CenteringSettings
	Wave CFPSettings
	Wave XTargets
	Wave YTargets
	Wave ZTargets
	Wave SampleAtPoint_Settings
	Wave/T SampleAtPoint_WaveNames
	Wave ZSensor=$getDataFolder(1)+"ZSensorPoint"
	Variable CurrentIteration=CFPSettings[%StepIteration]
	
	CenteringSettings[%State] = "SampleZCallback"
	// Average Z Sensor wave for current z sensor position
	WaveStats/Q ZSensor
	ZTargets[CurrentIteration]=V_avg
	
	// Move to next iteration and go back to main program loop
	CFPSettings[%StepIteration] = CurrentIteration+1
	CenteringSettings[%State] = "DiscreteMoves"
	CFP_MainLoop()

End

Function FineCenteringCallback()

	Wave/T CenteringSettings
	Wave CFPSettings
	Variable FineCenterIteration = CFPSettings[%FineCenteringIteration]
	Wave FineCenterX
	Wave FineCenterY
	Wave FineCenterZ
	Wave XSensorFine
	Wave YSensorFine
	Wave ZSensorFine
	Wave DefVFine
	Variable MaxIterations = CFPSettings[%$"Max Iterations"]
	Variable CriticalFitDifference = CFPSettings[%$"Critical Fit Difference"]
		
	// Split the raw waves into data for centering calculation
	Variable NumPoints=numpnts(XSensorFine)
	Variable Increment=Floor(NumPoints/16)

	Duplicate/O/R=[3*Increment+1,5*Increment] XSensorFine, XPos
	Duplicate/O/R=[3*Increment+1,5*Increment] ZSensorFine, ZSensor_X 
	Duplicate/O/R=[11*Increment+1,13*Increment] YSensorFine, YPos
	Duplicate/O/R=[11*Increment+1,13*Increment] ZSensorFine, ZSensor_Y	
	
	// Save this iteration data
	String CurrentIterationStr=num2str(FineCenterIteration)
	String XPosName =  "XPos_"+ CurrentIterationStr
	String YPosName =  "YPos_"+ CurrentIterationStr
	String ZSensor_XName =  "ZSensorX_"+ CurrentIterationStr
	String ZSensor_YName =  "ZSensorY_"+ CurrentIterationStr
		
	Duplicate/O XPos, $XPosName
	Duplicate/O YPos, $YPosName
	Duplicate/O ZSensor_X, $ZSensor_XName
	Duplicate/O ZSensor_Y, $ZSensor_YName	
		
	// Calculate Center Positions
	Variable CenterX = CalculateCenterPosition(XPos,ZSensor_X)
	Duplicate/O Quadratic_Fit, XFit
	String XFitName =  "XFit_"+ CurrentIterationStr
	Duplicate/O Quadratic_Fit, $XFitName
	
	Variable CenterY = CalculateCenterPosition(YPos,ZSensor_Y)
	Duplicate/O Quadratic_Fit, YFit
	String YFitName =  "YFit_"+ CurrentIterationStr
	Duplicate/O Quadratic_Fit, $YFitName
	
	FineCenterX[FineCenterIteration]=CenterX
	FineCenterY[FineCenterIteration]=CenterY
	
	//Uncomment to display the fine centering
	if (!windowExists("FineDisplay"))
		display/N=fineDisplay zSensorFine vs xSensorFine
		appendToGraph XFit vs XPos
		ModifyGraph LSize(XFit)=2
		appendToGraph/C=(0,0,0)/B=X2 zSensorFine vs ySensorFine
		appendToGraph/C=(0,0,0)/B=X2 YFit vs YPos
		ModifyGraph LSize(YFit)=2
		ModifyGraph freePos(X2)={1,kwFraction}
	endif
	
	
	Wave MoveToPoint_Settings
	
	MoveToPoint_Settings[%XPosition_V]=CenterX
	MoveToPoint_Settings[%YPosition_V]=CenterY
	MoveToPoint_Settings[%Force_N]=CFPSettings[%TargetForce]
	MoveToPoint_Settings[%DefVOffset]=CFPSettings[%DeflectionOffset]
	
	MoveToPointCF(MoveToPoint_Settings,Callback="MoveToNewCenterCallback()")			

End // Centering Callback

Function MoveToNewCenterCallback()

	Wave/T CenteringSettings
	Wave CFPSettings
	Variable FineCenterIteration = CFPSettings[%FineCenteringIteration]
	Wave FineCenterX
	Wave FineCenterY
	Wave FineCenterZ
	Wave XSensorFine
	Wave YSensorFine
	Wave ZSensorFine
	Wave DefVFine
	Wave FineCentering_Settings
	Variable MaxIterations = CFPSettings[%$"Max Iterations"]
	Variable CriticalFitDifference = CFPSettings[%$"Critical Fit Difference"]
	
	Variable XCriticalFitDifference = Abs(CriticalFitDifference/GV("XLVDTSens")) // X Critical difference in LVDT volts
	Variable YCriticalFitDifference = Abs(CriticalFitDifference/GV("YLVDTSens")) // Y Critical difference in LVDT volts
	
	// Determine if we found the center.  End if center is found, or if we reach the max number of iterations.
	Variable FoundCenter=0
	If (FineCenterIteration==1)  // If this is the first iteration, run a second iteration to be sure we found the center
		FoundCenter=0
	ElseIf ((FineCenterIteration<MaxIterations)&&(FineCenterIteration>1)) // If we are in between 2 iterations and the max iterations, see if we found a good center
		variable XDiff = Abs((FineCenterX[FineCenterIteration-1]-FineCenterX[FineCenterIteration]))
		variable YDiff =  Abs((FineCenterY[FineCenterIteration-1]-FineCenterY[FineCenterIteration]))
		
		updateStatus("XDiff: "+num2str(xDiff)+" | "+"YDiff: "+num2str(yDiff)+" | "+ "Iter: "+num2str(fineCenterIteration))
		cryptidDebug(diagString= "XDiff: "+num2str(xDiff)+" | "+"YDiff: "+num2str(yDiff)+" | "+ "Iter: "+num2str(fineCenterIteration))
		If ((XDiff<XCriticalFitDifference)&&(YDiff<YCriticalFitDifference) ) 
			FoundCenter=1
			CFPSettings[%$"Center Found?"] = 1
			CFPSettings[%$"Center X"] = FineCenterX[FineCenterIteration] 
			CFPSettings[%$"Center Y"] = FineCenterY[FineCenterIteration]
			
		Else	// If not, try another centering
			FoundCenter=0
		Endif
		
	Else   // If we have reached the maximum number of iterations, go to center and ramp
		FoundCenter=0
	EndIf
	
 	// Now, if center found then execute a ramp to get centered force data
	If (FoundCenter)
		//Congrats! Gunna run the next step now -BD
//		print "Center Found"
		updateStatus("Center Found!")
		wave CenteredRamp_Settings
		CFPSettings[%NumCenteredForcePulls]+=1
		if(CFPSettings[%UsePresetPullingVelocities])
			Wave PPV=$getDataFolder(1)+"PresetPullingVelocities"
			Duplicate/O/R=[0,*][2] PPV,PPVCounts
			Redimension/N=-1 PPVCounts
			Variable PPVIndex=0
			PPVIndex= GetIndex(PPVCounts,CFPSettings[%NumCenteredForcePulls])		
			CenteredRamp_Settings[%'Retract Velocity']=PPV[PPVIndex][%PullingVelocity]
			KillWaves PPVCounts
			
		EndIf
		
		StopZFeedbackLoop()
		CenteringSettings[%State] = "CenterFound"
		
		
		SVAR sCallback
		execute sCallback
		//cryptidMain(1)
	else	
		 // If we haven't found the center, try again to find the center
		FineCentering_Settings[%CenterX_V]= FineCenterX[FineCenterIteration] 
		FineCentering_Settings[%CenterY_V]= FineCenterY[FineCenterIteration] 
		
		CFPSettings[%FineCenteringIteration]+=1
	//	print "Center Not Found, iter: "+num2str(CFPSettings[%FineCenteringIteration]-1) + " with XDiff and yDiff = "+num2str(xDiff) +">"+num2str(xcriticalFitDifference)+" or "+num2str(yDiff) +">"+num2str(ycriticalFitDifference)
		CFP_MainLoop()
	Endif  // test == 1
	
End
Function MoveThenRampCallback()
	StopZFeedbackLoop()
	wave CenteredRamp_Settings
	wave/t centeredRamp_WaveNames
	DoForceRamp(CenteredRamp_Settings,CenteredRamp_WaveNames)
End

Function StopZFeedbackLoop()
	// Here we stop the z feedback loop and reset it.  Without this code, our next force ramp will just be stuck.  
	//Detrending change: stopPISLoop from -2 to 2 so it doesnt kill the outAloop
	ir_StopPISLoop(2)
	Struct ARFeedbackStruct FB
	ARGetFeedbackParms(FB,"outputZ")
	FB.StartEvent = "2"
	FB.StopEvent = "3"
	String ErrorStr
	ErrorStr += vs_writePIDSLoop(FB)

End

// Center calculation happens here. 
// Currently does a quadratic fit but then just returns the current center position.  Will change this when we have a sample with molecules. 
Function CalculateCenterPosition(PosData,DefData)
	Wave DefData, PosData
	Duplicate/O DefData Quadratic_Fit
	Make/D/O/N=4 Quadratic_Coeff
	
	WaveStats/Q DefData
	Variable DefMin=V_min
	Variable ChangeInDef=V_max-V_min
	// Check to make sure that the minimum deflection signal is in the minimum 80% of the data.  
	Variable DefMinLoc=V_minRowLoc
	Variable StartRange=V_npnts*0.1
	Variable EndRange = V_npnts*0.9
	Variable MinInRange=(DefMinLoc>StartRange)&&(DefMinLoc<EndRange)
	// Default value for center location is the position associated with the minimum deflection signal. 
	Variable CenterLocation=PosData[DefMinLoc]
	// If the minimum deflection signal is in the minimum 80% of the data, then fit a parabola and get a better center value.
	If(MinInRange)
		WaveStats/Q PosData
		Variable PosAvg=V_min
		Variable ChangeInPos=V_max-V_min
		Variable DefOverPos=ChangeInDef/ChangeInPos
		
		Quadratic_Coeff[0] = DefMin
		Quadratic_Coeff[1] = DefOverPos
		Quadratic_Coeff[2] = DefOverPos
		Quadratic_Coeff[3] = PosAvg
		FuncFit/Q/N/NTHR=0/W=2 QuadraticFit Quadratic_Coeff DefData /X=PosData /D=Quadratic_Fit
		FuncFit/Q/N/NTHR=0/W=2 QuadraticFit Quadratic_Coeff DefData /X=PosData /D=Quadratic_Fit
		CenterLocation=Quadratic_Coeff[3]-(Quadratic_Coeff[1]/2/Quadratic_Coeff[2])
	EndIf
	Return CenterLocation
	
End //CalculateCenterPosition

// Custom Quadratic Fit Function.  Allows the center of the quadratic to vary, unlike to the stupid IGOR version
Function QuadraticFit(w,x) : FitFunc
	WAVE w
	Variable x

	return w[0]+w[1]*(x-w[3])+w[2]*(x-w[3])^2
End

///////////////////////////////////////////////////
// PauseCFPCallback()
// This will cause the program to end after the centered force pull.  All data will be saved, but you won't do anything else 
// Useful for modes where you want to pull from the center and then manually manipulate the molecule
//  such as for the RNA constructs (HIV stemloop and Sugar cane virus pseudoknot)

Function PauseCFPCallback()
	Wave/T CenteringSettings
	Beep
	StopZFeedbackLoop()  // Need this to stop feedback loop.  Fixed in version 7.1
	CenteringSettings[%$"EndProgram"]="1"
	CenteredForcePullCallback()
End

// CenteredForcePullCallback()
// This is the function that executes after the centered force ramp is finished, or after the the first ramp when no molecule is attached
// I am iterating the master loop and put the centered force pull data in the appropriate place
// This will end the master loop when the end master loop parameter is set to "Yes" or when we have reached the maximum number of iterations
Function CenteredForcePullCallback()
	Wave/T CenteringSettings
	Wave CFPSettings

	CenteringSettings[%State] = "CenteredForcePullCallback"
	
	// Did we do a centered force ramp?
	Variable CenteredForceRamp=WhichListItem(CenteringSettings[%FoundCenterAction],"ForceRamp;RampThenClamp;RampThenPause;MoveThenForceRamp;")!=-1
	// If we did a centered force ramp, then save final force ramp with suffix _CFR (stands for centered force ramp)
	If(CenteredForceRamp)
		Wave DefVolts = $getDataFolder(1)+"DefV_Ramp2"
		Wave ZSensorVolts = $getDataFolder(1)+"ZSensor_Ramp2"
		String SaveName=CenteringSettings[%SaveName]+"_CFR"
		print "SAVING CENTERED RAMP"
		If(StringMatch(CenteringSettings[%FoundCenterAction],"MoveThenForceRamp"))
			ControlInfo/W=CFP_Panel LateralMoveSV
			Variable DistanceToMoveV=V_value
			String OffsetNote="CenterRampLateralOffset:"+num2str(DistanceToMoveV)+"\r"
			SaveAsAsylumForceRamp(SaveName,CFPSettings[%MasterIteration],DefVolts,ZSensorVolts,AdditionalNotes=OffsetNote)
		Else
			//BDEdit to add Experiment Info Note
			String addNote = ""
			addNote += ExperimentInfoNote()
			SaveAsAsylumForceRamp(SaveName,CFPSettings[%MasterIteration],DefVolts,ZSensorVolts,additionalNotes=addNote)
		EndIf
		
	EndIf
	
	// Save Centering Data
	SaveCurrentData()
	
	// Set back to regular folder
	FinishCFP()
		
End //CenteredForcePullCallback

Function FinishCFP()
	// This is the code that will officially finish a centered force pull.  I'll add functionality to move around the surface here. 
	// I should also add code to reset all the appropriate wave values for the next centered force pull.
	// For now, it will just stop the program
//	Wave/T CenteringSettings
//	Wave CFPSettings
//	Wave/T ZeroThePDCallbackWave
//	Wave/T CheckInvolsCallbackWave


	//BD - I think if we end up here, then we have failed?
	SVAR fCallback
	
	execute fCallback
	//cryptidMain(0)

//	CFPSettings[%MasterIteration]+=1
	// Max index for saving in the asylum format is 9999.  After that, we'll just reset to 0
//	If(CFPSettings[%MasterIteration]>9999)
//		CFPSettings[%MasterIteration]=0
//	EndIf
	
	// If using the search grid, then use it.  If we found the center, then we found a molecule.
	// After moving to next spot, execute StartCFP()
//	CenteringSettings[%State] = "FinishCFP"

//	Variable EndProgram=StringMatch(CenteringSettings[%$"EndProgram"],"1")
//	Variable FoundX=CFPSettings[%StartX]
//	Variable FoundY=CFPSettings[%StartY]
	
//	If(!EndProgram)
//		If(CFPSettings[%UseSearchGrid]&&!CFPSettings[%UseZeroThePD]&&CFPSettings[%UseCheckInvols])
//			CheckInvolsCallbackWave[%Callback]="StartCFP()"
//			SearchForMolecule(FoundMolecule=CFPSettings[%FoundMolecule],Callback="DoCheckInvols()",FoundX_V=FoundX,FoundY_V=FoundY)
//		EndIf
//		If(CFPSettings[%UseSearchGrid]&&!CFPSettings[%UseZeroThePD]&&!CFPSettings[%UseCheckInvols])
//			SearchForMolecule(FoundMolecule=CFPSettings[%FoundMolecule],Callback="StartCFP()",FoundX_V=FoundX,FoundY_V=FoundY)
//		EndIf
//		If(CFPSettings[%UseSearchGrid]&&CFPSettings[%UseZeroThePD]&&CFPSettings[%UseCheckInvols])
//			ZeroThePDCallbackWave[%Callback]="DoCheckInvols()"
//			CheckInvolsCallbackWave[%Callback]="StartCFP()"
//			SearchForMolecule(FoundMolecule=CFPSettings[%FoundMolecule],Callback="DoZeroPD()",FoundX_V=FoundX,FoundY_V=FoundY)
//		EndIf
//		If(CFPSettings[%UseSearchGrid]&&CFPSettings[%UseZeroThePD]&&!CFPSettings[%UseCheckInvols])
//			ZeroThePDCallbackWave[%Callback]="StartCFP()"
//			SearchForMolecule(FoundMolecule=CFPSettings[%FoundMolecule],Callback="DoZeroPD()",FoundX_V=FoundX,FoundY_V=FoundY)
//		EndIf
//		If(!CFPSettings[%UseSearchGrid]&&CFPSettings[%UseZeroThePD]&&CFPSettings[%UseCheckInvols])
//			ZeroThePDCallbackWave[%Callback]="DoCheckInvols()"
//			CheckInvolsCallbackWave[%Callback]="StartCFP()"
//			DoZeroPD()
//		EndIf
//		If(!CFPSettings[%UseSearchGrid]&&CFPSettings[%UseZeroThePD]&&!CFPSettings[%UseCheckInvols])
//			ZeroThePDCallbackWave[%Callback]="StartCFP()"
//			DoZeroPD()
//		EndIf
//		If(!CFPSettings[%UseSearchGrid]&&!CFPSettings[%UseZeroThePD]&&CFPSettings[%UseCheckInvols])
//			CheckInvolsCallbackWave[%Callback]="StartCFP()"
//			DoCheckInvols()		
//		EndIf
//		If(!CFPSettings[%UseSearchGrid]&&!CFPSettings[%UseZeroThePD]&&!CFPSettings[%UseCheckInvols])
//			StartCFP()
//		EndIf
//	EndIF
	
End

Function SaveCurrentData()
	Wave/T CenteringSettings
	Wave CFPSettings
	
	String CurrentIterationStr
	sprintf CurrentIterationStr, "%04d", CFPSettings[%MasterIteration]
	
	String DataFolderName= CenteringSettings[%SaveName]+CurrentIterationStr
	NewDataFolder/O $DataFolderName
	
	String WaveNames = WaveList("*", ";" ,"" )
	
	Variable NumWavesToCopy=ItemsInList(WaveNames, ";")
	Variable Counter=0
	For(Counter=0;Counter<NumWavesToCopy;Counter+=1)
		String CurrentWaveName=StringFromList(Counter, WaveNames)
		String NewWaveName=getDataFolder(1)+DataFolderName+":"+CurrentWaveName
		Duplicate/O $CurrentWaveName,$NewWaveName
	EndFor
								
End //SaveCurrentData

//////////////////////////////////////////////////////////////////////////
// Stuff for the user interface

Function/S CFPQuickSettingsList()
	Wave CFPQuickSettings
	
	if(!WaveExists(CFPQuickSettings))
		Wave CFPQuickSettings = :Centering:CFPQuickSettings
	endif
	
	Return GetWaveDimNames(CFPQuickSettings,DimNumber=1)
End

Function CFPTabProc(tca) : TabControl
	STRUCT WMTabControlAction &tca
	switch( tca.eventCode )
		case 2: // mouse up
			Variable tab = tca.tab
	
			SetVariable SurfaceTrigger1,disable= (tab!=0)
			SetVariable MoleculeTrigger1,disable= (tab!=0)
			SetVariable ApproachVelocity1,disable= (tab!=0)
			SetVariable RetractVelocity1,disable= (tab!=0)
			SetVariable DwellTime1,disable= (tab!=0)
			SetVariable NoTriggerDistance1,disable= (tab!=0)
			SetVariable ForceDistanceIFR,disable= (tab!=0)
			SetVariable SamplingRateIFR,disable= (tab!=0)
			SetVariable FilterFreqSV,disable= (tab!=0)
			SetVariable FirstRampCallbackSV,disable= (tab!=0)

			SetVariable SurfaceTrigger2,disable= (tab!=1)
			SetVariable MoleculeTrigger2,disable= (tab!=1)
			SetVariable ApproachVelocity2,disable= (tab!=1)
			SetVariable RetractVelocity2,disable= (tab!=1)
			SetVariable DwellTime2,disable= (tab!=1)
			SetVariable NoTriggerDistance2,disable= (tab!=1)
			SetVariable ForceDistanceCFR,disable= (tab!=1)
			SetVariable SamplingRateCFR,disable= (tab!=1)
			SetVariable CenteredRampCallbackSV,disable= (tab!=1)
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function CFPButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	String ButtonName=ba.CtrlName

	switch( ba.eventCode )
		case 2: // mouse up
			strswitch(ButtonName)
				case "CFPStartButton":
					StartCFP()
				break
				case "CFPStopButton":
					StopCFP()
				break 
			EndSwitch
		break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function CFPInfoDisplay(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa

	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			DisplayCFPInfo(popStr)
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End



Function CheckSaveName(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva

	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
		case 3: // Live update
			Variable dval = sva.dval
			String sval = sva.sval
				Variable NameLength=strlen(sval)
				If(NameLength>13)
					Wave/T CenteringSettings
					String NewName=sval[0,12]
					CenteringSettings[%SaveName]=NewName
					
				EndIf
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function CFPCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba
	String CheckBoxName=cba.CtrlName
	Wave CFPSettings
	

	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			strswitch(CheckBoxName)
				case "UseSearchGrid":
					CFPSettings[%UseSearchGrid]=Checked
				break
				case "UseZeroThePD_CB":
					CFPSettings[%UseZeroThePD]=Checked
				break
				case "UseCheckInvols_CB":
					CFPSettings[%UseCheckInvols]=Checked
				break
				case "UsePresetPV_CB":
					CFPSettings[%UsePresetPullingVelocities]=Checked
				break
				
			EndSwitch
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function CFPQuickSettingsMenu(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa
	

	
	switch( pa.eventCode )
		case 2: // mouse up
			
			string StartDF = ""
			//If we are calling from ForceClamp, need to check subfolder
			If(!WaveExists(firstRamp_QuickSettings))
				startDF = getDataFolder(1)
				setDataFolder :Centering:
			endif
			
			
			Variable popNum = pa.popNum
			String SelectedQS = pa.popStr

			Duplicate/O/R=[0,*][popNum-1] FirstRamp_QuickSettings,FirstRamp_Settings
			Redimension/N=-1 CFPSettings
			Duplicate/O/R=[0,*][popNum-1] FirstRamp_WaveNamesQS,FirstRamp_WaveNames
			Redimension/N=-1 FirstRamp_WaveNames
			Duplicate/O/R=[0,*][popNum-1] CenteredRamp_QuickSettings,CenteredRamp_Settings
			Redimension/N=-1 CenteredRamp_Settings
			Duplicate/O/R=[0,*][popNum-1] CenteredRamp_WaveNamesQS,CenteredRamp_WaveNames
			Redimension/N=-1 CenteredRamp_WaveNames
			Duplicate/O/R=[0,*][popNum-1] CenteringQuickSettings,CenteringSettings
			Redimension/N=-1 CenteringSettings
			Duplicate/O/R=[0,*][popNum-1] CFPQuickSettings,CFPSettings
			Redimension/N=-1 CFPSettings
			UpdateCFPMenus()
			
			if(!stringMatch(startDF,""))
				setDataFolder $StartDF
			endif
			break
		case -1: // control being killed
			break
	endswitch


	return 0
End

Function CFPCenteringModePopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa

	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			Wave/T CenteringSettings
			
			if (!WaveExists(centeringSettings))
				Wave/t centeringSettings = :Centering:CenteringSettings
			endif
			
			CenteringSettings[%CenteringMode]=popStr			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function UpdateCFPMenus()
	Wave/T CenteringSettings
	
	if(!WaveExists(centeringSettings))
		wave/t centeringSettings=:Centering:CenteringSettings
	endif
	
	PopupMenu CenteringMode,popvalue=CenteringSettings[%CenteringMode]
//	PopupMenu FoundCenterActionMenu,popvalue=CenteringSettings[%FoundCenterAction]
	
End

Function FoundCenterActionPopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa

	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			Wave/T CenteringSettings
			CenteringSettings[%FoundCenterAction]=popStr

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function CFP_Panel([PanelName,WindowName,hostName]) : Panel
	
	String PanelName,WindowName, hostName
	
	Wave CFPSettings
	Wave/T CenteringSettings
	
	SVAR CFDeflectionChannel
	
	Wave firstRamp_Settings
	Wave firstRamp_WaveNames
	
	cryptidDebug()
	
	If(ParamIsDefault(WindowName))
		WindowName="Centering"
	EndIf
	If(ParamIsDefault(PanelName))
		PanelName="Centering"
	EndIf
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	//If no hostname, make as independent window
	if (paramIsDefault(hostName))
		NewPanel/W=(0,0,280,700)/N=$PanelName as WindowName
	else
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	
	Variable xShift = 40 
	Variable yShift = 10
	
	
	ModifyPanel cbRGB=(47872,47872,47872)

	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,501,270,501
	SetVariable CenteringDistance,pos={9,162},size={207,16},title="Centering Distance"
	SetVariable CenteringDistance,format="%.1W1Pm"
	SetVariable CenteringDistance,limits={-inf,inf,5e-09},value= CFPSettings[%'Distance to move from center']
	SetVariable SurfaceTrigger2,pos={90,40},size={154,16},disable=1,title="Surface Trigger"
	SetVariable SurfaceTrigger2,format="\\JR%.1W1PN"
	SetVariable SurfaceTrigger2,limits={-inf,inf,1e-11},value= CenteredRamp_Settings[%'Surface Trigger'],styledText= 1
	SetVariable MoleculeTrigger2,pos={90,67},size={154,16},disable=1,title="Molecule Trigger"
	SetVariable MoleculeTrigger2,format="\\JR%.1W1PN"
	SetVariable MoleculeTrigger2,limits={-inf,inf,5e-12},value= CenteredRamp_Settings[%'Molecule Trigger'],styledText= 1
	SetVariable ApproachVelocity2,pos={84,94},size={160,16},disable=1,title="Approach Velocity"
	SetVariable ApproachVelocity2,format="\\JR%.1W1Pm/s"
	SetVariable ApproachVelocity2,limits={-inf,inf,1e-07},value= CenteredRamp_Settings[%'Approach Velocity'],styledText= 1
	SetVariable RetractVelocity2,pos={90,121},size={154,16},disable=1,title="Retract Velocity"
	SetVariable RetractVelocity2,format="\\JR%.1W1Pm/s"
	SetVariable RetractVelocity2,limits={-inf,inf,1e-07},value= CenteredRamp_Settings[%'Retract Velocity'],styledText= 1
	SetVariable DwellTime2,pos={90,148},size={154,16},disable=1,title="Surface Dwell Time"
	SetVariable DwellTime2,format="\\JR%.1W1Ps"
	SetVariable DwellTime2,limits={-inf,inf,0.5},value= CenteredRamp_Settings[%'Surface Dwell Time'],styledText= 1
	SetVariable NoTriggerDistance2,pos={67,175},size={177,16},disable=1,title="No Trigger Distance"
	SetVariable NoTriggerDistance2,format="\\JR%.1W1Pm"
	SetVariable NoTriggerDistance2,limits={-inf,inf,1e-08},value= CenteredRamp_Settings[%'No Trigger Distance'],styledText= 1
	SetVariable MaxIterations,pos={9,140},size={207,16},title="Fine Centering Max Iterations"
	SetVariable MaxIterations,value= CFPSettings[%'Max Iterations']
	SetVariable CriticalFitDifference,pos={9,185},size={207,16},title="Critical Fit Difference"
	SetVariable CriticalFitDifference,format="%.1W1Pm"
	SetVariable CriticalFitDifference,limits={-inf,inf,1e-09},value= CFPSettings[%'Critical Fit Difference']
	SetVariable SetCircleRadius,pos={9,117},size={207,16},title="Circle Radius"
	SetVariable SetCircleRadius,format="%.1W1Pm"
	SetVariable SetCircleRadius,limits={-inf,inf,5e-09},value= CFPSettings[%CircleRadius]
	SetVariable TargetForce,pos={9,207},size={207,16},title="Target Force"
	SetVariable TargetForce,format="%.1W1PN"
	SetVariable TargetForce,limits={-inf,inf,5e-12},value= CFPSettings[%TargetForce]
	SetVariable ForceDistanceCFR,pos={65,202},size={179,16},disable=1,title="Force Distance"
	SetVariable ForceDistanceCFR,format="\\JR%.1W1Pm"
	SetVariable ForceDistanceCFR,limits={-inf,inf,1e-07},value= CenteredRamp_Settings[%'Extension Distance'],styledText= 1
	SetVariable SamplingRateCFR,pos={65,229},size={179,16},disable=1,title="Sample Rate"
	SetVariable SamplingRateCFR,format="\\JR%.1W1PHz"
	SetVariable SamplingRateCFR,limits={500,50000,1000},value= CenteredRamp_Settings[%'Sampling Rate'],styledText= 1
	PopupMenu QuickSettings,pos={9,54},size={207,22},bodyWidth=135,proc=CFPQuickSettingsMenu,title="Quick Settings"
	PopupMenu QuickSettings,mode=6,popvalue="650nmDigDNA",value= #"CFPQuickSettingsList()"
	SetVariable CenteredRampCallbackSV,pos={44,256},size={200,16},disable=1,title="Callback"
	SetVariable CenteredRampCallbackSV,limits={500,50000,1000},value= CenteredRamp_WaveNames[%Callback]
	PopupMenu CenteringMode,pos={9,81},size={108,22},bodyWidth=108,proc=CFPCenteringModePopMenuProc,title="Centering Mode"
	PopupMenu CenteringMode,mode=0,value= #"\"FullCentering;JustFineCentering;\""
	SetVariable LateralMoveSV,pos={9,227},size={207,16},title="Lateral Move Distance"
	SetVariable LateralMoveSV,help={"This will offset a distance from the center in the lateral direction for the final force ramp.  Only works with MoveThenForceRamp mode.  Don't use this for most things."}
	SetVariable LateralMoveSV,format="%.2W1Pm",limits={-inf,inf,5e-08},value= _NUM:0
	TitleBox CenteringTitle,pos={106,11},size={91,24},title="Centering",fSize=18
	TitleBox CenteringTitle,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115,468},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable CenteringDeflectionChannel,pos={9,248},size={207,16},title="Deflection Channel"
	SetVariable CenteringDeflectionChannel,help={"The channel the centering PID loop will use for deflection. If unsure, use Deflection"}
	SetVariable CenteringDeflectionChannel,limits={-inf,inf,0},value= CFDeflectionChannel
	SetVariable CenteringDeflectionChannel1,pos={117,82},size={117,20},title=" "
	SetVariable CenteringDeflectionChannel1,help={"The channel the centering PID loop will use for deflection. If unsure, use Deflection"}
	SetVariable CenteringDeflectionChannel1,fSize=15
	SetVariable CenteringDeflectionChannel1,limits={-inf,inf,0},value= CenteringSettings[%CenteringMode]

End

//BD - function to make a "Real" circle wave
Function/Wave realCircleWave(XSC, YSC,ZSC, [disp, inVolts])

	Wave XSC, YSC, ZSC
	variable disp, involts
	
	if (paramIsDefault(disp))
		disp = 1
	endif
	if (paramIsDefault(inVolts))
		inVolts = 0
	endif
	
	duplicate/O xSC xTemp
	duplicate/O ySC yTemp
	duplicate/O zSC zTemp

	
	Variable xSens = GV("XLVDTSens")
	Variable ySens = GV("YLVDTSens")
	Variable zSens = GV("ZLVDTSens")
	
	if (!InVolts)
		xTemp *= xSens
		yTemp *= ySens
		zTemp *= zSens
	endif
	
	Concatenate/O {xTemp, yTemp, zTemp}, fullCircle
	Wave fullCircle
	
	killTrailingZeroes(fullCircle)

	if (disp)
		if (windowExists("CircleDisplay"))
			killWindow $"CircleDisplay"
		endif
		
		pauseUpdate
		Execute "newGizmo/N=$\"CircleDisplay\""
		
		wave/t cSettings = getCryptidSettings(1)
		if (windowExists(cSettings[%panelName]))
			getWindow $cSettings[%panelName] wSize
			moveWindow/W=$"CircleDisplay" v_right, v_top, v_right+720, v_top+460
		endif
		
		Execute "appendToGizmo defaultScatter=fullCircle, name=circle"
		Execute "modifyGizmo aspectRatio=0"
		Execute "modifyGizmo object=circle, property = {shape,1}, property = {size, 2}"
		resumeUpdate
	endif

	return fullCircle
	
End

//Writen to visualize centering
Function updateCenteringDisplay([create, iteration])

	Variable create, iteration

	if (paramIsDefault(iteration))
		iteration = 0
	endif
	
	Wave targetWave
	
	if (create)
		Wave xSensorCircle, ySensorCircle, zSensorCircle
		Wave circleWave = realCircleWave(xSensorCircle, ySensorCircle, zSensorCircle, inVolts=1,disp=0)
		
		wave xTargets, yTargets, zTargets
		
		Wave targetWave
		if (waveExists(targetWave))
			redimension/N=(1,3) targetWave
		else
			make/O/N=(1,3) targetWave
		endif
		Wave targetWave
		
		targetWave[0][0] = xTargets[1]
		targetWave[0][1] = yTargets[1]
		targetWave[0][2] = (wavemax(zSensorCircle)+waveMin(zSensorCircle)) / 2
		
		//Execute "appendToGizmo defaultScatter=targetWave, name=targets"
		//Execute "modifyGizmo object=targets, property = {shape,1}, property ={color , 0,0,65535,1}, property ={size, 4}"
				
	elseif (iteration >1)
		insertPoints/M=0 iteration+1, 1, targetWave
		Wave zTargets, yTargets, xTargets
		targetWave[iteration][0] = xTargets[iteration-1]
		targetWave[iteration][1] = yTargets[iteration-1]
		targetWave[iteration][2] = zTargets[iteration-1]
		
	endif
	

End


Window CenteringPanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1028,973,1308,1673) as "Centering"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,501,270,501
	SetVariable CenteringDistance,pos={9,162},size={207,16},title="Centering Distance"
	SetVariable CenteringDistance,format="%.1W1Pm"
	SetVariable CenteringDistance,limits={-inf,inf,5e-09},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFPSettings[%'Distance to move from center']
	SetVariable SurfaceTrigger2,pos={90,40},size={154,16},disable=1,title="Surface Trigger"
	SetVariable SurfaceTrigger2,format="\\JR%.1W1PN"
	SetVariable SurfaceTrigger2,limits={-inf,inf,1e-11},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Surface Trigger'],styledText= 1
	SetVariable MoleculeTrigger2,pos={90,67},size={154,16},disable=1,title="Molecule Trigger"
	SetVariable MoleculeTrigger2,format="\\JR%.1W1PN"
	SetVariable MoleculeTrigger2,limits={-inf,inf,5e-12},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Molecule Trigger'],styledText= 1
	SetVariable ApproachVelocity2,pos={84,94},size={160,16},disable=1,title="Approach Velocity"
	SetVariable ApproachVelocity2,format="\\JR%.1W1Pm/s"
	SetVariable ApproachVelocity2,limits={-inf,inf,1e-07},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Approach Velocity'],styledText= 1
	SetVariable RetractVelocity2,pos={90,121},size={154,16},disable=1,title="Retract Velocity"
	SetVariable RetractVelocity2,format="\\JR%.1W1Pm/s"
	SetVariable RetractVelocity2,limits={-inf,inf,1e-07},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Retract Velocity'],styledText= 1
	SetVariable DwellTime2,pos={90,148},size={154,16},disable=1,title="Surface Dwell Time"
	SetVariable DwellTime2,format="\\JR%.1W1Ps"
	SetVariable DwellTime2,limits={-inf,inf,0.5},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Surface Dwell Time'],styledText= 1
	SetVariable NoTriggerDistance2,pos={67,175},size={177,16},disable=1,title="No Trigger Distance"
	SetVariable NoTriggerDistance2,format="\\JR%.1W1Pm"
	SetVariable NoTriggerDistance2,limits={-inf,inf,1e-08},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'No Trigger Distance'],styledText= 1
	SetVariable MaxIterations,pos={9,140},size={207,16},title="Fine Centering Max Iterations"
	SetVariable MaxIterations,value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFPSettings[%'Max Iterations']
	SetVariable CriticalFitDifference,pos={9,185},size={207,16},title="Critical Fit Difference"
	SetVariable CriticalFitDifference,format="%.1W1Pm"
	SetVariable CriticalFitDifference,limits={-inf,inf,1e-09},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFPSettings[%'Critical Fit Difference']
	SetVariable SetCircleRadius,pos={9,117},size={207,16},title="Circle Radius"
	SetVariable SetCircleRadius,format="%.1W1Pm"
	SetVariable SetCircleRadius,limits={-inf,inf,5e-09},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFPSettings[%CircleRadius]
	SetVariable TargetForce,pos={9,207},size={207,16},title="Target Force"
	SetVariable TargetForce,format="%.1W1PN"
	SetVariable TargetForce,limits={-inf,inf,5e-12},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFPSettings[%TargetForce]
	SetVariable ForceDistanceCFR,pos={65,202},size={179,16},disable=1,title="Force Distance"
	SetVariable ForceDistanceCFR,format="\\JR%.1W1Pm"
	SetVariable ForceDistanceCFR,limits={-inf,inf,1e-07},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Extension Distance'],styledText= 1
	SetVariable SamplingRateCFR,pos={65,229},size={179,16},disable=1,title="Sample Rate"
	SetVariable SamplingRateCFR,format="\\JR%.1W1PHz"
	SetVariable SamplingRateCFR,limits={500,50000,1000},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_Settings[%'Sampling Rate'],styledText= 1
	PopupMenu QuickSettings,pos={9,54},size={207,22},bodyWidth=135,proc=CFPQuickSettingsMenu,title="Quick Settings"
	PopupMenu QuickSettings,mode=6,popvalue="650nmDigDNA",value= #"CFPQuickSettingsList()"
	SetVariable CenteredRampCallbackSV,pos={44,256},size={200,16},disable=1,title="Callback"
	SetVariable CenteredRampCallbackSV,limits={500,50000,1000},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteredRamp_WaveNames[%Callback]
	PopupMenu CenteringMode,pos={9,81},size={108,22},bodyWidth=108,proc=CFPCenteringModePopMenuProc,title="Centering Mode"
	PopupMenu CenteringMode,mode=0,value= #"\"FullCentering;JustFineCentering;\""
	SetVariable LateralMoveSV,pos={9,227},size={207,16},title="Lateral Move Distance"
	SetVariable LateralMoveSV,help={"This will offset a distance from the center in the lateral direction for the final force ramp.  Only works with MoveThenForceRamp mode.  Don't use this for most things."}
	SetVariable LateralMoveSV,format="%.2W1Pm",limits={-inf,inf,5e-08},value= _NUM:0
	TitleBox CenteringTitle,pos={106,11},size={91,24},title="Centering",fSize=18
	TitleBox CenteringTitle,frame=0,fStyle=1
	TitleBox DCEventTitle,pos={115,468},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable CenteringDeflectionChannel,pos={9,248},size={207,16},title="Deflection Channel"
	SetVariable CenteringDeflectionChannel,help={"The channel the centering PID loop will use for deflection. If unsure, use Deflection"}
	SetVariable CenteringDeflectionChannel,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CFDeflectionChannel
	SetVariable CenteringDeflectionChannel1,pos={117,82},size={117,20},title=" "
	SetVariable CenteringDeflectionChannel1,help={"The channel the centering PID loop will use for deflection. If unsure, use Deflection"}
	SetVariable CenteringDeflectionChannel1,fSize=15
	SetVariable CenteringDeflectionChannel1,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:Centering_1:CenteringSettings[%CenteringMode]
	ToolsGrid snap=1,visible=1
EndMacro


