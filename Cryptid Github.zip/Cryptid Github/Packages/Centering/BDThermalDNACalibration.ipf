#pragma rtGlobals=3		// Use modern global access method and strict wave access.

function involstospring([T])
	
	Variable T
	if (paramisdefault(T))
		//This seems overly complicated to read the temp. Asylum agrees.
		T = Thmstr1ValueToDeg(8*td_ReadValue("Head.ADC")) + 273.15
	endif
	
	Variable f = GV("ThermalFrequency")
	Variable q = GV("ThermalQ")
	Variable DC = GV("ThermalDC")
	Variable ampInvols = GV("ampInvols")
	
	Variable DCVolts = DC/ampInvols
	Variable kb = 1.3806452e-23
	
	
	Variable SC = 2*kb*T / ((DCVolts*ampInvols)^2*pi*f*q)

	return SC
end

Function SCDNATherm(deflV, [T])


	Variable deflV //deflection Volts at DNA overstretch
	Variable T

	if (paramisdefault(T))
		
		//T =GV("EnvironSampleTemp")+273.15
		T = GV("ThermalTemperature")
	endif
	
	Variable Fdna = 65e-12 //N

	Variable f = GV("ThermalFrequency")
	Variable q = GV("ThermalQ")
	Variable DC = GV("ThermalDC")
	
		
	Variable DCVolts = DC/GV("AmpInvols")
	//DC is in meters/sqrt(Hz). Divide by the current invols (m/v) to get v/sqrt(Hz)
	
	Variable kb = 1.3806452e-23
	
	Variable SC = (DCVolts*1.09*Fdna)^2*pi*f*Q / (2*kb*T*deflV^2)
	
	Return SC

end

Function InvolsDNATherm(deflV, [T])
	
	Variable deflV,T //deflection Volts at DNA overstretch
	Variable Fdna = 65e-12 //N
	
	if (paramisdefault(T))
		//This seems overly complicated to read the temp. Asylum agrees.
		//T = GV("EnvironSampleTemp")+273.15
		T = GV("ThermalTemperature")
	endif
	
	Variable SC = SCDNATherm(deflV, T=T)
	Variable invols = Fdna / (DeflV*SC)
	
	return invols

end