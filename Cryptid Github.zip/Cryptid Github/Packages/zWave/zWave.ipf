#pragma TextEncoding = "UTF-8"
#pragma rtGlobals=3				// Use modern global access method and strict wave access
#pragma DefaultTab={3,20,4}		// Set default tab width in Igor Pro 9 and later

//Brandon Dzuba 11/30/2023
//This procedure creats a panel from which parameters for a z-wave can be set.
//The current intent is to either integrate this into Rob Walders code and/or implement my own panel to run
//Several kinds of experiments

//Menu "ZWave"
//	"Initialize ZWave", zWaveInitialize()
//	"Do zWave", doZWave()
//End

Function cryptidExecuteZWave()

	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	doZWave(vSettings,tSettings)

End


Function zWaveMakeSettings()

	loadCryptidSettings("ZWave","vSettings;tSettings",useCurrentDF=1)
	Make/O/N=0 zWaveWave

End

//Function that should be called after last step
//Function doZWave([previousDefV, previousZSensorV, previousIndentForce, zwParams, zwTextSettings, LowPositionV, HighPositionV, callback])
Function doZWave(vSettings,tSettings)

//	Wave previousDefV, previousZSensorV, zwParams
//	Wave/T zwTextSettingstSettings
//	Variable previousIndentForce, lowPositionV, highPositionV
//	String callback

	wave vSettings
	wave/t tSettings

	//Clear all events
//	Variable error = td_WS("Event."+num2str(vSettings[%CTFCEvent]), "Clear")
//	error += td_WS("Event."+num2str(vSettings[%feedbackStartEvent]), "Clear")
//	error += td_WS("Event."+num2str(vSettings[%feedbackStopEvent]), "Clear")
//	error += td_WS("Event."+num2str(vSettings[%outWaveStartEvent]), "Clear")
//	error += td_WS("Event."+num2str(vSettings[%outWaveStopEvent]), "Clear")	
//	cryptidDebug(diagString="Asylum Error in td_WS: "+num2str(Error))
	
	variable error = setupZWaveParameters(vSettings,tSettings)
	
	if (error)
		cryptidDebug(diagString="Error during setup of zWave params", updateDisplay=1)
		cryptidMain(0)
	endif
	
	//Move to the location of the start of the ramp (this now puts us in callback hell. Going to use the switch method to handle it
	zWaveRuntime(0)

End

Function setupZWaveParameters(vSettings,tSettings)

	wave vSettings
	wave/t tSettings
	
	Variable ZLVDTSens = GV("ZLVDTSens")

	vSettings[%approachSpeedVolts] = vSettings[%approachSpeed]  / ZLVDTSens
	vSettings[%retractSpeedVolts] = vSettings[%retractSpeed] / ZLVDTSens

	//////////////////////LOW POSITION///////////////////////////////
	Variable lowPositionVoltage
	
	//Get the surface voltage and any offsets
	if(vSettings[%useSurface])
		
		//Get the surface voltage
		variable surfaceVoltage = getSurfaceVoltage()
		if (surfaceVoltage ==-1)
			cryptidDebug(Diagstring="SurfaceVoltage not found", alwaysPrint = 1, alert = 1, message = 1, stopCryptid=1)
			return -1
		endif
		
		
		if(vSettings[%useSurfaceDistanceOffset])
			
			//Subtract the distanceFromLow in volts so that the offset is above the surface
			lowPositionVoltage = surfaceVoltage - vSettings[%SurfaceDistanceOffset] / ZLVDTSens
			print "Surface Voltage: "+ num2str(surfaceVoltage)
			print "Offset: "+num2str(vSettings[%SurfaceDistanceOffset]/ZLVDTSens)
		//Use the force from low
		elseif(vSettings[%useSurfaceForceOffset])
			lowPositionVoltage = getSurfaceVoltageForceOffset(vSettings[%surfaceForceOffset])
			if (lowPositionVoltage == -1)
				return -1
			endif
		endif
	
	//Check that the global variable exits and use that
	elseif(vSettings[%useLPGlobal])
	
		NVAR/Z GVSurface = $tSettings[%LPGlobalVariableName]
		if (!NVAR_exists(GVSurface))
			cryptidDebug(diagString="Low position SVAR not found", alwaysPrint=1,alert=1)
		else
			lowPositionVoltage = GVSurface
		endif
	endif
	
	vSettings[%lowPositionVolts] = lowPositionVoltage
	///////////////////////////////////////////////////////////////////////////////

	//////////////////////HIGH POSITION///////////////////////////////
	variable highPositionVoltage
	Make/O/T triggerInfo
	td_ReadGroup("ARC.CTFC",TriggerInfo)
	Wave zSensorVolts = getFirstRampWave("ZSensorVolts")
	Wave deflVolts = getFirstRampWave("DeflVolts")
	
	if (vSettings[%usedistanceFromLow])
		
		//High position is just a distance from the low
		highPositionVoltage = lowPositionVoltage - vSettings[%distanceFromLowPosition] / ZLVDTSens
		
	elseif(vSettings[%useforceFromLow])
		
		//Find the time at which the low position voltage happens
		WaveStats/Q zSensorVolts
		//Start from the indent position
		variable startp = v_maxRowLoc
		findLevel/Q/R=[startP] zSensorVolts, lowPositionVoltage
		if(v_flag)
			cryptidDebug(diagString="Low position voltage not found for high position", alwaysPrint=1,alert=1)
		endif
		variable lowPosTime = v_levelX
		
		//Find the deflV at that position, and offset it by the desired amount
		variable lowDeflV = deflVolts(lowPosTime)
		variable newDeflV = lowDeflV - vSettings[%forceFromLow] / GV("SpringConstant") / GV("Invols")
		
		//Find where that voltage occurs in zSensorVolts
		findLevel/Q/R=(lowPosTime) deflVolts, newDeflV
		if(v_flag)
			cryptidDebug(diagString="Unable to find high position force offset in force curve", alwaysPrint=1,alert=1)
		endif
		highPositionVoltage = zSensorVolts(v_levelX)

		
	elseif(vSettings[%useTriggerForHigh])
		
		//Get the time where the trigger happened		
		Variable triggerTime = str2num(triggerInfo[%triggerTime2])
		
		//If no forceOffsetFromTrigger, just use that
		if (vSettings[%forceOffsetFromTrigger])
			highPositionVoltage = zSensorVolts(triggerTime)
		//else we need to do a force offset
		else
			variable triggerDeflV = str2num(triggerInfo[%triggerValue2])
			variable deflVoffset = vSettings[%forceOffsetFromTrigger] / GV("SpringConstant") / GV("Invols")
			variable newDeflVPosition = triggerDeflV + abs(deflVOffset)
			
			//Find that position working backward
			wave deflVWave = getFirstRampWave("DeflVolts")
			startP = dimsize(deflVWave,0)-1
			
			findLevel/Q/R=[startP,0] deflVWave, newDeflVPosition
			if (v_flag)
				cryptidDebug(diagString="couldnt find force offset for high position", Alert = 1, alwaysPrint=1)
				return -1
			endif
			
			highPositionVoltage = zSensorVolts(v_levelX)
		endif
		
	elseif(vSettings[%useHPGlobal])
		
		NVAR/Z GVSurfaceHigh = $tSettings[%HPGlobalVariableName]
		if (!NVAR_exists(GVSurfaceHigh))
			cryptidDebug(diagString="Low position SVAR not found", alwaysPrint=1,alert=1)
		else
			HighPositionVoltage = GVSurfaceHigh
		endif
		
	endif

	killWaves triggerInfo
	vSettings[%HighPositionVolts] = HighPositionVoltage
	
	///////////////////////////////////////////////////////////////////////////////	

	//Values now set, make the appropriate zWave
	vSettings[%totalTime] = 0
	cryptidDebug(diagString="Making zWave with LP = "+num2str(vSettings[%lowPositionVolts])+"and HP = "+num2str(vSettings[%HighPositionVolts]))
	
	Wave zWaveWave = makeZWave(vSettings)

	Variable npnts = dimsize(zWaveWave,0)
	npnts -= mod(npnts,32)
	redimension/N=(npnts) zWaveWave
	
	//TotalTime should be the time of the zWave right now. Add the time it wil take to move to the start at 300 nm/s for now
	Variable moveTime = abs(td_RV("Cypher.LVDT.Z") - zWaveWave[0]) * GV("ZLVDTSens") / vSettings[%ctfcVelocity]
	
	vSettings[%totalTime] += moveTime + 3		//2.5 seconds found to be time needed to load wave (between CTFC and ZFeedback)

	return 0

End

Function zWaveRuntime(iter)

	Variable iter
	Wave zWaveWave
	Wave vSettings
	Wave/T tSettings
	cryptidDebug(diagString="Case: "+num2str(iter))
	
	//Going by 10's in case other things need to be added later
	switch (iter)
		
		//Set up the data recording, move to the start
		case 0:
			
			Variable overtime = 1 //may tweak based on actual experimental runtime
			Variable pnts = (vSettings[%totalTime] * vSettings[%captureRate]) * overtime
			
			pnts -= mod(pnts,32)
			
			Make/O/N=(pnts) deflVolts
			Make/O/N=(pnts) zSensorVolts
			
			//set to event 1, as 0 is most likely used for a capture of the entire experiment
			td_stopInWaveBank(vSettings[%SCBank]) //clears the bank I'm using
			
			Variable error
			//inWavePair's callback will trigger the end of the program
			error = td_xSetInWavePair(vSettings[%SCBank], num2str(vSettings[%CTFCEvent]), tSettings[%deflectionChannel], deflVolts, tSettings[%zSensorChannel], zSensorVolts,"zWaveRuntime(20)", ARGetDeci(vSettings[%CaptureRate]))		
			
			//CTFC callback will move to the section that handles the in wave
			//Removed feedback events, don't think they were needed
			programCTFC(triggerValue1 = zWaveWave[0], EventEnable = num2str(vSettings[%CTFCEvent]), Callback="zWaveRuntime(10)")//,eventDwell=num2str(vSettings[%feedbackStartEvent]),eventRamp=num2str(vSettings[%feedbackStopEvent]))
			
			setFeedback()
			cryptidDebug(diagString="Running CTFC")
			//For diagnostic purposes
			error = td_WS("Event."+num2str(vSettings[%CTFCEvent]), "Once")
			
			break
		
		case 10:
			//Setup for wait
			//setFeedback(setpoint = zWaveWave[0])
			cryptidDebug(diagString="Setting OutWave")
			//Start feedback for wait
			//td_WS("Event."+num2str(vSettings[%feedbackStartEvent]),"Once")
			td_stopOutWaveBank(vSettings[%outWaveBank])
			
			string eventString = num2str(vSettings[%outWaveStartEvent])+","+num2str(vSettings[%outWaveStopEvent])
			
			//Set the outWave to run to that feedback
			cryptidDebug(diagString="Setting OutWave with event: "+eventString)
			error = td_xSetOutWave(vSettings[%outWaveBank], eventString, "PIDSLoop.2.Setpoint", zWaveWave, vSettings[%interpolation])
			
			setFeedback(EventString = eventString,setpoint=zWaveWave[0], IGain =100000)
			
			//SetoutWave doesn't use callbacks for some dumb reason. Instead, we will wait for the callback of our data capture here
			updateStatus("Triggering Outwave")
			cryptidDebug(diagString="Triggering outWave,")
			
			cryptidDebug(diagString="Executing OutWaveStartEvent "+num2str(vSettings[%outWaveStartEvent]))
			error = td_WS("Event."+num2str(vSettings[%outWaveStartEvent]),"Once")
			
			if (error)
				cryptidDebug(diagString="Asylum Error: "+num2str(Error), alwaysPrint=1)
			endif
			
			break
			
		case 20:
			cryptidDebug(diagString="Stopping OutWave")
			td_WS("Event."+num2str(vSettings[%outWaveStopEvent]), "Once")
			td_stopInWavebank(vSettings[%SCBank])
			td_stopOutWaveBank(vSettings[%outWaveBank])
			
			Wave deflVolts, zSensorVolts

			//Will add failure parameters later
			string params = "zWaveRetractVelocity;zWaveApproachVelocity"
			string values = num2str(vSettings[%retractSpeed])+";"+num2str(vSettings[%approachSpeed])+";"
			writeToStdOut(params,values)
			
			updateCryptidGraph(deflVolts=deflVolts, zSensorVolts=zSensorVolts)
			cryptidMain(1, deflVolts=deflVolts, zSensorVolts=zSensorVolts)
			
			break
			
//		case 30:
//			break
	
	endswitch

End


//Makes a zWave given everything in voltages
Function/WAVE makeZWave(vSettings, [sampleRate])
	

	//MAX wave size must be 87,380
	Wave vSettings
	Variable  sampleRate
	
	Variable repeats,  AS,  RS,  LP,  LPO,  DTL,  HP,  HPO,  DTH
	repeats = vSettings[%repeats]
	AS = vSettings[%approachSpeedVolts]
	RS = vSettings[%retractSpeedVolts]
	LP = vSettings[%lowPositionVolts]
	DTL = vSettings[%DwellTimeLow]
	HP = vSettings[%HighPositionVolts]
	DTH = vSettings[%dwellTimeHigh]
	
	//NOTE: On the cypher, +Z moves the stage upward, thus closer to the cantilever, -Z moves away from the cantilever
	//In my code, I will use UP to refer to moving the cantilever away from the stage, and down for towards the stage. Sorry.
	
	//Start by assuming 50000, then scale down and return an interp factor such that numpnts < 87,380
	
	if (paramIsDefault(sampleRate))
		sampleRate = 50000
	endif

	//Check the total time this will take, calculate points based on that and the sample rate
	Variable totalTime = repeats * ( abs((HP-LP)/AS)+DTL + abs((LP-HP)/RS)+DTH )
	Variable pnts = floor(totalTime*sampleRate)
	
	//Check pnts, as there is a max amount for an out wave
	if (pnts > 87380)
		Variable interpolation = ceil(pnts/87380)
		sampleRate *= 1/interpolation
		pnts = floor(totalTime*sampleRate)
	else
		interpolation = 1
	endif
	
	//Calculate appropriate increments between the points for the wave
	Variable downPnts = floor(abs((HP-LP)/AS) * sampleRate)
	Variable downIncrement = (LP-HP) / downPnts
	Variable downPausePnts = floor(DTL * sampleRate)
	
	//Calculate appropriate increments between the points for the wave
	Variable upPnts =  floor(abs((LP-HP)/RS) * sampleRate)
	Variable upIncrement = (HP-LP) / upPnts
	Variable UpPausePnts = floor(DTH * sampleRate)
	
	//Going to go from high to low (I think this is the most likely use case, might change later to add an option)
	Make/O/N=(pnts) zWaveWave
	setScale/P x, 0, (1/sampleRate), "s", zWaveWave
	
	Variable iter
	Variable pntNum = 0
	Variable currentV = HP
	
	//For every repeat
	for (iter=0;iter<repeats;iter+=1)
		
		//Make donward track
		zWaveWave[pntNum,(pntNum+downPnts-1)] = currentV + downIncrement*(p-pntNum)
		pntNum += downPnts
		currentV = zWaveWave[pntNum-1]
		
		//Make downward pause
		if (downPausePnts != 0)
			zWaveWave[pntNum,(pntNum+downPausePnts-1)] = currentV
			pntNum += downPausePnts
		endif
				
		//Make upWard track
		zWaveWave[pntNum,(pntNum+upPnts-1)] = currentV + upIncrement*(p-pntNum)
		pntNum += upPnts
		currentV = zWaveWave[pntNum-1]	
			
		//Make upward pause
		if (upPausePnts != 0)
			zWaveWave[pntNum,(pntNum+upPausePnts-1)] = currentV
			pntNum += upPausePnts
		endif

	Endfor
	
	vSettings[%interpolation] = interpolation
	vSettings[%totalTime] += totalTime
	vSettings[%zWaveTime] = totalTime
	
	//Clean some extra points
	deletePoints pntNum, (dimsize(zWaveWave,0)+1)-pntNum, zWaveWave
	
	//Make a factor of 32 point
	Variable npnts = dimsize(zWaveWave,0)
	npnts -= mod(npnts,32)
	redimension/N=(npnts) zWaveWave
	
	return zWaveWave
	
End


Function ZWaveSetVarProc(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva
	wave vSettings
	
	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
			
			//Use to ensure only one parameter is actually checked. Relies on each control being named exactly after
			//the parameter in vSettings they are changing.
			Wave vSettings
			string ctrlName = sva.ctrlName
			if (stringMatch("useSurface",ctrlName))
				vSettings[%useLPGlobal] = !sva.dVal
			endif
			if (stringMatch("useLPGlobal",ctrlName))
				vSettings[%useSurface] = !sva.dVal
			endif
			if (stringMatch("useSurfaceDistanceOffset",ctrlName))
				vSettings[%useSurfaceForceOffset] = !sva.dVal
			endif
			if (stringMatch("useSurfaceForceOffset",ctrlName))
				vSettings[%useSurfaceDistanceOffset] = !sva.dVal
			endif
			
			String HighPosList = "useDistanceFromLow;useForceFromLow;UseTriggerForHigh;useHPGlobal;"
			variable which = whichListItem(ctrlName,HighPosList)
			if ((which !=-1) && sva.dval == 1)		
				variable i	
				for (i=0;i<itemsInList(highPosList);i+=1)
					vSettings[%$stringFromList(i,HighPosList)] = (which == i)
				endfor
			endif
			break
			
		case 3: // Live update

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function ZWButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			strSwitch( ba.ctrlName)
				//case "ZWMakeZWave":
				//	makeZWave(zWaveWave)
					break
				case "ZWShowSettings1":
					wave/t tSettings
					wave vSettings
					edit tSettings.ld
					edit vSettings.ld
					break			
			endSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function MakezWavePanel([PanelName,WindowName,hostName]) : Panel

	String PanelName,WindowName, hostName
	Wave vSettings
	Wave/T tSettings
	
	If(ParamIsDefault(WindowName))
		WindowName="zWave"
	EndIf
	If(ParamIsDefault(PanelName))
		PanelName="zWavePanel"
	EndIf
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	//If no hostname, make as independent window
	if (paramIsDefault(hostName))
		NewPanel/W=(0,0,280,700)/N=$PanelName as WindowName
	else
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	
	ModifyPanel cbRGB=(47872,47872,47872)
	
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,525,270,525
	SetDrawEnv linethick= 2
	DrawLine 9,126,270,126
	SetDrawEnv linethick= 2
	DrawLine 9,297,270,297
	SetDrawEnv linethick= 2
	DrawLine 9,436,270,436
	SetVariable ZWRepeats,pos={10,54},size={206,16},bodyWidth=159,title="Repeats "
	SetVariable ZWRepeats,help={"Number of Repeats"}
	SetVariable ZWRepeats,limits={1,inf,1},value= vSettings[%Repeats]
	SetVariable ZWApproachSpeed,pos={9,76},size={207,16},bodyWidth=123,title="Approach Speed"
	SetVariable ZWApproachSpeed,help={"Approach Speed"},format="%.1W1Pm/s"
	SetVariable ZWApproachSpeed,limits={-inf,inf,0},value= vSettings[%ApproachSpeed]
	SetVariable ZWRetractSpeed,pos={9,99},size={207,16},bodyWidth=131,title="Retract Speed "
	SetVariable ZWRetractSpeed,help={"Retract Speed"},format="%.1W1Pm/s"
	SetVariable ZWRetractSpeed,limits={-inf,inf,0},value= vSettings[%RetractSpeed]
	SetVariable ZWDwellTimeLow,pos={11,270},size={228,16},bodyWidth=172,title="Dwell Time"
	SetVariable ZWDwellTimeLow,help={"Dwell time at the low position"}
	SetVariable ZWDwellTimeLow,format="%.1W1Ps"
	SetVariable ZWDwellTimeLow,limits={-inf,inf,0},value= vSettings[%DwellTimeLow]
	TitleBox ZWaveLowPositionTitle,pos={108,132},size={68,21},title="Low Position"
	TitleBox ZWaveHighPositionTitle1,pos={109,306},size={70,21},title="High Position"
	TitleBox ZWaveTitle,pos={108,11},size={72,24},title="Z-Wave",fSize=18,frame=0
	TitleBox ZWaveTitle,fStyle=1
	TitleBox DCEventTitle,pos={115,492},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable ZWDeflectionChannel,pos={9,450},size={223,16},bodyWidth=129,title="Deflection Channel"
	SetVariable ZWDeflectionChannel,help={"Channel to record"}
	SetVariable ZWDeflectionChannel,limits={-inf,inf,0},value= tSettings[%DeflectionChannel]
	SetVariable ZWZSensorChannel,pos={11,473},size={227,16},bodyWidth=141,title="ZSensor Channel"
	SetVariable ZWZSensorChannel,help={"Channel to record"}
	SetVariable ZWZSensorChannel,limits={-inf,inf,0},value= tSettings[%ZSensorChannel]
	SetVariable ZWCTFCEvent,pos={11,535},size={133,16},bodyWidth=71,title="CTFC Event"
	SetVariable ZWCTFCEvent,help={"Offset for the Low Position"}
	SetVariable ZWCTFCEvent,limits={-inf,inf,0},value= vSettings[%CTFCEvent]
	SetVariable ZWOutwaveEvent,pos={9,557},size={130,16},bodyWidth=55,title="OutWave Start"
	SetVariable ZWOutwaveEvent,help={"Offset for the Low Position"}
	SetVariable ZWOutwaveEvent,limits={-inf,inf,0},value= vSettings[%outWaveStartEvent]
	SetVariable ZWOutWaveStop,pos={9,579},size={130,16},bodyWidth=55,title="OutWave Stop"
	SetVariable ZWOutWaveStop,help={"Offset for the Low Position"}
	SetVariable ZWOutWaveStop,limits={-inf,inf,0},value= vSettings[%outWaveStopEvent]
	SetVariable ZWOutWaveBank,pos={9,602},size={131,16},bodyWidth=53,title="OutWave Bank"
	SetVariable ZWOutWaveBank,help={"Offset for the Low Position"}
	SetVariable ZWOutWaveBank,limits={-inf,inf,0},value= vSettings[%outWaveBank]
	SetVariable ZWSCBank,pos={10,624},size={134,16},bodyWidth=88,title="SC Bank"
	SetVariable ZWSCBank,help={"Offset for the Low Position"}
	SetVariable ZWSCBank,limits={-inf,inf,0},value= vSettings[%SCBank]
	SetVariable UseSurface,pos={9,162},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseSurface,help={"Dwell time at the low position"}
	SetVariable UseSurface,limits={0,1,1},value= vSettings[%UseSurface]
	TitleBox UseSurfaceTitle,pos={45,164},size={59,13},title="Use Surface"
	TitleBox UseSurfaceTitle,help={"Use the surface for the low position, determined from the first ramp run in the stack"}
	TitleBox UseSurfaceTitle,frame=0
	TitleBox UseGlobalVariable,pos={45,227},size={93,13},title="Use Global Variable"
	TitleBox UseGlobalVariable,help={"Helpful if you ran a function earlier to determine the voltage. Store that in a global variable and put the string pointing to it here"}
	TitleBox UseGlobalVariable,frame=0
	SetVariable UseLPGlobal,pos={9,225},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseLPGlobal,help={"Dwell time at the low position"}
	SetVariable UseLPGlobal,limits={0,1,1},value= vSettings[%useLPGlobal]
	SetVariable DistanceOffset,pos={63,181},size={144,16},bodyWidth=67,title="Distance Offset"
	SetVariable DistanceOffset,help={"Offset from the surface in meters. Obviously always above the surface, don't put a negative value if you care about your tip"}
	SetVariable DistanceOffset,format="%.1W1Pm"
	SetVariable DistanceOffset,limits={-inf,inf,0},value= vSettings[%surfaceDistanceOffset]
	SetVariable useSurfaceDistanceOffset,pos={27,182},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useSurfaceDistanceOffset,help={"Dwell time at the low position"}
	SetVariable useSurfaceDistanceOffset,limits={0,1,1},value= vSettings[%useSurfaceDistanceOffset]
	SetVariable UseSurfaceForceOffset,pos={27,200},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseSurfaceForceOffset,help={"Dwell time at the low position"}
	SetVariable UseSurfaceForceOffset,limits={0,1,1},value= vSettings[%useSurfaceForceOffset]
	SetVariable SurfaceForceOffset,pos={63,199},size={144,16},bodyWidth=82,title="Force Offset"
	SetVariable SurfaceForceOffset,help={"Force offset from the surface. Should always be a positive value if you care about your tip"}
	SetVariable SurfaceForceOffset,format="%.1W1PN"
	SetVariable SurfaceForceOffset,limits={-inf,inf,0},value= vSettings[%surfaceForceOffset]
	SetVariable ZWLowPosition1,pos={28,248},size={242,16},bodyWidth=123,title="Global Variable Location"
	SetVariable ZWLowPosition1,help={"String containing the location of a global variable to use for the low position voltage. MUST BE IN Cypher.LVDT.Z voltage!!"}
	SetVariable ZWLowPosition1,limits={-inf,inf,0},value= tSettings[%LPGlobalVariableName]
	SetVariable useDistanceFromLow,pos={9,333},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useDistanceFromLow,help={"Dwell time at the low position"}
	SetVariable useDistanceFromLow,limits={0,1,1},value= vSettings[%useDistanceFromLow]
	SetVariable DistanceFromLowPosition,pos={45,334},size={155,16},bodyWidth=67,title="Distance from low"
	SetVariable DistanceFromLowPosition,help={"Distance offset from the low position. Will obviously be above the low position"}
	SetVariable DistanceFromLowPosition,format="%.1W1Pm"
	SetVariable DistanceFromLowPosition,limits={-inf,inf,0},value= vSettings[%distanceFromLowPosition]
	SetVariable ZWLowPosition2,pos={45,389},size={184,16},bodyWidth=65,title="Global Variable Location"
	SetVariable ZWLowPosition2,help={"String containing the location of a global variable to use for the low position voltage. MUST BE IN Cypher.LVDT.Z voltage!!"}
	SetVariable ZWLowPosition2,limits={-inf,inf,0},value= tSettings[%HPGlobalVariableName]
	SetVariable useForceFromLow,pos={9,353},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useForceFromLow,help={"Dwell time at the low position"}
	SetVariable useForceFromLow,limits={0,1,1},value= vSettings[%useForceFromLow]
	SetVariable ForceFromLow,pos={45,352},size={140,16},bodyWidth=67,title="Force from low"
	SetVariable ForceFromLow,help={"Force offset from the low position. First ramp CTFC will be used to find this force above the low position"}
	SetVariable ForceFromLow,format="%.1W1PN"
	SetVariable ForceFromLow,limits={-inf,inf,0},value= vSettings[%forceFromLow]
	SetVariable UseTriggerForHigh,pos={9,369},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseTriggerForHigh,help={"Dwell time at the low position"}
	SetVariable UseTriggerForHigh,limits={0,1,1},value= vSettings[%useTriggerForHigh]
	SetVariable ForceFromLow1,pos={45,369},size={182,16},bodyWidth=67,title="Force offset from trigger"
	SetVariable ForceFromLow1,help={"A force offset from the trigger of the first ramp CTFC. It will be a force BELOW the trigger value, since this is needed to find it"}
	SetVariable ForceFromLow1,format="%.1W1PN"
	SetVariable ForceFromLow1,limits={-inf,inf,0},value= vSettings[%forceOffsetFromTrigger]
	SetVariable useHPGlobal,pos={9,389},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useHPGlobal,help={"Dwell time at the low position"}
	SetVariable useHPGlobal,limits={0,1,1},value= vSettings[%useHPGlobal]
	SetVariable ZWDwellTimeHigh,pos={11,410},size={228,16},bodyWidth=172,title="Dwell Time"
	SetVariable ZWDwellTimeHigh,help={"Dwell time at the high position"}
	SetVariable ZWDwellTimeHigh,format="%.1W1Ps"
	SetVariable ZWDwellTimeHigh,limits={-inf,inf,0},value= vSettings[%DwellTimeHigh]


End


Window zWavePanel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /W=(1272,116,1552,816) as "zWave"
	ModifyPanel cbRGB=(47872,47872,47872)
	ShowTools/A
	ShowInfo/W=zWavePanel
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,525,270,525
	SetDrawEnv linethick= 2
	DrawLine 9,126,270,126
	SetDrawEnv linethick= 2
	DrawLine 9,297,270,297
	SetDrawEnv linethick= 2
	DrawLine 9,436,270,436
	SetVariable ZWRepeats,pos={10,54},size={206,16},bodyWidth=159,title="Repeats "
	SetVariable ZWRepeats,help={"Number of Repeats"}
	SetVariable ZWRepeats,limits={1,inf,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%Repeats]
	SetVariable ZWApproachSpeed,pos={9,76},size={207,16},bodyWidth=123,title="Approach Speed"
	SetVariable ZWApproachSpeed,help={"Approach Speed"},format="%.1W1Pm/s"
	SetVariable ZWApproachSpeed,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%ApproachSpeed]
	SetVariable ZWRetractSpeed,pos={9,99},size={207,16},bodyWidth=131,title="Retract Speed "
	SetVariable ZWRetractSpeed,help={"Retract Speed"},format="%.1W1Pm/s"
	SetVariable ZWRetractSpeed,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%RetractSpeed]
	SetVariable ZWDwellTimeLow,pos={11,270},size={228,16},bodyWidth=172,title="Dwell Time"
	SetVariable ZWDwellTimeLow,help={"Dwell time at the low position"}
	SetVariable ZWDwellTimeLow,format="%.1W1Ps"
	SetVariable ZWDwellTimeLow,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%DwellTimeLow]
	TitleBox ZWaveLowPositionTitle,pos={108,132},size={68,21},title="Low Position"
	TitleBox ZWaveHighPositionTitle1,pos={109,306},size={70,21},title="High Position"
	TitleBox ZWaveTitle,pos={108,11},size={72,24},title="Z-Wave",fSize=18,frame=0
	TitleBox ZWaveTitle,fStyle=1
	TitleBox DCEventTitle,pos={115,492},size={63,24},title="Events",fSize=18,frame=0
	TitleBox DCEventTitle,fStyle=1
	SetVariable ZWDeflectionChannel,pos={9,450},size={223,16},bodyWidth=129,title="Deflection Channel"
	SetVariable ZWDeflectionChannel,help={"Channel to record"}
	SetVariable ZWDeflectionChannel,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:tSettings[%DeflectionChannel]
	SetVariable ZWZSensorChannel,pos={11,473},size={227,16},bodyWidth=141,title="ZSensor Channel"
	SetVariable ZWZSensorChannel,help={"Channel to record"}
	SetVariable ZWZSensorChannel,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:tSettings[%ZSensorChannel]
	SetVariable ZWCTFCEvent,pos={11,535},size={133,16},bodyWidth=71,title="CTFC Event"
	SetVariable ZWCTFCEvent,help={"Offset for the Low Position"}
	SetVariable ZWCTFCEvent,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%CTFCEvent]
	SetVariable ZWOutwaveEvent,pos={9,557},size={130,16},bodyWidth=55,title="OutWave Start"
	SetVariable ZWOutwaveEvent,help={"Offset for the Low Position"}
	SetVariable ZWOutwaveEvent,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%outWaveStartEvent]
	SetVariable ZWOutWaveStop,pos={9,579},size={130,16},bodyWidth=55,title="OutWave Stop"
	SetVariable ZWOutWaveStop,help={"Offset for the Low Position"}
	SetVariable ZWOutWaveStop,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%outWaveStopEvent]
	SetVariable ZWOutWaveBank,pos={9,602},size={131,16},bodyWidth=53,title="OutWave Bank"
	SetVariable ZWOutWaveBank,help={"Offset for the Low Position"}
	SetVariable ZWOutWaveBank,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%outWaveBank]
	SetVariable ZWSCBank,pos={10,624},size={134,16},bodyWidth=88,title="SC Bank"
	SetVariable ZWSCBank,help={"Offset for the Low Position"}
	SetVariable ZWSCBank,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%SCBank]
	SetVariable UseSurface,pos={9,162},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseSurface,help={"Dwell time at the low position"}
	SetVariable UseSurface,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%UseSurface]
	TitleBox UseSurfaceTitle,pos={45,164},size={59,13},title="Use Surface"
	TitleBox UseSurfaceTitle,help={"Use the surface for the low position, determined from the first ramp run in the stack"}
	TitleBox UseSurfaceTitle,frame=0
	TitleBox UseGlobalVariable,pos={45,227},size={93,13},title="Use Global Variable"
	TitleBox UseGlobalVariable,help={"Helpful if you ran a function earlier to determine the voltage. Store that in a global variable and put the string pointing to it here"}
	TitleBox UseGlobalVariable,frame=0
	SetVariable UseLPGlobal,pos={9,225},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseLPGlobal,help={"Dwell time at the low position"}
	SetVariable UseLPGlobal,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useLPGlobal]
	SetVariable DistanceOffset,pos={63,181},size={144,16},bodyWidth=67,title="Distance Offset"
	SetVariable DistanceOffset,help={"Offset from the surface in meters. Obviously always above the surface, don't put a negative value if you care about your tip"}
	SetVariable DistanceOffset,format="%.1W1Pm"
	SetVariable DistanceOffset,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%surfaceDistanceOffset]
	SetVariable useSurfaceDistanceOffset,pos={27,182},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useSurfaceDistanceOffset,help={"Dwell time at the low position"}
	SetVariable useSurfaceDistanceOffset,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useSurfaceDistanceOffset]
	SetVariable UseSurfaceForceOffset,pos={27,200},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseSurfaceForceOffset,help={"Dwell time at the low position"}
	SetVariable UseSurfaceForceOffset,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useSurfaceForceOffset]
	SetVariable SurfaceForceOffset,pos={63,199},size={144,16},bodyWidth=82,title="Force Offset"
	SetVariable SurfaceForceOffset,help={"Force offset from the surface. Should always be a positive value if you care about your tip"}
	SetVariable SurfaceForceOffset,format="%.1W1PN"
	SetVariable SurfaceForceOffset,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%surfaceForceOffset]
	SetVariable ZWLowPosition1,pos={28,248},size={242,16},bodyWidth=123,title="Global Variable Location"
	SetVariable ZWLowPosition1,help={"String containing the location of a global variable to use for the low position voltage. MUST BE IN Cypher.LVDT.Z voltage!!"}
	SetVariable ZWLowPosition1,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:tSettings[%LPGlobalVariableName]
	SetVariable useDistanceFromLow,pos={9,333},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useDistanceFromLow,help={"Dwell time at the low position"}
	SetVariable useDistanceFromLow,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useDistanceFromLow]
	SetVariable DistanceFromLowPosition,pos={45,334},size={155,16},bodyWidth=67,title="Distance from low"
	SetVariable DistanceFromLowPosition,help={"Distance offset from the low position. Will obviously be above the low position"}
	SetVariable DistanceFromLowPosition,format="%.1W1Pm"
	SetVariable DistanceFromLowPosition,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%distanceFromLowPosition]
	SetVariable ZWLowPosition2,pos={45,389},size={184,16},bodyWidth=65,title="Global Variable Location"
	SetVariable ZWLowPosition2,help={"String containing the location of a global variable to use for the low position voltage. MUST BE IN Cypher.LVDT.Z voltage!!"}
	SetVariable ZWLowPosition2,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:tSettings[%HPGlobalVariableName]
	SetVariable useForceFromLow,pos={9,353},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useForceFromLow,help={"Dwell time at the low position"}
	SetVariable useForceFromLow,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useForceFromLow]
	SetVariable ForceFromLow,pos={45,352},size={140,16},bodyWidth=67,title="Force from low"
	SetVariable ForceFromLow,help={"Force offset from the low position. First ramp CTFC will be used to find this force above the low position"}
	SetVariable ForceFromLow,format="%.1W1PN"
	SetVariable ForceFromLow,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%forceFromLow]
	SetVariable UseTriggerForHigh,pos={9,369},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable UseTriggerForHigh,help={"Dwell time at the low position"}
	SetVariable UseTriggerForHigh,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useTriggerForHigh]
	SetVariable ForceFromLow1,pos={45,369},size={182,16},bodyWidth=67,title="Force offset from trigger"
	SetVariable ForceFromLow1,help={"A force offset from the trigger of the first ramp CTFC. It will be a force BELOW the trigger value, since this is needed to find it"}
	SetVariable ForceFromLow1,format="%.1W1PN"
	SetVariable ForceFromLow1,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%forceOffsetFromTrigger]
	SetVariable useHPGlobal,pos={9,389},size={27,16},bodyWidth=27,proc=ZWaveSetVarProc,title=" "
	SetVariable useHPGlobal,help={"Dwell time at the low position"}
	SetVariable useHPGlobal,limits={0,1,1},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%useHPGlobal]
	SetVariable ZWDwellTimeHigh,pos={11,410},size={228,16},bodyWidth=172,title="Dwell Time"
	SetVariable ZWDwellTimeHigh,help={"Dwell time at the high position"}
	SetVariable ZWDwellTimeHigh,format="%.1W1Ps"
	SetVariable ZWDwellTimeHigh,limits={-inf,inf,0},value= root:Settings:Cryptid:WorkingFolders:zWave_1:vSettings[%DwellTimeHigh]
EndMacro
