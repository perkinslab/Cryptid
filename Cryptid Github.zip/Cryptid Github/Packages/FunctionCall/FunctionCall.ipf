#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//TIP: Copy this file into the desired package folder, rename it to your package name,
//Then run ctrlF and use ctr+V to replace "Example" with you actual package name


//************EXECUTE COMMAND*************
//This is a wrapper function for cryptid to call
//Put the name in the executables file
Function cryptidExecuteFunctionCall()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	DoFunctionCall(vSettings,tSettings)
	

End


//Just calls a function with the given name and arguments.
Function DoFunctionCall(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings
	
	Variable Error=0
	
	//Call the function with the arguments
	string functionName = tSettings[%functionName]
	string arguments = tSettings[%arguments]
	
	string executeString = functionName+"("+arguments+")"
	
	tSettings[%fullCall] = executeString
	
	execute executeString
	
End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeFunctionCallSettings()
	
	String packageName = "FunctionCall"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

	//Alternatively, you can construct the waves here
End



//Cryptid calls this function by passing its own values to panelName, widowName, and hostName
//This function is written so that if you call it with defaults, it will make its own window
//I highly recommend copying large parts of this function, and just replacing that last part
// 
//For easiest modification, make your panel using the graphical tools for panel making,
//Save it, and then copy the control's code to the bottom of this function
//You will need to replace all values to vSettings,tSettings instead of absolute paths to 
//make it work (I.E.): value=root:Settings:ExamplePackage:vSettings[%someValue] will need to be changed
//to 						value=vSettings[%someValue] to work with cryptid
////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeFunctionCallPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="FunctionCallPanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="FunctionCallWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	//You can use getRTStackInfo to pass the name of the function that called this function, which can be helpful
	cryptidDebug(diagString="Called by: "+GetRTStackInfo(2))
	
	PauseUpdate; Silent 1		// building window...
	
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	
	TitleBox FunctionCallTitle,pos={85,11},size={120,24},title="Function Call"
	TitleBox FunctionCallTitle,fSize=18,frame=0,fStyle=1
	SetVariable FunctionName,pos={9.00,54.00},size={207.00,18.00}
	SetVariable FunctionName,title="Function Name"
	SetVariable FunctionName,limits={0,inf,5e-12},value=tSettings[%FunctionName]
	SetVariable Arguments,pos={9.00,81.00},size={207.00,18.00}
	SetVariable Arguments,title="Arguments"
	SetVariable Arguments,value=tSettings[%Arguments]



End

Function testFunction(printStatement,[callback])

	string printStatement, callback
	
	if(paramIsDefault(callback))
		callback = ""
	endif
	
	print printStatement
	
	execute callback
End

