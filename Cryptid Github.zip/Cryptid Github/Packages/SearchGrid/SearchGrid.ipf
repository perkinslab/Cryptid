#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.0
#include ":Dependencies:ClosedLoopMotion"
#include ":Dependencies:WaveDimNote"
#include ":Dependencies:ParseDateTime"

// New for version 2.0
// Now loading settings wave from a file.
// Also setting a bunch of quick settings for different molecules.

//Menu "Search for Molecule"
//	"Initialize Search Grid", InitSearch(ShowUserInterface=1)
//	"Show Search Grid Panel", Execute "Search_Panel()"
//	"Show Search Grid Graph",ShowSearchInfo("SearchGrids")
//End


Function InitSearch([ShowUserInterface, justReset])
	Variable ShowUserInterface, justReset

	
	cryptidDebug()
	
	If(ParamIsDefault(ShowUserInterface))
		ShowUserInterface=1
	EndIf
	
		
	If(ParamIsDefault(justReset))
		justReset=0
	EndIf
	
	if (!JustReset)
		NewDataFolder/O root:Settings:SearchGrid
		SetDataFolder root:Settings:SearchGrid
		// Load External Parm waves
		loadCryptidSettings("SearchGrid","searchSettings;searchQuickSettings")

  	
		Make/N=2/O root:Settings:SearchGrid:MoveToSpot
		Wave MoveToSpot=root:Settings:SearchGrid:MoveToSpot
		SetDimLabel 0,0, $"CoarseSpotNumber", MoveToSpot
		SetDimLabel 0,1, $"FineSpotNumber", MoveToSpot
		MoveToSpot={0,-1}
      	endif
      	
	Make/T/O/N=2 root:Settings:SearchGrid:SearchMode
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
    	SetDimLabel 0,0, $"CurrentMode", SearchMode
    	SetDimLabel 0,1, $"Callback", SearchMode
    	SearchMode={"Coarse",""}
    	
    	//BDEDIT - Add functionality to tell SearchForMolecule a cantilever identifier
    	Make/T/O/N=3 root:Settings:SearchGrid:MiscInfo
    	Wave/T miscInfo = root:Settings:SearchGrid:MiscInfo
    	SetDimLabel 0,0, $"searchGraphName",MiscInfo
    	SetDimLabel 0,1, $"marqueeLeft",MiscInfo
    	SetDimLabel 0,2, $"marqueeBottom",MiscInfo
	
      	Make/N=1/O root:Settings:SearchGrid:PreviousX
      	Make/N=1/O root:Settings:SearchGrid:PreviousY
      	Make/N=1/O root:Settings:SearchGrid:CurrentX
      	Make/N=1/O root:Settings:SearchGrid:CurrentY
      	Make/N=1/O root:Settings:SearchGrid:FoundX
      	Make/N=1/O root:Settings:SearchGrid:FoundY
      	Make/N=1/O root:Settings:SearchGrid:FoundCoarseNumber
      	Wave FoundX=root:Settings:SearchGrid:FoundX
      	WAve FoundY=root:Settings:SearchGrid:FoundY
      	WAve FoundCoarseNumber=root:Settings:SearchGrid:FoundCoarseNumber
	FoundX[0]=NaN
	FoundY[0]=NaN
	FoundCoarseNumber[0]=NaN
	
	if (!JustReset)
		MakeCoarseGrid()    	
    		MakeFineGrid(0,0)
    		GoToLocation(0,0)
    	endif
    	
    	DoWindow/Z Search_Panel
	Variable UserInterfaceVisible=V_flag
	
	If(ShowUserInterface&&!UserInterfaceVisible)
	    	cryptidDebug(diagString="Making Search Panel...")
	    	Execute "Search_Panel()"
	EndIf

End

Function/S SearchQuickSettingsList()
	cryptidDebug()
	Wave SearchQuickSettings=root:Settings:SearchGrid:SearchQuickSettings
	Return GetWaveDimNames(SearchQuickSettings,DimNumber=1)
End

Function SearchGridHookFunction(s)
	STRUCT WMWinHookStruct &s

	//BDEDIT for MP function
	Wave/T miscInfo=root:Settings:SearchGrid:miscInfo
	
	Variable hookResult = 0	// 0 if we do not handle event, 1 if we handle it.
	Variable RightClick=(s.eventmod & 2^4)!=0
	Variable ControlButton=(s.eventmod & 2^3)!=0
	
	//BDEDIT for MP function
	Variable MouseXPos=AxisValFromPixel(miscInfo[%searchGraphName],"bottom",s.mouseloc.h)
	Variable MouseYPos=AxisValFromPixel(miscInfo[%searchGraphName],"left",s.mouseloc.v)
	
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode

	switch(s.eventCode)
		case 3:	// Mouse down event
			
			If(RightClick&&ControlButton)
				doAlert 1, "Move to new location?"
				if (v_flag == 1)
					movetoCoarseSpot(closestPoint(MouseXPos, MouseYPos))
					
					hookResult=1
				endif
			EndIf
		break	
	EndSwitch			
	return hookResult
End

Function moveToCoarseSpot(coarseSpot,[fineSpot])

	variable coarseSpot, fineSpot
	if (paramIsDefault(fineSpot))
		fineSpot = -1
	endif

	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
	
	SearchSettings[%IterationsAtCurrentSpot]=1
	SearchMode[%CurrentMode]="Coarse"
	
	//Move to the closest coarse spot
	Wave MoveToSpot=root:Settings:SearchGrid:MoveToSpot
	MoveToSpot[%coarseSpotNumber] = coarseSpot
	MoveToSpot[%fineSpotNumber] = fineSpot
	
	SearchSettings[%CoarseSpotNumber]=MoveToSpot[%CoarseSpotNumber]-1
	SearchSettings[%FineSpotNumber]=MoveToSpot[%FineSpotNumber]-1

	If(MoveToSpot[%FineSpotNumber]==-1)
		SearchSettings[%FineSpotNumber]=-1
		NextPosition("Coarse")
	Else
		NextPosition("Fine")
	EndIf
					
End

//BDEdit - Added graphName to display the searchGrid on top of an existing graph. Useful for when imaging is needed (membrane proteins)
Function ShowSearchInfo(SelectedDisplay, [graphName])
	
	String SelectedDisplay
	//BDEDIT
	
	String graphName
	if (paramIsDefault(graphName))
		graphName = "SearchGridDisplay"
	endif
	cryptidDebug()
	Wave searchSettings = root:Settings:SearchGrid:SearchSettings
	Wave/T miscInfo = root:Settings:SearchGrid:MiscInfo
	miscInfo[%searchGraphName] = graphName

	Wave CoarseGridX=root:Settings:SearchGrid:CoarseGridX
	Wave CoarseGridY=root:Settings:SearchGrid:CoarseGridY
	Wave FineGridX=root:Settings:SearchGrid:FineGridX
	Wave FineGridY=root:Settings:SearchGrid:FineGridY
	Wave PreviousX=root:Settings:SearchGrid:PreviousX
	Wave PreviousY=root:Settings:SearchGrid:PreviousY
	Wave CurrentX=root:Settings:SearchGrid:CurrentX
	Wave CurrentY=root:Settings:SearchGrid:CurrentY
	Wave FoundX=root:Settings:SearchGrid:FoundX
	Wave FoundY=root:Settings:SearchGrid:FoundY

	strswitch(SelectedDisplay)
		case "SearchGrids":

			if (cmpstr(graphname,"SearchGridDisplay")==0)
				DoWindow $graphName
			endif
			
			If(!V_flag)
				
				//graphName = "SearchGridDisplay"
				if (cmpstr(graphname,"SearchGridDisplay")==0)
					Display/K=1/N=$miscInfo[%searchGraphName] FineGridY vs FineGridX 
					ModifyGraph rgb(FineGridY) = (0,65535,0)
				endif
	
				//If traces already exist, don't add new ones
				String traces= TraceNameList(graphName,";",1)
				if (strsearch(traces,"CoarseGridY",0,2) == -1)
		
					AppendToGraph CoarseGridY vs CoarseGridX
					AppendToGraph PreviousY vs PreviousX
					AppendToGraph CurrentY vs CurrentX
					AppendToGraph FoundY vs FoundX
				endif
				
				ModifyGraph rgb(PreviousY) = (0,0,65535)
				ModifyGraph rgb(CurrentY) = (0,0,0)
				ModifyGraph rgb(FoundY) = (65535,0,0)
				
				ModifyGraph mode(CoarseGridY)= 3
				ModifyGraph mode(PreviousY)= 3
				ModifyGraph mode(CurrentY)= 3
				ModifyGraph mode(FoundY)= 3
				
				ModifyGraph marker(CurrentY) = 8 
				ModifyGraph msize(CurrentY) = 4
				ModifyGraph mrkThick(CurrentY) = 1
				ModifyGraph marker(FoundY) = 19 
				ModifyGraph msize(FoundY) = 1.5
				
				if (cmpstr(graphname,"SearchGridDisplay")!=0)
					Variable xDelta = str2num(miscInfo[%marqueeLeft]) - CoarseGridX[0]
					Variable yDelta = str2num(miscInfo[%marqueeBottom]) - CoarseGridY[0]
					
					ModifyGraph offset(CoarseGridY)={xDelta,yDelta}
					ModifyGraph offset(PreviousY)={xDelta,yDelta}
					ModifyGraph offset(CurrentY)={xDelta,yDelta}
					ModifyGraph offset(FoundY)={xDelta,yDelta}
				endif
				
				if (cmpstr(graphname,"SearchGridDisplay")==0)
					Label Left "Y Position (m)"
					Label bottom "X Position (m)"
				endif
				
				SetWindow $miscInfo[%searchGraphName] hook(SearchGridHook)=SearchGridHookFunction
			EndIf		
		
		break
	Endswitch
End

//Returns the closest coarse spot to the given position
Function closestPoint(xPos, yPos)

	Variable xPos, yPos
//	print xPos
//	print yPos
	
	wave searchSettings = root:Settings:SearchGrid:SearchSettings
	variable coarseNumX = SearchSettings[%coarseNumx]
	variable coarseNumY =SearchSettings[%coarseNumy]
	
	wave xWave = root:Settings:SearchGrid:CoarseGridX
	wave yWave = root:Settings:SearchGrid:CoarseGridy
	//Loop to find the x
	variable i
	variable xGuess = 0

	Variable maxIter = coarseNumX
	for(i=0;i<maxIter;i+=1)
		if (xWave[i] >= xPos)
			xGuess = i
			if (i > 0 && ((xPos-xWave[i-1]) < (xWave[i] - xPos)))
				xGuess = i-1
			endif
			break
		endif
	EndFor
	//At this point, xGuess gives us the correct "column"
	//Loop to find the y
	variable coarsePos = 0
	maxIter = coarseNumY*coarseNumX
	for(i=xGuess;i<maxIter;i+=coarseNumX)
		if (yWave[i] >= yPos)
			coarsePos = i
			if (i > coarseNumX && ((yPos-yWave[i-coarseNumX]) < (yWave[i] - yPos)))
				coarsePos = i-coarseNumX
			endif
			break
		endif
	EndFor
	
	return coarsePos
	
End

Function SearchForMolecule([FoundMolecule,Callback,FoundX_V,FoundY_V])
	Variable FoundMolecule
	String Callback
	Variable FoundX_V,FoundY_V
	cryptidDebug()
	cryptidTimer(20)
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
	Wave FoundX=root:Settings:SearchGrid:FoundX
	Wave FoundY=root:Settings:SearchGrid:FoundY
      	WAve FoundCoarseNumber=root:Settings:SearchGrid:FoundCoarseNumber
	
	If(ParamIsDefault(FoundMolecule))
		FoundMolecule=0
	EndIf
	If(ParamIsDefault(Callback))
		Callback=""
	EndIf
	
	//If the zSensor rails, the current position doesn't seem correct for lvdtX and y, so reset here
	String DataFolder = GetDF("Meter")
	Wave UpdateMeterUpdate = $DataFolder+"UpdateMeterUpdate"
	Variable Height_V =UpdateMeterUpdate[%Height]
	
	//MOVING
	If (Height_V<0) // Zsensor railed,
		moveToCoarseSpot(searchSettings[%coarseSpotNumber],fineSpot=searchSettings[%fineSpotNumber])
		//print "Moving Railed"
	EndIf
	
	If(ParamIsDefault(FoundX_V))
		FoundX_V=td_rv("Cypher.LVDT.X")
	EndIf
	If(ParamIsDefault(FoundY_V))
		FoundY_V=td_rv("Cypher.LVDT.Y")
	EndIf
	
	SearchMode[%Callback]=Callback
	
	// Update current location
	Wave CurrentX = root:Settings:SearchGrid:CurrentX
	Wave CurrentY= root:Settings:SearchGrid:CurrentY
  	CurrentX[0]=(td_rv("Cypher.LVDT.X")-GV("XLVDTOffset"))*GV("XLVDTSens")
   	CurrentY[0]=(td_rv("Cypher.LVDT.Y")-GV("YLVDTOffset"))*GV("YLVDTSens")

	If(FoundMolecule)
		SearchMode[%CurrentMode]="StayAtThisSpot"
		SearchSettings[%LastGoodIteration]=SearchSettings[%MasterIteration]
		Variable NumFound=DimSize(FoundX,0)
		Variable NewWaveSize=NumFound+1
		Redimension/N=(NewWaveSize) FoundX,FoundY,FoundCoarseNumber
	      FoundX[NumFound]=(FoundX_V-GV("XLVDTOffset"))*GV("XLVDTSens")
	      FoundY[NumFound]=(FoundY_V-GV("YLVDTOffset"))*GV("YLVDTSens")
	      FoundCoarseNumber[NumFound]=SearchSettings[%CoarseSpotNumber]
	EndIf
	
	String CurrentSearchMode=SearchMode[%CurrentMode]
	If(SearchSettings[%HotSpotManualOverride])
		CurrentSearchMode="HotSpotManualOverride"
	EndIf
	StrSwitch(CurrentSearchMode)
		case "Coarse":
			// If we didn't find anything at this spot, move to the next coarse spot
			If(SearchSettings[%IterationsAtCurrentSpot]>=SearchSettings[%CoarseIterationsPerSpot])
				NextPosition("Coarse")
				//print "Moving Next Coars Spot"
			Else
				//Added by BD to prevent issues with xy drift after each cycle
				Wave CoarseGridX=root:Settings:SearchGrid:CoarseGridX
				Wave CoarseGridY=root:Settings:SearchGrid:CoarseGridY
				GoToLocation(CoarseGridX[SearchSettings[%CoarseSpotNumber]],CoarseGridY[SearchSettings[%CoarseSpotNumber]], callback="")
				//print "Moving to Current Spot"
				////////////////////
				FinishIteration()
			EndIf
		break
		case "Fine":
			// If we didn't find anything at this fine spot, move to the next fine spot
			If(SearchSettings[%IterationsAtCurrentSpot]>=SearchSettings[%FineIterationsPerSpot])
				NextPosition("Fine")
				//print "Moving to Fine Spot"
			Else
				//Added by BD to prevent issues with xy drift after each cycle
				Wave FineGridX=root:Settings:SearchGrid:FineGridX
				Wave FineGridY=root:Settings:SearchGrid:FineGridY
				GoToLocation(FineGridX[SearchSettings[%FineSpotNumber]],FineGridY[SearchSettings[%FineSpotNumber]], callback="")
				//print "Moving to Current Spot Fine"
				////////////////////
				FinishIteration()
			EndIf
		break
		case "LastFound":
			If(SearchSettings[%IterationsAtCurrentSpot]>=SearchSettings[%NumIterationPerLastFound])
				NextPosition("LastFound")
				//print "Moving to Last Found"
			Else
				FinishIteration()
			EndIf

		break
		case "StayAtThisSpot":
			Variable IterationsSinceHit=SearchSettings[%MasterIteration]-SearchSettings[%LastGoodIteration]
			// If this hotspot is cold then go to another spot.  Use a fine search, if the user wants that.
			//BD Edit to allow iterationsAtHotSpot to be 0 to for assays which a molecule can't be picked up again (DNA, bR, Tubulin, ect..)
			If((IterationsSinceHit>SearchSettings[%IterationsAtHotSpot]) || ( (SearchSettings[%IterationsAtHotSpot] == 0) && (SearchSettings[%IterationsAtCurrentSpot]>=SearchSettings[%CoarseIterationsPerSpot]) )) //Modified BD 20250327
				If(SearchSettings[%UseFineSearch])
					Wave CurrentX = root:Settings:SearchGrid:CurrentX
				      Wave CurrentY= root:Settings:SearchGrid:CurrentY
			          	MakeFineGrid(CurrentX[0],CurrentY[0])
					SearchSettings[%FineSpotNumber]=-1
					SearchSettings[%FineLevel]+=1
					NextPosition("Fine")
					//print "Moving fine for no repeats"
					
				ElseIf(SearchSettings[%UseLastFoundSearch])
					MakeLastFoundGrid()
					SearchSettings[%CurrentLastFoundIndex]=-1
					SearchSettings[%LastFoundIteration]+=1
					NextPosition("LastFound")
					//print "Moving Last Found for no repeats"
					
				Else
					NextPosition("Coarse")
					//print "Moving Coarse for no repeats"
				EndIf
			Else
				//Added by BD to prevent issues with xy drift after each cycles
				if(SearchSettings[%FineSpotNumber] == -1)
					Wave CoarseGridX=root:Settings:SearchGrid:CoarseGridX
					Wave CoarseGridY=root:Settings:SearchGrid:CoarseGridY
					GoToLocation(CoarseGridX[SearchSettings[%CoarseSpotNumber]],CoarseGridY[SearchSettings[%CoarseSpotNumber]], callback="")
					//print "Staying at this spot coarse"
				////////////////////
				else
					Wave FineGridX=root:Settings:SearchGrid:FineGridX
					Wave FineGridY=root:Settings:SearchGrid:FineGridY
					GoToLocation(FineGridX[SearchSettings[%FineSpotNumber]],FineGridY[SearchSettings[%FineSpotNumber]], callback="")
					//print "Staying at this spot Fine"
				endif
				
				FinishIteration()
			EndIf
		break
		case "HotSpotManualOverride":
			//Added by BD to prevent issues with xy drift after each cycle
			if(SearchSettings[%FineSpotNumber] == -1)
				Wave CoarseGridX=root:Settings:SearchGrid:CoarseGridX
				Wave CoarseGridY=root:Settings:SearchGrid:CoarseGridY
				GoToLocation(CoarseGridX[SearchSettings[%CoarseSpotNumber]],CoarseGridY[SearchSettings[%CoarseSpotNumber]], callback="")
				//print "Staying at this spot manual"
			////////////////////
			else
				Wave FineGridX=root:Settings:SearchGrid:FineGridX
				Wave FineGridY=root:Settings:SearchGrid:FineGridY
				GoToLocation(FineGridX[SearchSettings[%FineSpotNumber]],FineGridY[SearchSettings[%FineSpotNumber]], callback="")
				//print "Staying at this spot manual Fine"
			endif
			
			FinishIteration()
		break
	EndSwitch
	
	// Setup for next iteration
End

Function FinishIteration()
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
	SearchSettings[%IterationsAtCurrentSpot]+=1
	SearchSettings[%MasterIteration]+=1
	cryptidDebug()
	
	//I don't want to permenantly save the callback, so reset it here
	string callback = searchMode[%callback]
	searchMode[%callback]=""
	
	Execute callback
End

Function NextPosition(NewSearchMode)
	String NewSearchMode
	cryptidDebug()
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
	
	SearchSettings[%IterationsAtCurrentSpot]=0
	SearchSettings[%SpotNumber]+=1
	SearchMode[%CurrentMode]=NewSearchMode
	
	strswitch(NewSearchMode)
		case "Coarse":
			Wave CoarseGridX=root:Settings:SearchGrid:CoarseGridX
			Wave CoarseGridY=root:Settings:SearchGrid:CoarseGridY
			
			// Move to next coarse spot
			SearchSettings[%CoarseSpotNumber]+=1
			// If we've exceeded the number of coarse spots in the grid, go back to coarse spot 0
			Variable TotalCoarseSpots=SearchSettings[%CoarseNumX]*SearchSettings[%CoarseNumY]
			
			//BDEdit to account for line code
			if (searchSettings[%useSpotLine] == 1)
				TotalCoarseSpots = SearchSettings[%CoarseNumX]
			endif
			
			If(SearchSettings[%CoarseSpotNumber]>=TotalCoarseSpots)
				SearchSettings[%CoarseSpotNumber]=0
			EndIf
			// Reset all the fine search settings to -1
			SearchSettings[%FineSpotNumber]=-1
			SearchSettings[%FineLevel]=-1
			Variable CoarseSpotNumber=SearchSettings[%CoarseSpotNumber]
			MakeFineGrid(CoarseGridX[CoarseSpotNumber],CoarseGridY[CoarseSpotNumber])
			GoToLocation(CoarseGridX[CoarseSpotNumber],CoarseGridY[CoarseSpotNumber])
		break
		case "Fine":
			Wave FineGridX=root:Settings:SearchGrid:FineGridX
			Wave FineGridY=root:Settings:SearchGrid:FineGridY

			SearchSettings[%FineSpotNumber]+=1
			Variable FineSpotNumber=SearchSettings[%FineSpotNumber]
			Variable TotalFineSpots=SearchSettings[%FineNumX]*SearchSettings[%FineNumY]
			// If we've exceeded the number of fine spots in the grid, go to the next coarse spot
			If(SearchSettings[%FineSpotNumber]>=TotalFineSpots)
				NextPosition("Coarse")
			Else 
			// If not, go to the next fine spot
				GoToLocation(FineGridX[FineSpotNumber],FineGridY[FineSpotNumber])
			EndIf

		break
		case "LastFound":
			Wave LastFoundX=root:Settings:SearchGrid:LastFoundX
			Wave LastFoundY=root:Settings:SearchGrid:LastFoundY
			SearchSettings[%CurrentLastFoundIndex]+=1
			Variable LastFoundSpotNumber=SearchSettings[%CurrentLastFoundIndex]
			Variable TotalLastFoundSpots=DimSize(LastFoundX,0)
//			// If we've exceeded the number of fine spots in the grid, go to the next coarse spot
			If(LastFoundSpotNumber>=TotalLastFoundSpots)
				NextPosition("Coarse")
			Else 
//			// If not, go to the next fine spot
				GoToLocation(LastFoundX[LastFoundSpotNumber],LastFoundY[LastFoundSpotNumber])
			EndIf

		break
		
	Endswitch
	
End

Function MakeCoarseGrid()
	cryptidDebug()
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
    	MakeGrid(SearchSettings[%CoarseNumX],SearchSettings[%CoarseNumY],SearchSettings[%CoarseDistX],SearchSettings[%CoarseDistY],XPosWaveName="root:Settings:SearchGrid:CoarseGridX",YPosWaveName="root:Settings:SearchGrid:CoarseGridY")
End

Function MakeFineGrid(CoarseX,CoarseY,[XPosWaveName,YPosWaveName])
	Variable CoarseX,CoarseY
	String XPosWaveName,YPosWaveName
	If(ParamIsDefault(XPosWaveName))
		XPosWaveName="root:Settings:SearchGrid:FineGridX"
	EndIf
	If(ParamIsDefault(YPosWaveName))
		YPosWaveName="root:Settings:SearchGrid:FineGridY"
	EndIf
	cryptidDebug()
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	
	Variable FineGridDistanceX=(SearchSettings[%FineNumX]-1)*SearchSettings[%FineDistX]
	Variable FineGridDistanceY=(SearchSettings[%FineNumY]-1)*SearchSettings[%FineDistY]

	Variable FineXOffset=-FineGridDistanceX/2 +CoarseX
	Variable FineYOffset=-FineGridDistanceY/2+CoarseY
	
	MakeGrid(SearchSettings[%FineNumX],SearchSettings[%FineNumY],SearchSettings[%FineDistX],SearchSettings[%FineDistY],XPosWaveName=XPosWaveName,YPosWaveName=YPosWaveName,XOffset=FineXOffset,YOffset=FineYOffset)

End

Function MakeLastFoundGrid()
	Variable AnyLastFoundToVisit=0
	cryptidDebug()
      	Wave FoundX=root:Settings:SearchGrid:FoundX
      	Wave FoundY=root:Settings:SearchGrid:FoundY
      	Wave FoundCoarseNumber=root:Settings:SearchGrid:FoundCoarseNumber
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
      		
	Variable TargetSpotNumber=SearchSettings[%CoarseSpotNumber]
	Variable NumFound=DimSize(FoundCoarseNumber,0)
	Variable MaxFoundIndex=NumFound-1
	Variable MaxFoundToVisit=SearchSettings[%NumLastFoundToVisit]
	Variable NumFoundToVisit=0
	Variable FoundCounter=0
	For(FoundCounter=0;(NumFound-FoundCounter>0)&&(FoundCounter<MaxFoundToVisit);FoundCounter+=1)
		Variable TargetIndex=MaxFoundIndex-FoundCounter
		If(TargetSpotNumber==FoundCoarseNumber[TargetIndex])
			NumFoundToVisit+=1
		EndIf
	EndFor
	
	If(NumFoundToVisit>0)
		Duplicate/O/R=[NumFound-NumFoundToVisit,MaxFoundIndex] FoundX, root:Settings:SearchGrid:LastFoundX
		Duplicate/O/R=[NumFound-NumFoundToVisit,MaxFoundIndex] FoundY, root:Settings:SearchGrid:LastFoundY
		// Eliminates nans at the beginning of FoundX and FoundY
		WaveTransform/O zapNaNs root:Settings:SearchGrid:LastFoundX
		WaveTransform/O zapNaNs root:Settings:SearchGrid:LastFoundY
		// Reverse order so we visit most recent found molecule sites first.
		Reverse root:Settings:SearchGrid:LastFoundX,root:Settings:SearchGrid:LastFoundY
		AnyLastFoundToVisit=1
	EndIf
	Return AnyLastFoundToVisit
End
	
Function MakeGrid(NumX,NumY,XStepSize,YStepSize, [XPosWaveName,YPosWaveName,XOffset,YOffset])
	Variable NumX,NumY,XStepSize,YStepSize,XOffset,YOffset
	String XPosWaveName,YPosWaveName
	cryptidDebug()
	If(ParamIsDefault(XPosWaveName))
		XPosWaveName="XPos"
	EndIf
	If(ParamIsDefault(YPosWaveName))
		YPosWaveName="YPos"
	EndIf
	If(ParamIsDefault(XOffset))
		XOffset=0
	EndIf
	If(ParamIsDefault(YOffset))
		YOffset=0
	EndIf
	
	Variable TotalNum=NumX*NumY
	Make/O/N=(TotalNum) $XPosWaveName
	Make/O/N=(TotalNum) $YPosWaveName

	
	Wave XPos=$XPosWaveName
	Wave YPos=$YPosWaveName
	
	XPos=Mod(p,NumX)*XStepSize+XOffset
	YPos=Mod(Floor(p/NumX),NumY)*YStepSize+YOffset
	
End

//BD EDIT - Make spotLine - Makes a line between the marquee points instead of a grid
Function MakeSpotLine([XPosWaveName,YPosWaveName])
	
	String xPosWaveName, yPosWaveName
	If(ParamIsDefault(XPosWaveName))
		XPosWaveName="XPos"
	EndIf
	If(ParamIsDefault(YPosWaveName))
		YPosWaveName="YPos"
	EndIf
	cryptidDebug()
	Wave/T miscInfo=root:Settings:SearchGrid:MiscInfo
	Wave searchSettings=root:Settings:SearchGrid:searchSettings
	
	//Bail if UseGraphSearch isnt 1
	if (!SearchSettings[%UseGraphSearch])
		doAlert 0, "Graph Search not selected!"
		return 1
	endif

	//////////////////////////////////Code exact from graph setGraphSearch//////////////////////////////////
	//Current variables Wave
	Wave RVW = $GetDF("Variables")+"RealVariablesWave"
	
	//Check x pos so trig works
	
	Variable XposA = xcsr(A)
	Variable yposA = vcsr(A)
	Variable XposB = xcsr(B)
	Variable YposB = vcsr(B)
	Variable temp1
	Variable temp2
	
	//A will always be the "bottom" point
	if (yPosB < yPosA) //if below switch
		temp1 = yPosB
		temp2 = xPosB
		yPosB = yPosA
		xPosB = xPosA
		yPosA = temp1
		xPosA = temp2
	endif
	
	//MightWork?
	miscInfo[%marqueeLeft] = num2str(xPosA)
	miscInfo[%marqueeBottom] = num2str(yPosA)
	
	String graphStr = winName(0,1)
	
	miscInfo[%searchGraphName] = graphStr
	
	Variable SlowSize,FastSize,ScanAngle, xOffset, yOffset
	
	//Determine if live window or one saved already
	if (StringMatch(GraphStr,"Channel*"))		//RT image

		SlowSize = RVW[%SlowScanSize][0]		//grab the current values
		FastSize = RVW[%FastScanSize][0]
		YOffset = RVW[%YOffset][0]
		XOffset = RVW[%XOffset][0]
		ScanAngle = RVW[%ScanAngle][0]*pi/180 //convert to radians

	else		//offline image
		
		String DataFolder,ImageName
		Variable Layer
		
		GetGraphData(GraphStr,DataFolder,ImageName,Layer)
		Wave Image = $DataFolder+ImageName
		String NoteStr = Note(Image)
		SlowSize = NumberByKey("SlowScanSize",NoteStr,":","\r",0)
		FastSize = NumberByKey("FastScanSize",NoteStr,":","\r",0)
		XOffset = NumberByKey("XOffset",NoteStr,":","\r",0)
		YOffset = NumberByKey("YOffset",NoteStr,":","\r",0)
		ScanAngle = NumberByKey("ScanAngle",NoteStr,":","\r",0)*pi/180 //convert to radians
	
	endif

	//Below staken from ScanMaster.ipf
	variable angleScanDirection = 1
	if (GV("ScanMode"))
		angleScanDirection = GV("XScanDirection")*GV("YScanDirection")
	endif
	
	//This takes into account any adjustments for the scan direction
	XOffset += (sin(ScanAngle*angleScanDirection)*(-SlowSize/2))+(cos(ScanAngle*angleScanDirection)*(-FastSize/2))
	YOffset += (cos(ScanAngle*angleScanDirection)*(-SlowSize/2))-(sin(ScanAngle*angleScanDirection)*(-FastSize/2))
	
	Variable bigdx = xPosB - xPosA
	Variable bigdy = yPosB - yPosA
	Variable length = sqrt(bigdx^2 + bigdy^2)
	Variable theta = acos(bigdx / length)
	
	//Use length and distance to populate
	Variable distSpots = searchSettings[%CoarseDistX]
	Variable totalNum = floor(length / distSpots)
	Variable dx = length * cos(theta) / totalNum
	Variable dy = length * sin(theta) / totalNum
	
	Make/O/N=(TotalNum) $XPosWaveName
	Make/O/N=(TotalNum) $YPosWaveName

	Wave XPos=$XPosWaveName
	Wave YPos=$YPosWaveName
	
	XPos=p*dx+XOffset + xPosA
	YPos=p*dy+YOffset + yPosA
	
	SearchSettings[%CoarseNumX] = totalNum
	SearchSettings[%CoarseNumY] = totalNum

End

//Edited by BD to add optional Callback parameter
Function GoToLocation(XPos,YPos, [callback])
	Variable XPos,YPos
	String Callback
	Wave/T SearchMode=root:Settings:SearchGrid:SearchMode
	
	if(paramisdefault(callback))
		callback = "FinishIteration()"
	endif
	cryptidDebug()
	Variable XPos_V=XPos/GV("XLVDTSens")+GV("XLVDTOffset")
	Variable YPos_V=YPos/GV("YLVDTSens")+GV("YLVDTOffset")
	
	//print "Moving to "+num2str(XPos_V)
	
	MakeMoveToPointCLSettingsWave(OutputWaveName="root:Settings:SearchGrid:MoveSettings")
	
	Wave MoveSettings=root:Settings:SearchGrid:MoveSettings
	MoveSettings[%XPosition_V]=XPos_V
	MoveSettings[%YPosition_V]=YPos_V
	
      Wave PreviousX= root:Settings:SearchGrid:PreviousX
      Wave PreviousY= root:Settings:SearchGrid:PreviousY
	Variable NumPreviousLocations=DimSize(PreviousX,0)
//	InsertPoints NumPreviousLocations,1,PreviousX,PreviousY
//	PreviousX[NumPreviousLocations]=XPos
//	PreviousY[NumPreviousLocations]=YPos
	
	Wave CurrentX = root:Settings:SearchGrid:CurrentX
      Wave CurrentY= root:Settings:SearchGrid:CurrentY
      CurrentX[0]=XPos
      CurrentY[0]=YPos

	MoveToPointClosedLoop(MoveSettings,Callback=callback)
	
End

Window Search_Panel() : Panel
	PauseUpdate; Silent 1		// building window...
	NewPanel /K=1 /W=(636,302,914,1013) as "Search_Panel"
	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	DrawLine 50,50,60,60
	DrawLine 19,207,253,207
	DrawLine 19,320,253,320
	SetDrawEnv fstyle= 1
	DrawText 19,225,"Spot Numbers"
	SetDrawEnv fstyle= 1
	DrawText 19,338,"Iteration Info"
	DrawLine 19,434,253,434
	SetDrawEnv fstyle= 1
	DrawText 19,455,"Operation Status"
	SetDrawEnv fstyle= 1
	DrawText 19,500,"Move To Spot"
	DrawLine 19,482,253,482
	SetVariable CoarseNumX,pos={24,46},size={207,16},proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable CoarseNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumX]
	SetVariable CoarseNumY,pos={24,88},size={210,16},proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable CoarseNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseNumY]
	SetVariable CoarseDistX,pos={24,67},size={210,16},proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable CoarseDistX,format="%.1W1Pm"
	SetVariable CoarseDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistX]
	SetVariable CoarseDistY,pos={24,111},size={209,16},proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable CoarseDistY,format="%.1W1Pm"
	SetVariable CoarseDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%CoarseDistY]
	SetVariable FineNumX,pos={28,43},size={207,16},disable=1,proc=SearchSetVarProc,title="Number of X Spots"
	SetVariable FineNumX,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumX]
	SetVariable FineDistX,pos={28,64},size={210,16},disable=1,proc=SearchSetVarProc,title="Distance Between X Spots"
	SetVariable FineDistX,format="%.1W1Pm"
	SetVariable FineDistX,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistX]
	SetVariable FineNumY,pos={28,85},size={210,16},disable=1,proc=SearchSetVarProc,title="Number of Y Spots"
	SetVariable FineNumY,limits={2,inf,1},value= root:Settings:SearchGrid:SearchSettings[%FineNumY]
	SetVariable FineDistY,pos={28,108},size={209,16},disable=1,proc=SearchSetVarProc,title="Distance Between Y Spots"
	SetVariable FineDistY,format="%.1W1Pm"
	SetVariable FineDistY,limits={1e-09,2e-05,1e-08},value= root:Settings:SearchGrid:SearchSettings[%FineDistY]
	SetVariable CoarseIterationsPerSpot,pos={24,135},size={209,16},proc=SearchSetVarProc,title="Iterations Per Spot"
	SetVariable CoarseIterationsPerSpot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseIterationsPerSpot]
	SetVariable FineIterationsPerspot,pos={28,134},size={209,16},disable=1,title="Iterations Per Spot"
	SetVariable FineIterationsPerspot,limits={1,1000,1},value= root:Settings:SearchGrid:SearchSettings[%FineIterationsPerSpot]
	TabControl tab0,pos={19,14},size={235,157},proc=SearchTabProc
	TabControl tab0,labelBack=(47872,47872,47872),tabLabel(0)="Coarse Grid Settings"
	TabControl tab0,tabLabel(1)="Fine Grid Settings",value= 0
	CheckBox UseFineSearch,pos={19,192},size={97,14},proc=SearchCheckProc,title="Use Fine Search"
	CheckBox UseFineSearch,value= 1
	SetVariable SpotNumber,pos={19,226},size={209,16},title="SpotNumber"
	SetVariable SpotNumber,limits={1,1e+06,1},value= root:Settings:SearchGrid:SearchSettings[%SpotNumber]
	SetVariable CoarseSpotNumber,pos={19,246},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%CoarseSpotNumber]
	SetVariable FineSpotNumber,pos={19,267},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineSpotNumber]
	SetVariable FineLevel,pos={19,288},size={209,16},title="Fine Level"
	SetVariable FineLevel,limits={-1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%FineLevel]
	SetVariable MasterIteration,pos={19,341},size={209,16},title="Master Iteration"
	SetVariable MasterIteration,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%MasterIteration],noedit= 1
	SetVariable IterationsCurrentSpot,pos={19,363},size={209,16},title="Iterations at Current Spot"
	SetVariable IterationsCurrentSpot,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtCurrentSpot],noedit= 1
	SetVariable LastGoodIteration,pos={19,386},size={209,16},title="Last Good Iteration"
	SetVariable LastGoodIteration,limits={1,100000,1},value= root:Settings:SearchGrid:SearchSettings[%LastGoodIteration],noedit= 1
	SetVariable CurrentMode,pos={19,458},size={200,16},title="Current Mode"
	SetVariable CurrentMode,value= root:Settings:SearchGrid:SearchMode[%CurrentMode]
	SetVariable CoarseSpotNumber1,pos={19,501},size={209,16},title="Coarse Spot Number"
	SetVariable CoarseSpotNumber1,limits={1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%CoarseSpotNumber]
	SetVariable FineSpotNumber1,pos={19,522},size={209,16},title="Fine Spot Number"
	SetVariable FineSpotNumber1,help={"Put -1 to not use a fine position"}
	SetVariable FineSpotNumber1,limits={-1,100000,1},value= root:Settings:SearchGrid:MoveToSpot[%FineSpotNumber]
	Button MoveToSpot,pos={19,545},size={79,27},proc=SearchButtonProc,title="Move To Spot"
	CheckBox HotSpotManualOverride,pos={129,193},size={68,14},proc=SearchCheckProc,title="Stay Here!"
	CheckBox HotSpotManualOverride,help={"This will prevent the algorithm from moving the stage from this spot.  Good if you want to keep hitting this spot."}
	CheckBox HotSpotManualOverride,value= 0
	SetVariable IterationsPerHotSpot,pos={20,407},size={209,16},title="Iterations Per Hot Spot"
	SetVariable IterationsPerHotSpot,limits={0,100000,1},value= root:Settings:SearchGrid:SearchSettings[%IterationsAtHotSpot]
	PopupMenu SearchGridQuckSettingsPM,pos={19,608},size={141,22},proc=SearchGridQSPopMenuProc,title="Quick Settings"
	PopupMenu SearchGridQuckSettingsPM,mode=1,popvalue="Default",value= #"SearchQuickSettingsList()"
	CheckBox UseGraphSearch,pos={19,172},size={106,14},proc=SearchCHeckProc,title="Use Graph Search"
	CheckBox UseGraphSearch,value= 0
	CheckBox UseSpotLine,pos={220,172},size={38,14},proc=SearchCHeckProc,title="Line"
	CheckBox UseSpotLine,value= 0
	Button GetGraphPos,pos={129,172},size={80,18},proc=SearchButtonProc,title="Get Graph Pos"
	Button NextSpot,pos={101,545},size={79,27},proc=SearchButtonProc,title="Next Spot"
	ToolsGrid snap=1,visible=1
EndMacro

Function SearchTabProc(tca) : TabControl
	STRUCT WMTabControlAction &tca
	cryptidDebug()
	string panelName = tca.win

	switch( tca.eventCode )
		case 2: // mouse up
			Variable tab = tca.tab
			
			SetVariable CoarseNumX win=$panelName,disable= (tab!=0)
			SetVariable CoarseNumY win=$panelName,disable= (tab!=0)
			SetVariable CoarseDistX win=$panelName,disable= (tab!=0)
			SetVariable CoarseDistY win=$panelName,disable= (tab!=0)
			SetVariable CoarseIterationsPerSpot win=$panelName,disable= (tab!=0)
			
			SetVariable FineNumX win=$panelName,disable= (tab!=1)
			SetVariable FineNumY win=$panelName,disable= (tab!=1)
			SetVariable FineDistX win=$panelName,disable= (tab!=1)
			SetVariable FineDistY win=$panelName,disable= (tab!=1)
			SetVariable FineIterationsPerspot win=$panelName,disable= (tab!=1)

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function SearchCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba
	String CheckBoxName=cba.CtrlName
	cryptidDebug(diagString=CheckBoxName)
	switch( cba.eventCode )
		case 2: // mouse up
			Variable checked = cba.checked
			Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
			
			//BDEDIT
			Wave/T MiscInfo=root:Settings:SearchGrid:SearchSettings
			
			strswitch(CheckBoxName)
				case "UseFineSearch":
					SearchSettings[%UseFineSearch]=checked
				break
				case "HotSpotManualOverride":
					SearchSettings[%HotSpotManualOverride]=checked
				break
				
				//BDEDIT
				case "UseGraphSearch":
					SearchSettings[%UseGraphSearch] = checked
				break
				
				//BDEDIT
				case "UseSpotLine":
					searchSettings[%UseSpotLine] = checked
				break
				
			Endswitch
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function SearchButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba
	String ButtonName=ba.CtrlName
	
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			strswitch(ButtonName)
			
				case "MoveToSpot":
					Wave MoveToSpot=root:Settings:SearchGrid:MoveToSpot
					
					SearchSettings[%CoarseSpotNumber]=MoveToSpot[%CoarseSpotNumber]-1
					SearchSettings[%FineSpotNumber]=MoveToSpot[%FineSpotNumber]-1

					If(MoveToSpot[%FineSpotNumber]==-1)
						SearchSettings[%FineSpotNumber]=-1
						NextPosition("Coarse")
					Else
						NextPosition("Fine")
					EndIf
				break // MoveToSpot
				case "NextSpotMain":
				case "NextSpot":					
					NextPosition("Coarse")
					break
				case "NextIteration":
					SearchForMolecule()
					break			
				case "viewSearchGrid":
					//BDEDIT
					Wave/T miscInfo=root:Settings:SearchGrid:miscInfo
		
					if(SearchSettings[%UseGraphSearch])
						ShowSearchInfo("SearchGrids",graphName=miscInfo[%searchGraphName])
					else	
						ShowSearchInfo("SearchGrids")
					endif
					
					doWindow/F searchGridDisplay
				break
				
				case "forceFineGrid":
					Wave CurrentX = root:Settings:SearchGrid:CurrentX
				      Wave CurrentY= root:Settings:SearchGrid:CurrentY
			          	MakeFineGrid(CurrentX[0],CurrentY[0])
					SearchSettings[%FineSpotNumber]=-1
					SearchSettings[%FineLevel]+=1
					NextPosition("Fine")
					//print "Moving fine for no repeats"
					break
				
				case "GetGraphPos":
					//Remove previous stuff
					redimension/N=0 root:Settings:SearchGrid:previousX 
					redimension/N=0 root:Settings:SearchGrid:previousY 
					redimension/N=0 root:Settings:SearchGrid:FoundX 
					redimension/N=0 root:Settings:SearchGrid:FoundY
					if(searchSettings[%UseSpotLine])
						MakeSpotLine(XPosWaveName="root:Settings:SearchGrid:CoarseGridX",YPosWaveName="root:Settings:SearchGrid:CoarseGridY")
					else
						SetGraphSearch()
					endif
					
					//Also use show to update
					//BDEDIT
					Wave/T miscInfo=root:Settings:SearchGrid:miscInfo
		
					if(SearchSettings[%UseGraphSearch])
						ShowSearchInfo("SearchGrids",graphName=miscInfo[%searchGraphName])
					else	
						ShowSearchInfo("SearchGrids")
					endif
				break	
				
					
			Endswitch
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function SearchSetVarProc(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva

	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
				cryptidDebug(diagString=sva.ctrlName)
				Variable dval = sva.dval
				String sval = sva.sval
				MakeCoarseGrid()    	
				Wave CurrentX = root:Settings:SearchGrid:CurrentX
 				Wave CurrentY= root:Settings:SearchGrid:CurrentY
				MakeFineGrid(CurrentX[0],CurrentY[0])
			break
		case 3: // Live update

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function SearchGridQSPopMenuProc(pa) : PopupMenuControl
	STRUCT WMPopupAction &pa
	Wave SearchQuickSettings=root:Settings:SearchGrid:SearchQuickSettings
	SetDataFolder root:Settings:SearchGrid
	cryptidDebug(diagString=pa.ctrlName)
	switch( pa.eventCode )
		case 2: // mouse up
			Variable popNum = pa.popNum
			String popStr = pa.popStr
			
			Duplicate/O/R=[0,*][popNum-1] SearchQuickSettings,SearchSettings
			Redimension/N=-1 SearchSettings
			// Build new grid when you select a quick setting.
			MakeCoarseGrid()    	
			Wave CurrentX = root:Settings:SearchGrid:CurrentX
 			Wave CurrentY= root:Settings:SearchGrid:CurrentY
			MakeFineGrid(CurrentX[0],CurrentY[0])

			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


//BDEDIT
//This is code to make the searchGrid using the current scan or a saved scan. 
Function SetGraphSearch()
		
	cryptidDebug()
	Wave/T miscInfo=root:Settings:SearchGrid:MiscInfo
	Wave searchSettings=root:Settings:SearchGrid:searchSettings
	if (!SearchSettings[%UseGraphSearch])
		doAlert 0, "Graph Search not selected!"
		return 1
	endif
	
	//Current variables Wave
	Wave RVW = $GetDF("Variables")+"RealVariablesWave"
	
	//Get the coordinates of the Marquee
	getMarquee Left,Bottom
	
	miscInfo[%marqueeLeft] = num2str(V_left)
	miscInfo[%marqueeBottom] = num2str(V_bottom)
	
	String graphStr = winName(0,1)
	
	miscInfo[%searchGraphName] = graphStr
	
	Variable SlowSize,FastSize,YOffset,XOffset,ScanAngle
	
	//Determine if live window or one saved already
	if (StringMatch(GraphStr,"Channel*"))		//RT image

		SlowSize = RVW[%SlowScanSize][0]		//grab the current values
		FastSize = RVW[%FastScanSize][0]
		YOffset = RVW[%YOffset][0]
		XOffset = RVW[%XOffset][0]
		ScanAngle = RVW[%ScanAngle][0]*pi/180 //convert to radians
			
//		print slowSize
//		print fastSize
//		print scanangle
	else		//offline image
		
		String DataFolder,ImageName
		Variable Layer
		
		GetGraphData(GraphStr,DataFolder,ImageName,Layer)
		Wave Image = $DataFolder+ImageName
		String NoteStr = Note(Image)
		SlowSize = NumberByKey("SlowScanSize",NoteStr,":","\r",0)
		FastSize = NumberByKey("FastScanSize",NoteStr,":","\r",0)
		XOffset = NumberByKey("XOffset",NoteStr,":","\r",0)
		YOffset = NumberByKey("YOffset",NoteStr,":","\r",0)
		ScanAngle = NumberByKey("ScanAngle",NoteStr,":","\r",0)*pi/180 //convert to radians

	endif

	//Below staken from ScanMaster.ipf
	variable angleScanDirection = 1
	if (GV("ScanMode"))
		angleScanDirection = GV("XScanDirection")*GV("YScanDirection")

	endif

	//This takes into account any adjustments for the scan direction
	XOffset += (sin(ScanAngle*angleScanDirection)*((V_top+V_bottom)/2-SlowSize/2))+(cos(ScanAngle*angleScanDirection)*((V_left+V_right)/2-FastSize/2))
	YOffset += (cos(ScanAngle*angleScanDirection)*((V_top+V_bottom)/2-SlowSize/2))-(sin(ScanAngle*angleScanDirection)*((V_left+V_right)/2-FastSize/2))
	
//	xOffset += -fastSize/2
//	yOffset += -slowSize/2

	//This takes into account that Robs grid starts from the center and goes up and right rather then using it as the center
	XOffset += -abs(V_right - V_left)/2
	YOffset += -abs(V_top - V_bottom)/2

//	print xoffset
//	print yoffset
	

	//Get desired dist between spots
	Wave SearchSettings = root:Settings:SearchGrid:SearchSettings
	Variable disX = SearchSettings[%CoarseDistX]
	Variable disY = SearchSettings[%CoarseDistY]
	
	Variable numX = abs(floor((V_right-V_left)/(disX))) +1
	Variable numY = abs(floor((V_Top-V_bottom)/(disX))) +1
	
	SearchSettings[%CoarseNumX] = numX
	SearchSettings[%CoarseNumY] = numY
	SearchSettings[%CoarseDistX] = disX
	SearchSettings[%CoarseDistY]= disx
	
	MakeGrid(SearchSettings[%CoarseNumX],SearchSettings[%CoarseNumY],SearchSettings[%CoarseDistX],SearchSettings[%CoarseDistY],XPosWaveName="root:Settings:SearchGrid:CoarseGridX",YPosWaveName="root:Settings:SearchGrid:CoarseGridY", xOffset=xOffset,yOffset=yOffset )
	
End

Function SGmoveToSpot(spotNum,[fineSpotNum])

	Variable spotNum, fineSpotNum
	Wave MoveToSpot=root:Settings:SearchGrid:MoveToSpot
	Wave SearchSettings=root:Settings:SearchGrid:SearchSettings
	
	if(paramIsDefault(fineSpotNum))
		fineSpotNum=searchSettings[%fineSpotNumber]
	endif
	
	SearchSettings[%CoarseSpotNumber]=spotNum-1
	SearchSettings[%FineSpotNumber]=fineSpotNum-1

	If(MoveToSpot[%FineSpotNumber]==-1)
		SearchSettings[%FineSpotNumber]=-1
		NextPosition("Coarse")
	Else
		NextPosition("Fine")
	EndIf

End

