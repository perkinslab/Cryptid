#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//Package to easily do z-Dwells


Function cryptidExecuteDwell()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	DoDwell(vSettings,tSettings)
	

End



Function DoDwell(vSettings,tSettings,[callback])
	
	Wave vSettings
	Wave/T tSettings
	string callback
	
	if(paramIsDefault(callback))
		callback = ""
	endif
	
	tSettings[%callback]=callback
	
	Variable Error=0
	
	//We need to set up an event. Best to put this in your settings and set a default value
	String EventString=tSettings[%eventEnable]
	
	//Clear the event we are going to use
	Error += td_WS(EventString,"Clear")
	
	cryptidDebug(diagString="Asylum Error in td_WS: "+num2str(Error))
	
	//Here we set up and load/change any ARC/Cypher parameters. Feedback loops, CTFCs, ect...
	SetupDwellParameters(vSettings,tSettings)
	
	//Here we set up our inWaves. Make the waves, set up the td_xSetInWave stuff ect....
	SetupDwellData(vSettings,tSettings)
	
	//Here we execute
	ExecuteDwell(vSettings, tSettings)
End


Function SetupDwellParameters(vSettings,tSettings)

	wave vSettings
	wave/t tSettings
	
	cryptidDebug()

	setupZFeedback(eventEnable=tSettings[%eventEnable],eventStop=tSettings[%eventStop])
	
End //SetupForceRamp


//Going to record data even if we don't want to, just to use the callback
Function SetupDwellData(vSettings,tSettings)

	Wave vSettings
	Wave/t tSettings
	
	cryptidDebug()

	Variable dwellTime = vSettings[%dwellTime]
	Variable captureRate = vSettings[%captureRate]
	
	if(!vSettings[%DwellsaveCollectedData])
		captureRate = 100
	Endif

	Variable numPoints = captureRate*dwellTime

	
	String zSensorWaveName = tSettings[%zSensorWaveName]
	String deflectionWaveName = tSettings[%deflectionWaveName]
	
	make/O/N=(numPoints) $zSensorWaveName
	make/O/N=(numPoints) $deflectionWaveName
	
	wave zSensor = $zSensorWaveName
	wave deflection = $deflectionWaveName
	
	//get the Event we set up earlier
	String eventString = tSettings[%eventEnable]
	String deflectionChannel = tSettings[%deflectionChannel]
	
	string fullZWaveName = getWavesDataFolder(vSettings,2)
	string fullDWaveName = getWavesDataFolder(tSettings,2)
	
	//set up the in wave pair. Callback can be here or in the CTFC/SetOutWave/ect...
	String callback = "DwellCallback("+fullZWaveName+","+fullDWaveName+")"
	
	td_XSetInWavePair(0,EventString,deflectionChannel,deflection,"Cypher.LVDT.Z",zSensor,callback,ARGetDeci(captureRate))


End

Function ExecuteDwell(vSettings,tSettings)

	Wave/t tSettings
	wave vSettings
	
	String EventString="Event."+tSEttings[%eventEnable]
	
	updateStatus("Begining "+num2str(vSettings[%dwellTime])+" s Dwell")
	
	//Actually execute the thing
	td_WS(EventString,"Once")	

End


//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from externam files
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeDwellSettings()
	
	String packageName = "Dwell"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

End


//Called from the end of the dataCapture
Function DwellCallback(vSettings,tSettings,[cont])

	Variable cont
	Wave/T tSettings
	Wave vSettings
	
	if(paramIsDefault(cont))
		cont = 1
	endif
	
	td_WS("Event."+tSettings[%eventStop],"Once")	
	td_stopinwavebank(0)
	
	string zSensorWaveName = tSettings[%zSensorWaveName]
	string deflectionWaveName = tSettings[%deflectionWaveName]
	Wave deflVolts = $deflectionWaveName
	Wave zSensorVolts = $zSensorWaveName
	
	//Update graph of Cryptid to show your data (doesn't save)
	updateCryptidGraph(deflvolts=deflVolts,zSensorVolts=zSensorVolts)
	
	string params = "DwellTime;"
	string values = num2str(vSettings[%dwellTime])+";"
	writeToStdOut(params,values)
	
	if(cont == 3)
		return 1
	endif
	
	if(stringMatch(tSettings[%callback],""))
		if(vSettings[%DwellsaveCollectedData])
			cryptidMain(cont, deflVolts=deflVolts,zSensorVolts=zSensorVolts)
		else
			cryptidMain(cont)
		endif
	else
		execute tSettings[%callback]
		return 1
	endif
End



//Put your controls down here (setVariableControl, buttonControl, ect...)


Function DwellCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			wave vSettings
			
			Variable checked = cba.checked
			vSettings[%$cba.ctrlName] = checked
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function DwellButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
			
				case "StartDwellNow":
					cryptidExecuteDwell()
					break
				case "StopDwellNow":
					updateStatus("Dwell ended by button")
					wave tSettings
					wave vSettings
					DwellCallback(vSettings,tSettings,cont=3)
					break
			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function MakeDwellPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="DwellPanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="DwellPanel"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif


	ModifyPanel cbRGB=(47872,47872,47872)
	SetDrawLayer UserBack
	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	SetVariable DwellTime,pos={9,54},size={207,16},title="Dwell Time"
	SetVariable DwellTime,format="%.1W1Ps"
	SetVariable DwellTime,value= vSettings[%dwellTime]
	SetVariable DwellCaptureRate,pos={9,81},size={207,16},title="Capture Rate"
	SetVariable DwellCaptureRate,format="%.1W1PHz"
	SetVariable DwellCaptureRate,limits={-inf,inf,0},value= vSettings[%captureRate]
	SetVariable DwellEventEnable,pos={9,513},size={144,16},title="Event Enable"
	SetVariable DwellEventEnable,format="%.1W1PHz"
	SetVariable DwellEventEnable,limits={-inf,inf,0},value= tSettings[%EventEnable]
	SetVariable DwellEventStop,pos={9,540},size={144,16},title="Event Stop"
	SetVariable DwellEventStop,format="%.1W1PHz"
	SetVariable DwellEventStop,limits={-inf,inf,0},value= tSettings[%EventStop]
	Button StartDwellNow,pos={8,214},size={118,27},proc=DwellButtonProc,title="Start Dwell Now"
	Button StopDwellNow,pos={9,243},size={117,27},proc=DwellButtonProc,title="Stop Dwell Now"
	TitleBox DwellTitle,pos={117,11},size={51,24},title="Dwell",fSize=18,frame=0
	TitleBox DwellTitle,fStyle=1
	TitleBox DwellEventTitle,pos={115,470},size={63,24},title="Events",fSize=18
	TitleBox DwellEventTitle,frame=0,fStyle=1
	SetVariable DwellDeflectionChannel,pos={9,144},size={207,16},title="Deflection Channel"
	SetVariable DwellDeflectionChannel,format="%.1W1PHz"
	SetVariable DwellDeflectionChannel,limits={-inf,inf,0},value= tSettings[%deflectionChannel]
	SetVariable DwellZSensorChannel,pos={9,168},size={207,16},title="ZSensor Channel"
	SetVariable DwellZSensorChannel,format="%.1W1PHz"
	SetVariable DwellZSensorChannel,limits={-inf,inf,0},value= tSettings[%zSensorChannel]
	SetVariable saveData,pos={9,119},size={81,16},title="Save Data"
	SetVariable saveData,limits={0,1,1},value= vSettings[%dwellSaveCollectedData]
	ToolsGrid snap=1,visible=1
	SetWindow kwTopWin,hook(thisPanelHook)=cryptidPanelHook
End

