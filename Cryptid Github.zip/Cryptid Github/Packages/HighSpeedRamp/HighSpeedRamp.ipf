#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma version=2.1

//Package for runing HS ramps, including tools for testing transfer functions to develop
//anti stage-ringing driving signals


Function cryptidExecuteHSRamp()
	
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	
	DoHSRamp(vSettings,tSettings)
	
End



Function DoHSRamp(vSettings,tSettings)
	
	Wave vSettings
	Wave/T tSettings
	
	Variable Error=0
	cryptidDebug()
	
	wave vSettings
	wave/t tSettings
	
	cryptidDebug()

	//Set the crosspoint. This puts it through a 37kHz LPF. I wish it was a lower filter, but this is what we got
	//The intent here is to smooth out the 50 kHz steps that setOutWave takes
	//Here, output.A will be filtered and then drive zMod. 
	//THIS ASSUMES ZMOD HAS THE SAME VOLTAGE SCALING AS Z, which might not be true for some reason (Pippin?)
	td_WS("ARC.Crosspoint.FilterIn","OutA")
	td_WS("ARC.Crosspoint.OutZMod","FilterOut")
	
	//Get the location of the HSWave
	string HSWaveLoc = tSettings[%HSWave]
	wave HSWave = $HSWaveLoc
	
	//Set up the outwave		
	//Transform the wave for output
	variable interpFactor = prepWaveForOutput(HSWave)
	
	//Set up outWave
	td_xSetOutWave(0, "0", "ARC.Output.A", HSWave, interpFactor)
	
	//Set up data recording
	variable totalTime =  dimsize(HSWave,0)*dimDelta(HSWave,0)
	variable eventNum = str2num(tSettings[%eventEnable])
	
	//SC here might just be for the callback 
	setupStandardCapture("Deflection", "ZSensor", 50000, totalTime*1.5, vSettings[%SCBank], eventNum, "HSRampCallback()")

	
	//Stream here for z sensor mostly
	td_StopStream("Cypher.Stream.0")
	make/O/N=0 DeflectionFC, ZSensorFC
	SetupStream(1,totalTime*1.5, DeflectionFC, ZSensorFC,event=tSettings[%eventEnable])
	
	//5Mhz FC needed for defl
	setupFastCapture(totalTime*1.5, 20e6)

	//Execute the ramp
	updateStatus("Executing HS Ramp")
	executeFastCapture()
	td_WS("Event."+tSettings[%eventEnable],"Once")
	
End



//NOTE: For both the vSettings and tSettings, you could instead use loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1) to load from external files
//I would highly recomend this. It works as long as the saved waves are located in /Cryptid/Packages/PackageName/Settings/
//This is also where the wave "Executables" needs to go.
////////////////////////////////////vWaveSetup////////////////////////////////////
Function makeHSRampSettings()
	
	String packageName = "HighSpeedRamp"
	loadCryptidSettings(packageName,"vSettings;tSettings",useCurrentDF=1)

End


//Called at the end of you function. Must call cryptid back from here.
Function HSRampCallback()

	Wave/t tSettings
	Wave vSettings
	cryptidDebug()
	td_StopStream("Cypher.Stream.0")
	td_stopOutWaveBank(vSettings[%outWaveBank])
	td_stopinwavebank(vSettings[%SCBank])
	
	Wave deflectionFC, zSensorFC
	cleanWavesAfterSC(deflectionFC,zSensorFC)
	
	//Update graph of Cryptid to show your data (doesn't save)
	updateCryptidGraph(deflvolts=deflectionFC,zSensorVolts=zSensorFC)

	//Decide if we found a molecule (mostly taken from FR code)
	Variable moleculeAttached=0
	
	//Check criteria
	Variable invols = GV("Invols")
	Variable SC = GV("SpringConstant")
	Variable zeroVolts = deflectionFC[ dimsize(deflectionFC,0)-1]
	variable maxForce = abs( waveMin( deflectionFC)-zeroVolts ) *invols*SC
	
	//Check against threshold first
	if (maxForce > vSettings[%threshold])
		cryptidDebug(diagString = "Threshold met")
		//Check against contour length
		variable minLc = vSettings[%minLc]
		variable maxLc = vSettings[%maxLc]
		
		variable Lc = approximateLc(zSensorFC, deflectionFC)

		if ( (Lc > minLc) && (Lc < maxLc))
			moleculeAttached = 1
			cryptidDebug(diagString = "Lc met")
		endif
			
	endif
	
	//I need to ramp z backwards by out.A and set outA back to 0 I think
	variable currentZ = td_RV("Output.Z")
	variable currentA = td_RV("Output.A")*outModMultiplier()
	variable newZ = currentZ+currentA
	
	td_WV("Output.Z",newZ)
	td_WV("Output.A",0)
	
	if(moleculeAttached)
		UpdateStatus("Molecule found, Pulling FC")
		//Write to the output the notes we want
		writeToStdOut("RetractVelocity",num2str(vSettings[%retractVelocity]))
		
		//make/O/N=0 Force5MHz
		pullFastCapture("HSRampFCCallback()","FCWave")
	else
	
		updateStatus("No Molecule")
		cryptidMain(0)
	endif
	
	
End

Function HSRampFCCallback()

	Wave deflectionFC, zSensorFC
	Wave FCWave
	string saveName = getCurrentStepName()+"_FC_"
	//saveFastCapture(FCWave, saveName ,getCVar("FullIterations"))
	cryptidSaveWaves(FCWave, $"", FC=0,saveName=saveName)
	cryptidMain(1, deflVolts=deflectionFC,zSensorVolts=zSensorFC)
End

////////////////////////////////////PanelFunction////////////////////////////////////
Function MakeHSRampPanel([PanelName,WindowName,hostName,vSettings,tSettings]) : Panel
	

	
	String PanelName,WindowName, hostName
	Wave vSettings
	wave/t tSettings
	
	If(ParamIsDefault(panelName))
		panelName="HSRampPanel"
	EndIf
	If(ParamIsDefault(windowName))
		windowName="HSRampWindow"
	EndIf
	
	if (paramIsDefault(vSettings))
		Wave vSettings
	endif
	if(paramIsDefault(tSettings))
		Wave/T tSettings
	endif
	
	
	//This handles making cryptid host if by defualt. It will pass a hostname
	//to call this panel on it's own, simply call it without passing a hostName (wont work with cryptid)
	//I would reccomend directly copying this
	if (paramIsDefault(hostName))
		NewPanel/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	else
		//Use newPanelDims to get the starting dimensions for cryptid
		NewPanel/K=1/HOST=$hostName/W=(newPanelDims(0),newPanelDims(1),newPanelDims(2),newPanelDims(3))/N=$PanelName as WindowName
	endif
	ModifyPanel cbRGB=(47872,47872,47872)
		
	
	PauseUpdate; Silent 1		// building window...
	
		//Put all of your panel stuffs here

	SetDrawEnv linethick= 2
	DrawLine 9,45,270,45
	SetDrawEnv linethick= 2
	DrawLine 9,503,270,503
	
	TitleBox HSRampTitle,pos={63,11},size={171,24},title="High Speed Ramp",fSize=18
	TitleBox HSRampTitle,frame=0,fStyle=1
	TitleBox HSRampEventTitle,pos={115,470},size={63,24},title="Events",fSize=18
	TitleBox HSRampEventTitle,frame=0,fStyle=1
	
	SetVariable HSRampVariable,pos={9,54},size={144,16},proc=HSRSetVarProc,title="HS Wave"
	SetVariable HSRampVariable,value= tSettings[%HSWave]
	SetVariable HSRampVariable1,pos={9,513},size={144,16},title="Event Enable"
	SetVariable HSRampVariable1,format="%.1W1Ps"
	SetVariable HSRampVariable1,value= tSettings[%EventEnable]
	SetVariable HSRampVariable2,pos={9,540},size={144,16},title="SC Bank"
	SetVariable HSRampVariable2,limits={-inf,inf,0},value= vSettings[%SCBank]
	SetVariable HSRampVariable3,pos={9,567},size={144,16},title="OutWave Bank"
	SetVariable HSRampVariable3,limits={-inf,inf,0},value= vSettings[%OutWaveBank]
	SetVariable HSRampVariable4,pos={9,81},size={225,16},title="Retract Velocity"
	SetVariable HSRampVariable4,format="%.1W1Pm/s"
	SetVariable HSRampVariable4,value= vSettings[%retractVelocity]
	SetVariable Threshold,pos={9,108},size={225,16},title="Threshold"
	SetVariable Threshold,format="%.1W1PN"
	SetVariable Threshold,limits={-inf,inf,5e-12},value= vSettings[%Threshold]
	SetVariable MinimumLc,pos={9,128},size={108,16},title="Min Lc",format="%.1W1Pm"
	SetVariable MinimumLc,limits={-inf,inf,1e-08},value= vSettings[%minLc]
	SetVariable MaximumLc,pos={126,128},size={108,16},title="Max Lc"
	SetVariable MaximumLc,format="%.1W1Pm"
	SetVariable MaximumLc,limits={-inf,inf,1e-08},value= vSettings[%maxLc]

End


//Put your controls down here (setVariableControl, buttonControl, ect...)
Function HSRSetVarProc(sva) : SetVariableControl
	STRUCT WMSetVariableAction &sva

	switch( sva.eventCode )
		case 1: // mouse up
		case 2: // Enter key
			//Check the wave exits
			wave/t tSettings
			wave checkWave = $tSettings[%HSWave]
			
			if (!WaveExists(checkWave))
				setVariable $sva.ctrlName, valueBackColor = (2^15, 0, 0)
			else
				setVariable $sva.ctrlName, valueBackColor =0
			endif
			break
		case 3: // Live update
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End


Function HSRampCheckProc(cba) : CheckBoxControl
	STRUCT WMCheckboxAction &cba

	switch( cba.eventCode )
		case 2: // mouse up
			wave vSettings
			
			Variable checked = cba.checked
			vSettings[%$cba.ctrlName] = checked
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

Function HSRampButtonProc(ba) : ButtonControl
	STRUCT WMButtonAction &ba

	switch( ba.eventCode )
		case 2: // mouse up
			// click code here
			
			strSwitch(ba.ctrlName)
			
				case "StartDwellNow":

			EndSwitch
			
			break
		case -1: // control being killed
			break
	endswitch

	return 0
End

//HS WAVE FUNCTIONS //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Temporary function to run and test high speed movement assuming a cantilever is used to measure stage position
Function/Wave makeHSWave(speed, distance, dwellTime, pauseTime, [startVolts, direction,halfWave,mult])

	variable speed, distance, dwellTime, pauseTime, startVolts, direction,halfWave,mult

	if( paramIsDefault(startVolts) )
		startVolts = 0
	endif
	
	if(paramIsDefault(mult))
		mult = outModMultiplier()
	endif
	
	if ( paramIsDefault(direction))
		direction = 0
	endif
	
	if(paramIsDefault(halfWave))
		halfWave = 0
	endif
	
	//Make triangle wave
	make/O/N=50000 outWave
	outWave[0,25000] = p
	outWave[25000+1,50000-1] = 50000-p

	//Give it the appropriate time scaling and volt range
	variable zPiezoSens = GV("ZPiezoSens")*mult
	variable voltRange = distance / zPiezoSens
	outWave *= (voltRange / 25000)
	setScale d, -1, -1, "V", outWave
	variable triangleTime = (distance*2) / speed
	
	setScale/I x, 0, triangleTime, "s", outWave
	Variable timeStep = dimDelta(outWave,0)
	
	//Insert a pause at the begining, middle, and end
	//Middle
	variable numInsertPoints = floor(pauseTime/timeStep)
	insertPoints 25000+1, numInsertPoints, outWave
	outWave[25001, 25001+numInsertPoints] = outWave[25000]
	
	//Begining
	numInsertPoints = floor(dwellTime/timeStep)
	insertPoints 0, numInsertPoints, outWave
	outWave[0, 0+numInsertPoints] = outWave[1]
	
	//End
	variable endPnt = dimsize(outWave,0)-1
	insertPoints endPnt+1, numInsertPoints, outWave
	outWave[endPnt, endPnt+numInsertPoints] = outWave[endPnt-1]	
	
	outWave*=direction

	//Make sure the correct startvolts after flipping
	Variable offset = outWave[0] - startVolts
	outWave -= offSet
	
	if (halfWave)
		variable cutpnt = x2pnt(outWave, TriangleTime/2+pauseTime+dwellTime)
		redimension/N=(cutpnt+1) outWave
	endif
		
	//Set the "sampling rate" to 50kHz
	variable fullTime = pnt2x( outWave, dimsize(outWave,0)-1 )
	variable newNumPnts = fullTime * 50000
	make/O/N=(newNumPnts) tempWave
	setScale/p x, 0, 1/50000, "s", tempWave
	tempWave = outWave(x)
	duplicate/O tempWave outWave
	
	smooth 2, outWave
	
	return outWave
End

//Might want to add smoothing depending on the distance we get up to speed, will need to test...
Function runHSWave(speed, distance, dwellTime, pauseTime, [HSWave,callback, direction, halfWave,mult,noFilter])

	variable speed, distance, pauseTime, dwellTime,direction, halfWave,mult,noFilter
	wave HSWave
	string callback

	if(paramIsDefault(noFilter))
		noFilter = 0
	endif
	if(paramIsDefault(mult))
		mult = outModMultiplier()
	endif
	if(paramIsDefault(callback))
		callback = ""
	endif
	if(paramIsDefault(direction))
		direction = 0
	endif
	
	if(paramIsDefault(halfWave))
		halfWave = 0
	endif
	
	string outChannel = "ARC.Output.A"
	
	if (noFilter)
		mult=1
		outChannel="Output.Z"
	endif
	
	
	variable startVolts = td_RV(outChannel)
	
	if(paramIsDefault(HSWave))
		//Make the wave
		wave HSWave = makeHSWave(speed, distance, dwellTime, pauseTime, startVolts = startVolts,direction=direction, halfWave=halfWave,mult=mult)
	else
		variable offset = HSWave[0] - startVolts
		HSWave -= offset
	endif
		
	//Transform the wave for output
	variable interpFactor = prepWaveForOutput(HSWave)
	
	//Set up outWave
	td_xSetOutWave(0, "0", outChannel, HSWave, interpFactor)
	
	//Set up data recording
	variable totalTime = (distance / speed ) + pauseTime + dwellTime
	if (!paramIsDefault(HSWave))
		totalTime = dimsize(HSWave,0)*dimDelta(HSWave,0)
	endif
	
	setupStandardCapture("Deflection", "ZSensor", 50000, totalTime*1.5, 0, 0, "runHSWaveCallback("+"\""+callback+"\""+")")

	td_StopStream("Cypher.Stream.0")
	make/O/N=0 DeflectionFC, ZSensorFC
	SetupStream(1,totalTime*1.5, DeflectionFC, ZSensorFC,event="0")

	td_WS("Event.0","Once")
End

Function runHSWaveCallback(callback)

	string callback
	td_stopInWaveBank(0)
	td_stopOutWaveBank(0)
	td_StopStream("Cypher.Stream.0")
	
	Wave Deflection, zSensor, OutWave, DeflectionFC, ZSensorFC
	
	wavetransform/O zapNans deflectionFC
	wavetransform/O zapNans zSensorFC

	duplicate/O deflection deflV
	duplicate/O deflectionFC deflVFC
	setScale d, -1, -1, "V", deflV, deflVFC

	variable invols = GV("Invols")
	fastop deflection = (invols)*deflection
	fastop deflectionFC = (invols)*deflectionFC
	setScale d, -1, -1, "m", deflection, deflectionFC
	
	variable ZLVDTSens = GV("ZLVDTSens")
	fastop zSensor = (zlvdtSens)*zSensor
	fastop zSensorFC= (zlvdtSens)*zSensorFC
	setScale d, -1, -1, "m", zSensor,zSensorFC
	
	duplicate/O outWave outWaveV
	setScale d, -1, -1, "V", outWaveV
	
	duplicate/O outWave outWaveM
	
	variable zPiezoSens = GV("zPiezoSens")
	fastop outWave = (zPiezoSens)*outWave
	setScale d, -1, -1, "m", outWave
	
	//Display results
//	stackedPlot("DeflVFC;DeflectionFC;ZSensorFC;OutWaveV;OutWave;")
	
	execute callback
End

Function/Wave magPhase2cmplx(TFEMag,TFEPhs)

	wave TFEPhs, TFEMag
	
	duplicate/O TFEMag TFECmplx
	redimension/C TFECmplx
	Wave/C newTFECmplx = $getWavesDataFolder(TFECmplx,2)
	
	
	newTFECmplx = cmplx(cos(TFEPhs*pi/180)*TFEMag, -sin(TFEPhs*pi/180)*TFEMag)

	return newTFECmplx
End

Function/Wave testTFE(driveV, TFECmplx, forward)

	variable forward
	wave driveV
	wave/C TFECmplx
	
	duplicate/O driveV DeflTest
	
	//Make even if need be
	variable size = dimsize(DeflTest,0)
	if ( mod(size,2) != 0)
		redimension/N=(size+1) DeflTest
		DeflTest[size] = DeflTest[size-1]
	endif

	FFT/Dest=DeflTestFFT DeflTest

	duplicate/C/O deflTestFFT tempTFECmplx
	tempTFECmplx = TFECmplx(x)

	if (forward)
		DeflTestFFT *= tempTFECmplx
	else
		deflTestFFT /= tempTFECmplx
	endif
	
	IFFT/Dest=temp DeflTestFFT
	duplicate/O temp DeflTest
	kilLWaves temp, tempTFECmplx//, DeflTestFFT
	
	variable offset = (deflTest[0] - driveV[0])
	deflTest -= offset


	string driveWaveName = getWavesDataFolder(driveV,2)
//	stackedPlot("deflTest;"+driveWaveName)
	
	return deflTest
End



Function FullHSTestCallback()

	Wave outWave,deflection, zSensor, outWaveV, deflectionFC, zSensorFC
	Wave TFECmplx
	
	//Rename waves
	duplicate/O outWave stdDriveM
	duplicate/O deflection stdDeflM
	duplicate/O outWaveV stdDriveV
	duplicate/O deflectionFC stdDeflM_2MHz
	duplicate/O zSensorFC stdZSensor_2Mhz

	//Make the output prediciton using outWave
	testTFE(stdDriveV, TFECmplx, 1)
	Wave deflTest
	duplicate/O deflTest stagePredictionM
	variable invols = GV("Invols")
	stagePredictionM *= invols
	
	//Set them on the same scale
	variable offset = stagePredictionM[0]-stdDeflM[0]
	stagePredictionM -= offset
	
	//Display
	display stdDeflM_2MHz
	appendToGraph/C=(0,0,2^16-1) stdDeflM
	appendToGraph/C=(0,0,0) stagePredictionM
	
	Legend/C/N=text0/F=0/A=MC

End

//Function dupHSWave()

//	Wave outWave, outWaveV, zSensor, Deflection, deflV, stagePrediction, deflectionFC, zSensorFC, deflVFC
//	duplicate/O outWave StdOutWave
//	duplicate/O outWaveV stdOutWaveV
//	duplicate/O zSensor stdZSensor
//	duplicate/O zSensorFC stdZSensorFC
//	duplicate/O Deflection stdDeflection
//	duplicate/O DeflectionFC stdDeflectionFC
//	duplicate/O deflV stdDeflV
//	duplicate/O deflVFC stdDeflVFC
	
//	stackedPlot("stdDeflVFC;stdDeflectionFC;stdZSensorFC;stdOutWaveV;stdOutWave")
//	display stdDeflectionFC
//	appendToGraph/C=(0,0,0) stagePrediction

//End


Function testNormalDrive(velocity, direction, [halfWave,mult,noFilter])

	variable velocity, direction, halfWave,mult,noFilter
	
	if(paramIsDefault(mult))
		mult = outModMultiplier()
	endif
	
	if(paramIsDefault(halfWave))
		halfWave = 0
	endif
	
	if(paramIsDefault(noFilter))
		noFilter = 0
	endif
	
	Wave TFEMag, TFEPhs
	Wave TFECmplx = magPHase2cmplx(TFEMag,TFEPhs)
	
	//Run the normal HS motion
	RunHSWave(velocity, 300e-9, 0.001, 0.005, callback="FullHSTestCallback()",direction=direction, halfWave=halfWave,mult=mult,noFilter=noFilter)
	
End
//Need to add 2MHz data collection
Function testAntiRing(velocity, direction, [halfWave,mult,noFilter])

	variable velocity, direction, halfWave,mult,noFilter
	
	if(paramIsDefault(noFilter))
		noFilter = 0
	endif
	
	if(paramIsDefault(mult))
		mult = outModMultiplier()
	endif
	if(paramIsDefault(halfWave))
		halfWave = 0
	endif
	
	wave antiRingV = makeAntiRingWave(velocity, direction, halfWave=halfWave,mult=mult)
	
	RunHSWave(velocity, 300e-9, 0.001, 0.005, HSWave=antiRingV, callback="testAntiRingCallback()")
	
End

Function/Wave makeAntiRingWave(velocity, direction, [halfWave,mult])

	variable velocity, direction, halfWave, mult
	
	
	if(paramIsDefault(halfWave))
		halfWave = 0
	endif
	
	if(paramIsDefault(mult))
		mult = outModMultiplier()
	endif
	
	//Test the antiRing
	Wave TFECmplx
	//Make a new outwave
	Wave desiredDeflV = makeHSWave(velocity, 300e-9, 0.001, 0.005, direction=direction, mult=mult)
	variable zPiezoSens = GV("ZPiezoSens")*mult
	fastop desiredDeflV = (zPiezoSens)*desiredDeflV
	
	variable invols = GV("Invols")
	fastop desiredDeflV = (1/invols)*desiredDeflV
	
	testTFE(desiredDeflV,TFEcmplx,0)
  	
  	//Need to cut the wave AFTER TFE. It seems to work better on symmetric waves
	Wave deflTest
	duplicate/O deflTest antiRingV
	
	if (halfWave)
		variable cutPnt = floor(dimsize(antiRingV,0)/2)
		redimension/N=(cutPnt) antiRingV
	endif
	
	return antiRingV

End

Function testAntiRingCallback()

	td_StopStream("Cypher.Stream.0")

	Wave outWave,deflection, zSensor, outWaveV, deflectionFC, zSensorFC
	Wave TFECmplx
	
	//Rename waves
	duplicate/O outWave antiRingDriveM
	duplicate/O deflection antiRingDeflM
	duplicate/O outWaveV antiRingDriveV
	duplicate/O deflectionFC antiRingDeflM_2MHz
	duplicate/O zSensorFC antiRingZSensor_2Mhz
	
	Wave stdDeflM, stdDeflM_2Mhz
	
	display stdDeflM
	variable offset = antiRingDeflM[0]-stdDeflM[0]
	antiRingDeflM -= offset
	appendToGraph/C=(0,0,0) antiRingDeflM
	
	display stdDeflM_2Mhz
	 offset = antiRingDeflM_2Mhz[0]-stdDeflM_2Mhz[0]
	antiRingDeflM_2Mhz -= offset
	appendToGraph/C=(0,0,0) antiRingDeflM_2MHZ
//	variable offset = antiRingDeflM_2MHz[0]-antiRingDeflM[0]
//	antiRingDeflectionFC -= offset
	
//	duplicate/O stdDeflectionFC diff_stdDeflection
//	duplicate/O antiRingDeflectionFC diff_AntiRing
	
//	differentiate diff_stdDeflection
//	differentiate diff_AntiRing
	
	
//	Wave stdDriveM stdDriveM_2MHZ
	
//	variable offset = antiRingDeflM_2MHz[0]-antiRingDeflM[0]
//	antiRingDeflectionFC -= offset
	
//	display stdDeflectionFC
//	appendToGraph/C=(0,0,0) antiRingDeflectionFC

//	display diff_stdDeflection
//	appendToGraph/C=(0,0,0) diff_AntiRing
End

Function testRamp()

	variable distance = 300e-9
	variable speed = 2e-3
	variable maxSeconds = distance / speed
	
	variable distanceV = distance / GV("ZPiezoSens")
	variable destV = td_RV("Output.Z")+distanceV
	
	print maxSeconds
	print distanceV
	print destV
	
	td_StopStream("Cypher.Stream.0")
	make/O/N=0 DeflectionFC, ZSensorFC
	SetupStream(1,maxSeconds+1, DeflectionFC, ZSensorFC,event="0")
	td_WS("Event.0","Once")
	td_setRamp(maxSeconds, "output.z", 0, destV, "", 0, 0, "", 0,0,"finishTestRamp()")

end

Function finishTestRamp()

	td_StopStream("Cypher.Stream.0")
	variable invols = GV("Invols")
	
	Wave deflectionFC
	fastOp deflectionFC = (invols)*deflectionFC
	
	display deflectionFC

End

